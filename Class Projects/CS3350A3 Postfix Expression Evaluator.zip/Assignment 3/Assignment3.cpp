/*
Author: Logan Pavelschak
Date:
Purpose: make postfix expression evaluator using a stack implementation
*/


#include "LinkedStack.h"
#include "Node.h"
#include "StackInterface.h"

#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

void PostFixEvaluation(LinkedStack<string>& inputStack) {
	//declare necessary variables
	LinkedStack<int> postFixStack;
	int operand1, operand2;
	string token;

	//create a reverse of input stack to get the correct evaluation order
	LinkedStack<string> reversedStack;
	while (!inputStack.isEmpty()) {
		reversedStack.push(inputStack.peek());
		inputStack.pop();
	}

	//process reversedStack (inputs in correct order) until it is empty
	while (!reversedStack.isEmpty()) {
		//get token (top value on stack)
		token = reversedStack.peek();
		reversedStack.pop();

		//check if input is a number (checking all digits)
		bool isValidNum = true;
		for (char ch : token) {
			if (!isdigit(ch))
				isValidNum = false;
		}
		// if operand/number, convert string to int and push
		if (isValidNum) { 
			postFixStack.push(stoi(token));
		}
		//if it's an operator, evaluate
		else if (token == "+" || token == "-" || token == "*" || token == "/") { 
			//error check before getting operand1
			if (postFixStack.isEmpty()) {
				cout << "Error: not enough operands for calculation" << endl;
				return;
			}
			//get 2nd operand
			operand2 = postFixStack.peek();
			postFixStack.pop();
			//error check for operand2
			if (postFixStack.isEmpty()) {
				cout << "Error: not enough operands for calculation" << endl;
				return;
			}
			//get 1st operand
			operand1 = postFixStack.peek();
			postFixStack.pop();

			int result = 0;
			//calculate and store result
			if (token == "+")
				result = operand1 + operand2;
			else if (token == "-")
				result = operand1 - operand2;
			else if (token == "*")
				result = operand1 * operand2;
			else if (token == "/") { //if divide by 0 error, exit program
				if (operand2 == 0) {
					cout << "Error: divide by 0" << endl;
					return;
				}
				result = operand1 / operand2;
			}
			//push result back onto the stack
			postFixStack.push(result);
		}
		else { //if is neither, throw error and exit
			cout << "Error: Invalid token: " << token << endl;
			return;
		}
	}

	//output result
	if (!postFixStack.isEmpty()) {
		cout << postFixStack.peek() << endl;
	}
	else {
		cout << "no result to display" << endl;
	}
}

int main() {
	//declare necessary variables to get the expression
	string input, fullExpression;
	LinkedStack<string> inputStack;
	
	//prompt 
	cout << "Enter the postfix expression, 1 token per line. Enter '-1' to terminate." << endl;

	//loop adds inputs to fullExpression (for output purposes) and to
	//the inputStack, stopping at -1 without adding it
	getline(cin, input); //initial input
	while (input != "-1") {
		inputStack.push(input);
		fullExpression += input + " ";
		getline(cin, input);
	}
	
	//output full expression
	cout << fullExpression << " = " << endl;

	//call postfix evaluation
	PostFixEvaluation(inputStack);

	return 0;
}