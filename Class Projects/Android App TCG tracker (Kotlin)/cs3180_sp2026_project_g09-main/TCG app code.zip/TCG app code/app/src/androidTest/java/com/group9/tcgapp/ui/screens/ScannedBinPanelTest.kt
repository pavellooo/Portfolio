package com.group9.tcgapp.ui.screens

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.group9.tcgapp.data.repository.ScannedCardEntry
import com.group9.tcgapp.ui.TestTags
import com.group9.tcgapp.viewmodel.CardSearchResult
import com.group9.tcgapp.viewmodel.GameType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class ScannedBinPanelTest {

    @get:Rule
    val composeRule = createComposeRule()

    private fun sampleEntry(
        id: String = "base1-4",
        name: String = "Charizard",
        isFoil: Boolean = false,
        hasFoil: Boolean = true
    ): ScannedCardEntry {
        return ScannedCardEntry(
            card = CardSearchResult(
                id = id,
                name = name,
                subtitle = "Pokémon • Base • Rare Holo",
                imageUrl = null,
                game = GameType.POKEMON,
                hasFoilVariant = hasFoil
            ),
            isFoil = isFoil,
            scannedAt = 1000L
        )
    }

    @Test
    fun scannedBinPanel_emptyBinShowsEmptyMessage() {
        composeRule.setContent {
            ScannedBinPanel(
                entries = emptyList(),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = {},
                onSaveAll = {},
                onClearAll = {},
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_DIALOG)
            .assertIsDisplayed()

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_EMPTY_TEXT)
            .assertIsDisplayed()
    }

    @Test
    fun scannedBinPanel_displaysCardEntry() {
        val entry = sampleEntry()

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = {},
                onSaveAll = {},
                onClearAll = {},
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithText("Charizard")
            .assertIsDisplayed()

        composeRule
            .onNodeWithText("Pokémon • Base • Rare Holo")
            .assertIsDisplayed()
    }

    @Test
    fun scannedBinPanel_saveOneCallsCallback() {
        val entry = sampleEntry()
        var savedEntry: ScannedCardEntry? = null

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = { savedEntry = it },
                onRemoveOne = {},
                onSaveAll = {},
                onClearAll = {},
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_SAVE_PREFIX + entry.localId)
            .performClick()

        assertEquals(entry.localId, savedEntry?.localId)
    }

    @Test
    fun scannedBinPanel_removeOneCallsCallback() {
        val entry = sampleEntry()
        var removedEntry: ScannedCardEntry? = null

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = { removedEntry = it },
                onSaveAll = {},
                onClearAll = {},
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_REMOVE_PREFIX + entry.localId)
            .performClick()

        assertEquals(entry.localId, removedEntry?.localId)
    }

    @Test
    fun scannedBinPanel_saveAllCallsCallback() {
        val entry = sampleEntry()
        var saveAllClicked = false

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = {},
                onSaveAll = { saveAllClicked = true },
                onClearAll = {},
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_SAVE_ALL)
            .performClick()

        assertTrue(saveAllClicked)
    }

    @Test
    fun scannedBinPanel_clearAllCallsCallback() {
        val entry = sampleEntry()
        var clearAllClicked = false

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = {},
                onSaveAll = {},
                onClearAll = { clearAllClicked = true },
                onFoilChanged = { _, _ -> }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_CLEAR_ALL)
            .performClick()

        assertTrue(clearAllClicked)
    }

    @Test
    fun scannedBinPanel_foilToggleCallsCallback() {
        val entry = sampleEntry(isFoil = false, hasFoil = true)
        var changedEntry: ScannedCardEntry? = null
        var changedFoilValue: Boolean? = null

        composeRule.setContent {
            ScannedBinPanel(
                entries = listOf(entry),
                isSaving = false,
                errorMessage = null,
                statusMessage = null,
                onDismiss = {},
                onSaveOne = {},
                onRemoveOne = {},
                onSaveAll = {},
                onClearAll = {},
                onFoilChanged = { selectedEntry, isFoil ->
                    changedEntry = selectedEntry
                    changedFoilValue = isFoil
                }
            )
        }

        composeRule
            .onNodeWithTag(TestTags.SCANNED_BIN_FOIL_PREFIX + entry.localId)
            .performClick()

        assertEquals(entry.localId, changedEntry?.localId)
        assertEquals(true, changedFoilValue)
    }
}