package com.group9.tcgapp.ui.screens

import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.text.AnnotatedString
import com.group9.tcgapp.ui.theme.TCGAppTheme
import org.junit.Rule
import org.junit.Test

class SearchScreenFilterTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun searchScreen_canSwitchGameTabsAndToggleAdvancedFilters() {
        composeRule.setContent {
            TCGAppTheme {
                SearchScreen()
            }
        }

        composeRule
            .onNodeWithText("Pokémon")
            .assertIsDisplayed()

        composeRule
            .onNodeWithText("MTG")
            .assertIsDisplayed()

        composeRule
            .onNodeWithText("MTG")
            .performClick()

        composeRule.waitForIdle()

        composeRule
            .onNodeWithText("Pokémon")
            .performClick()

        composeRule.waitForIdle()

        composeRule
            .onNodeWithText("Show Advanced")
            .performScrollTo()
            .assertIsDisplayed()

        composeRule
            .onNodeWithText("Show Advanced")
            .performClick()

        composeRule.waitForIdle()

        composeRule
            .onNodeWithText("Hide Advanced")
            .performScrollTo()
            .assertIsDisplayed()

        composeRule
            .onNodeWithText("Hide Advanced")
            .performClick()

        composeRule.waitForIdle()

        composeRule
            .onNodeWithText("Show Advanced")
            .performScrollTo()
            .assertIsDisplayed()
    }

    @Test
    fun searchScreen_canEnterCardName() {
        composeRule.setContent {
            TCGAppTheme {
                SearchScreen()
            }
        }

        val firstTextField = composeRule
            .onAllNodes(hasSetTextAction())
            .onFirst()

        firstTextField.performTextInput("Charizard")

        composeRule.waitForIdle()

        firstTextField.assert(
            SemanticsMatcher.expectValue(
                SemanticsProperties.EditableText,
                AnnotatedString("Charizard")
            )
        )
    }
}