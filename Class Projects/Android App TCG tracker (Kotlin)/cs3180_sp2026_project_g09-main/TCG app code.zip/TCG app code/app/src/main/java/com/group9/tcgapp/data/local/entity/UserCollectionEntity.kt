package com.group9.tcgapp.data.local.entity

import androidx.room.Entity

@Entity(
    tableName = "user_collection",
    primaryKeys = ["cardId"]
)
data class UserCollectionEntity(
    val cardId: String,
    val quantityOwned: Int,
    val condition: String? = null,
    val notes: String? = null,
    val isFavorite: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)