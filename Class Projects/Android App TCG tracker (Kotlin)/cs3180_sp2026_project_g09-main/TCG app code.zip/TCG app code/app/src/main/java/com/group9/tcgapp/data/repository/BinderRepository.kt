package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.local.dao.BinderDao
import com.group9.tcgapp.data.local.entity.BinderCardCrossRef
import com.group9.tcgapp.data.local.entity.BinderEntity
import com.group9.tcgapp.data.local.entity.BinderWithCards
import kotlinx.coroutines.flow.Flow

class BinderRepository(
    private val binderDao: BinderDao
) {
    fun getAllBindersFlow(): Flow<List<BinderEntity>> {
        return binderDao.getAllBindersFlow()
    }

    fun getBindersByGameFlow(gameType: String): Flow<List<BinderEntity>> {
        return binderDao.getBindersByGameFlow(gameType)
    }

    fun getBinderWithCardsFlow(binderId: Long): Flow<BinderWithCards?> {
        return binderDao.getBinderWithCardsFlow(binderId)
    }

    fun getBinderIdsForCardFlow(cardId: String): Flow<List<Long>> {
        return binderDao.getBinderIdsForCardFlow(cardId)
    }

    suspend fun getCardCountForBinder(binderId: Long): Int {
        return binderDao.getCardCountForBinder(binderId)
    }

    suspend fun createBinder(gameType: String, name: String, description: String? = null): Long {
        return binderDao.insertBinder(
            BinderEntity(
                gameType = gameType,
                name = name,
                description = description
            )
        )
    }

    suspend fun addCardToBinder(binderId: Long, cardId: String, quantity: Int = 1) {
        binderDao.addCardToBinder(
            BinderCardCrossRef(
                binderId = binderId,
                cardId = cardId,
                quantityInBinder = quantity
            )
        )
    }

    suspend fun removeCardFromBinder(binderId: Long, cardId: String) {
        binderDao.removeCardFromBinder(binderId, cardId)
    }

    suspend fun updateCardQuantity(binderId: Long, cardId: String, quantity: Int) {
        if (quantity <= 0) {
            removeCardFromBinder(binderId, cardId)
        } else {
            binderDao.updateCardQuantityInBinder(binderId, cardId, quantity)
        }
    }

    suspend fun deleteBinder(binderId: Long) {
        binderDao.deleteBinder(binderId)
    }

    suspend fun renameBinder(
        binderId: Long,
        name: String,
        description: String? = null
    ) {
        binderDao.updateBinder(binderId, name, description)
    }
}