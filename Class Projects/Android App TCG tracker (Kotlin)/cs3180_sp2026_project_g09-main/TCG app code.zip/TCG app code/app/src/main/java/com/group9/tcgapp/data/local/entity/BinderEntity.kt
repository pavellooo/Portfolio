package com.group9.tcgapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "binders")
data class BinderEntity(
    @PrimaryKey(autoGenerate = true)
    val binderId: Long = 0,
    val gameType: String,
    val name: String,
    val description: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)