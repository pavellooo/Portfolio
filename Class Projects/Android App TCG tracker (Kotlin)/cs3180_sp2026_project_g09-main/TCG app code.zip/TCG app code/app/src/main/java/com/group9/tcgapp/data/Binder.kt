package com.group9.tcgapp.data

data class Binder(
    val id: String,
    val name: String,
    val cardIds: List<String> = emptyList()
)
