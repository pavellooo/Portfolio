package com.group9.tcgapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.SearchRepository

class SearchViewModelFactory(
    private val searchRepository: SearchRepository,
    private val cardRepository: CardRepository,
    private val collectionRepository: CollectionRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SearchViewModel::class.java)) {
            return SearchViewModel(
                searchRepository = searchRepository,
                cardRepository = cardRepository,
                collectionRepository = collectionRepository
            ) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}