package com.group9.tcgapp.data.local.entity

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class BinderWithCards(
    @Embedded val binder: BinderEntity,

    @Relation(
        parentColumn = "binderId",
        entityColumn = "id",
        associateBy = Junction(
            value = BinderCardCrossRef::class,
            parentColumn = "binderId",
            entityColumn = "cardId"
        )
    )
    val cards: List<CardEntity>
)