package com.group9.tcgapp.data.local.db


import androidx.room.Database
import androidx.room.RoomDatabase
import com.group9.tcgapp.data.local.dao.BinderDao
import com.group9.tcgapp.data.local.dao.CardDao
import com.group9.tcgapp.data.local.dao.CollectionDao
import com.group9.tcgapp.data.local.dao.DeckDao
import com.group9.tcgapp.data.local.entity.*

@Database(
    entities = [
        CardEntity::class,
        ExpansionEntity::class,
        CardRuleEntity::class,
        CardRulingEntity::class,
        CardTypeEntity::class,
        CardSubtypeEntity::class,
        CardSupertypeEntity::class,
        CardColorEntity::class,
        CardColorIdentityEntity::class,
        CardKeywordEntity::class,
        BinderEntity::class,
        BinderCardCrossRef::class,
        DeckEntity::class,
        DeckCardCrossRef::class,
        UserCollectionEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cardDao(): CardDao
    abstract fun collectionDao(): CollectionDao
    abstract fun binderDao(): BinderDao
    abstract fun deckDao(): DeckDao
}