package com.group9.tcgapp.data.local.entity

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class DeckWithCards(
    @Embedded val deck: DeckEntity,

    @Relation(
        parentColumn = "deckId",
        entityColumn = "id",
        associateBy = Junction(
            value = DeckCardCrossRef::class,
            parentColumn = "deckId",
            entityColumn = "cardId"
        )
    )
    val cards: List<CardEntity>
)
