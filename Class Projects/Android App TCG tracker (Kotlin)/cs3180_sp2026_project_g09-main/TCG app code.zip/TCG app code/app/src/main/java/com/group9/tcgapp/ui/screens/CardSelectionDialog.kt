package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.group9.tcgapp.ui.TestTags
import com.group9.tcgapp.viewmodel.CardSearchResult

@Composable
fun CardSelectionDialog(
    candidateName: String,
    matches: List<CardSearchResult>,
    onCardSelected: (CardSearchResult, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val foilSelections = remember(matches) {
        mutableStateMapOf<String, Boolean>().apply {
            matches.forEach { card ->
                put(card.id, false)
            }
        }
    }

    AlertDialog(
        modifier = Modifier.testTag(TestTags.CARD_SELECTION_DIALOG),
        onDismissRequest = onDismiss,
        title = {
            Text("Select Correct Card")
        },
        text = {
            Column {
                Text(
                    text = "Detected: $candidateName",
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(matches, key = { it.id }) { card ->
                        CardSelectionItem(
                            card = card,
                            isFoil = foilSelections[card.id] == true,
                            onFoilChanged = { checked ->
                                foilSelections[card.id] = checked
                            },
                            onClick = {
                                onCardSelected(
                                    card,
                                    foilSelections[card.id] == true
                                )
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun CardSelectionItem(
    card: CardSearchResult,
    isFoil: Boolean,
    onFoilChanged: (Boolean) -> Unit,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.testTag(TestTags.CARD_SELECTION_ITEM_PREFIX + card.id)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = card.imageUrl,
                contentDescription = card.name,
                modifier = Modifier.size(width = 70.dp, height = 98.dp),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = card.name,
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    text = card.subtitle,
                    style = MaterialTheme.typography.bodySmall
                )

                if (card.hasFoilVariant) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isFoil,
                            onCheckedChange = onFoilChanged,
                            modifier = Modifier.testTag(
                                TestTags.CARD_SELECTION_FOIL_PREFIX + card.id
                            )
                        )

                        Text("Foil")
                    }
                }
            }
        }
    }
}