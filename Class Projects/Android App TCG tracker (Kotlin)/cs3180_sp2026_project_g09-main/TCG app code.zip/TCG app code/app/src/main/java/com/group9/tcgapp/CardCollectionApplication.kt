package com.group9.tcgapp

import android.app.Application
import com.group9.tcgapp.data.AppContainer

class CardCollectionApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}