package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.remote.dto.CardDto
import com.group9.tcgapp.viewmodel.CardSearchResult
import com.group9.tcgapp.viewmodel.GameType

fun CardDto.toCardSearchResult(game: GameType): CardSearchResult {
    val expansionName = expansion?.name.orEmpty()
    val rarityText = rarity.orEmpty()

    val subtitle = buildString {
        append(
            when (game) {
                GameType.POKEMON -> "Pokémon"
                GameType.MTG -> "MTG"
            }
        )

        if (expansionName.isNotBlank()) {
            append(" • ")
            append(expansionName)
        }

        if (rarityText.isNotBlank()) {
            append(" • ")
            append(rarityText)
        }
    }

    val hasFoil = variants.any { variant ->
        variant.name?.contains("foil", ignoreCase = true) == true
    }

    return CardSearchResult(
        id = id,
        name = name,
        subtitle = subtitle,
        imageUrl = images.firstOrNull()?.small,
        game = game,
        hasFoilVariant = hasFoil
    )
}