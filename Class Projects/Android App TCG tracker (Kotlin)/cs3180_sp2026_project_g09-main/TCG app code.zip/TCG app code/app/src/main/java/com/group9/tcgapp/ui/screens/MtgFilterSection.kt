package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.group9.tcgapp.viewmodel.MtgColor
import com.group9.tcgapp.viewmodel.MtgLayoutOption
import com.group9.tcgapp.viewmodel.SearchUiState
import com.group9.tcgapp.viewmodel.SearchViewModel

@Composable
fun MtgFiltersSection(
    vm: SearchViewModel,
    uiState: SearchUiState
) {
    val filters = uiState.mtg

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Magic: The Gathering Filters",
            style = MaterialTheme.typography.titleMedium
        )

        Text(text = "Colors")
        MtgColorChipGroup(
            selectedColors = filters.selectedColors,
            onToggle = vm::toggleMtgColor
        )

        Text(text = "Color Identity")
        MtgColorChipGroup(
            selectedColors = filters.selectedColorIdentity,
            onToggle = vm::toggleMtgColorIdentity
        )

        OutlinedTextField(
            value = filters.type,
            onValueChange = vm::onMtgTypeChanged,
            label = { Text("Type") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = filters.subtype,
            onValueChange = vm::onMtgSubtypeChanged,
            label = { Text("Subtype") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (uiState.showAdvancedFilters) {
            OutlinedTextField(
                value = filters.supertype,
                onValueChange = vm::onMtgSupertypeChanged,
                label = { Text("Supertype") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = filters.keyword,
                onValueChange = vm::onMtgKeywordChanged,
                label = { Text("Keyword") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = filters.artist,
                onValueChange = vm::onMtgArtistChanged,
                label = { Text("Artist") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = filters.manaValueMin?.toString().orEmpty(),
                    onValueChange = vm::onMtgManaValueMinChanged,
                    label = { Text("Mana Value Min") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(12.dp))

                OutlinedTextField(
                    value = filters.manaValueMax?.toString().orEmpty(),
                    onValueChange = vm::onMtgManaValueMaxChanged,
                    label = { Text("Mana Value Max") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            Text(text = "Layout")
            MtgLayoutChipGroup(
                selectedLayout = filters.layout,
                onSelected = vm::onMtgLayoutChanged
            )

            Row {
                Checkbox(
                    checked = filters.hasRulesText,
                    onCheckedChange = vm::onMtgHasRulesTextChanged
                )
                Text(
                    text = "Has Rules Text",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
private fun MtgColorChipGroup(
    selectedColors: Set<MtgColor>,
    onToggle: (MtgColor) -> Unit
) {
    val colors = listOf(
        MtgColor.WHITE,
        MtgColor.BLUE,
        MtgColor.BLACK,
        MtgColor.RED,
        MtgColor.GREEN,
        MtgColor.COLORLESS
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        colors.forEach { color ->
            FilterChip(
                selected = selectedColors.contains(color),
                onClick = { onToggle(color) },
                label = { Text(color.symbol) }
            )
        }
    }
}

@Composable
private fun MtgLayoutChipGroup(
    selectedLayout: MtgLayoutOption,
    onSelected: (MtgLayoutOption) -> Unit
) {
    val options = listOf(
        MtgLayoutOption.ANY,
        MtgLayoutOption.NORMAL,
        MtgLayoutOption.SPLIT,
        MtgLayoutOption.TRANSFORM,
        MtgLayoutOption.MODAL_DFC,
        MtgLayoutOption.SAGA,
        MtgLayoutOption.ADVENTURE,
        MtgLayoutOption.TOKEN
    )

    val rows = options.chunked(4)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { rowOptions ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowOptions.forEach { option ->
                    FilterChip(
                        selected = selectedLayout == option,
                        onClick = { onSelected(option) },
                        label = { Text(option.label) }
                    )
                }
            }
        }
    }
}