package com.group9.tcgapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey
    val id: String,
    val game: String,
    val name: String,
    val typeLine: String?,
    val number: String?,

    val rarity: String?,
    val artist: String?,

    val manaCost: String?,
    val manaValue: Int?,

    val power: String?,
    val toughness: String?,

    val imageSmall: String?,
    val imageMedium: String?,
    val imageLarge: String?,

    val expansionId: String?,
    val language: String?,
    val languageCode: String?,
    val layout: String?,
    val expansionSortOrder: Int?
)