package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.remote.api.ScrydexAPI
import com.group9.tcgapp.viewmodel.CardSearchResult
import com.group9.tcgapp.viewmodel.GameType

class SearchRepository(
    private val api: ScrydexAPI
) {

    suspend fun searchCards(
        request: CardSearchRequest,
        page: Int = 1,
        pageSize: Int = 50
    ): List<CardSearchResult> {
        // TODO: this if statement below is for showing mock data only. Comment/Remove this!
        // if (request.shared.query.equals("mock", ignoreCase = true)) {
        //     return mockSearchResults(request.game)
        // }

        val gamePath = request.game.toApiGamePath()
        val query = request.toLuceneQuery()

        val response = api.searchCards(
            game = gamePath,
            query = query,
            page = page,
            pageSize = pageSize.coerceIn(1, 100)
        )

        return response.data.orEmpty().map { dto ->
            dto.toCardSearchResult(request.game)
        }
    }

    suspend fun searchByScannedName(
        game: GameType,
        candidateName: String,
        pageSize: Int = 8
    ): List<CardSearchResult> {
        val request = CardSearchRequest(
            game = game,
            shared = SharedSearchRequest(
                query = candidateName,
                setNameOrCode = null,
                cardNumber = null,
                rarity = null,
                language = null,
                sort = null
            ),
            mtg = null,
            pokemon = null
        )

        return searchCards(
            request = request,
            page = 1,
            pageSize = pageSize
        )
    }
}

// TODO: the function below is for showing mock data only. Comment/Remove this!
// private fun mockSearchResults(game: GameType): List<CardSearchResult> {
//     return when (game) {
//         GameType.POKEMON -> listOf(
//             CardSearchResult(
//                 id = "mock-pokemon-base1-4",
//                 name = "Charizard",
//                 subtitle = "Pokemon • Base • Rare Holo",
//                 game = GameType.POKEMON
//             ),
//             CardSearchResult(
//                 id = "mock-pokemon-base1-58",
//                 name = "Pikachu",
//                 subtitle = "Pokemon • Base • Common",
//                 game = GameType.POKEMON
//             )
//         )

//         GameType.MTG -> listOf(
//             CardSearchResult(
//                 id = "mock-mtg-lightning-bolt",
//                 name = "Lightning Bolt",
//                 subtitle = "MTG • Magic 2010 • Common",
//                 game = GameType.MTG
//             ),
//             CardSearchResult(
//                 id = "mock-mtg-serra-angel",
//                 name = "Serra Angel",
//                 subtitle = "MTG • Magic 2010 • Uncommon",
//                 game = GameType.MTG
//             )
//         )
//     }
// }

private fun GameType.toApiGamePath(): String {
    return when (this) {
        GameType.POKEMON -> "pokemon"
        GameType.MTG -> "magicthegathering"
    }
}