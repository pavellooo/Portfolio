package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.group9.tcgapp.CardCollectionApplication
import com.group9.tcgapp.viewmodel.GameType
import com.group9.tcgapp.viewmodel.SearchViewModel
import com.group9.tcgapp.viewmodel.SearchViewModelFactory
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll



@Composable
fun SearchScreen() {
    val context = LocalContext.current.applicationContext as CardCollectionApplication

    val vm: SearchViewModel = viewModel(
        factory = SearchViewModelFactory(
            searchRepository = context.container.searchRepository,
            cardRepository = context.container.cardRepository,
            collectionRepository = context.container.collectionRepository
        )
    )

    val uiState by vm.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = uiState.shared.query,
            onValueChange = vm::onQueryChanged,
            label = { Text("Card Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(
                selected = uiState.selectedGame == GameType.POKEMON,
                onClick = { vm.onGameSelected(GameType.POKEMON) },
                label = { Text("Pokémon") }
            )

            FilterChip(
                selected = uiState.selectedGame == GameType.MTG,
                onClick = { vm.onGameSelected(GameType.MTG) },
                label = { Text("MTG") }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        SharedFiltersSection(vm = vm, uiState = uiState)

        Spacer(modifier = Modifier.height(12.dp))

        when (uiState.selectedGame) {
            GameType.POKEMON -> PokemonFiltersSection(vm = vm, uiState = uiState)
            GameType.MTG -> MtgFiltersSection(vm = vm, uiState = uiState)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = vm::searchCards) {
                Text("Search")
            }

            Button(onClick = vm::clearAllFilters) {
                Text("Clear")
            }

            Button(onClick = vm::toggleAdvancedFilters) {
                Text(
                    if (uiState.showAdvancedFilters) "Hide Advanced"
                    else "Show Advanced"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (uiState.isSaving) {
            Text("Saving card to collection...")
            Spacer(modifier = Modifier.height(8.dp))
        }

        uiState.statusMessage?.let { status ->
            Text(
                text = status,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        when {
            uiState.isLoading -> {
                CircularProgressIndicator()
            }

            uiState.errorMessage != null -> {
                Text(
                    text = uiState.errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error
                )
            }

            else -> {
                if (uiState.results.isEmpty()) {
                    Text("No cards found.")
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        uiState.results.forEach { result ->
                            SearchResultItem(
                                name = result.name,
                                subtitle = result.subtitle,
                                onAddToCollection = { vm.addCardToCollection(result.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}