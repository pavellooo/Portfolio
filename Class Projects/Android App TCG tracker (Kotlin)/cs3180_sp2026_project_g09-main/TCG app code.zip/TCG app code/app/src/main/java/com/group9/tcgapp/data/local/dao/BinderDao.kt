package com.group9.tcgapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.group9.tcgapp.data.local.entity.BinderCardCrossRef
import com.group9.tcgapp.data.local.entity.BinderEntity
import com.group9.tcgapp.data.local.entity.BinderWithCards
import kotlinx.coroutines.flow.Flow

@Dao
interface BinderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBinder(binder: BinderEntity): Long

    @Query("SELECT * FROM binders ORDER BY createdAt DESC")
    fun getAllBindersFlow(): Flow<List<BinderEntity>>

    @Query("SELECT * FROM binders WHERE gameType = :gameType ORDER BY createdAt DESC")
    fun getBindersByGameFlow(gameType: String): Flow<List<BinderEntity>>

    @Transaction
    @Query("SELECT * FROM binders WHERE binderId = :binderId LIMIT 1")
    fun getBinderWithCardsFlow(binderId: Long): Flow<BinderWithCards?>

    @Query("SELECT binderId FROM binder_cards WHERE cardId = :cardId")
    fun getBinderIdsForCardFlow(cardId: String): Flow<List<Long>>

    @Query("SELECT COUNT(DISTINCT cardId) FROM binder_cards WHERE binderId = :binderId")
    suspend fun getCardCountForBinder(binderId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addCardToBinder(crossRef: BinderCardCrossRef)

    @Query("DELETE FROM binder_cards WHERE binderId = :binderId AND cardId = :cardId")
    suspend fun removeCardFromBinder(binderId: Long, cardId: String)

    @Query("""
        UPDATE binder_cards
        SET quantityInBinder = :quantity
        WHERE binderId = :binderId AND cardId = :cardId
    """)
    suspend fun updateCardQuantityInBinder(binderId: Long, cardId: String, quantity: Int)

    @Query("DELETE FROM binders WHERE binderId = :binderId")
    suspend fun deleteBinder(binderId: Long)

    @Query(
        """
        UPDATE binders
        SET name = :name, description = :description
        WHERE binderId = :binderId
        """
    )
    suspend fun updateBinder(binderId: Long, name: String, description: String? = null)
}