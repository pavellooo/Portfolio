package com.group9.tcgapp.data.repository

import com.group9.tcgapp.viewmodel.*

fun CardSearchRequest.toLuceneQuery(): String {
    val parts = mutableListOf<String>()

    // --- Shared ---
    shared.query.takeIf { it.isNotBlank() }?.let {
        parts.add("name:\"$it\"")
    }

    shared.setNameOrCode?.let {
        parts.add("expansion.name:\"$it\"")
    }

    shared.cardNumber?.let {
        parts.add("number:$it")
    }

    shared.rarity?.let {
        parts.add("rarity:\"${it.label}\"")
    }

    shared.language?.let {
        parts.add("language_code:${it.toApiValue()}")
    }

    // --- Game-specific ---
    when (game) {
        GameType.MTG -> mtg?.let { addMtgFilters(parts, it) }
        GameType.POKEMON -> pokemon?.let { addPokemonFilters(parts, it) }
    }

    return parts.joinToString(" ").ifBlank { "*:*" }
}
private fun addMtgFilters(
    parts: MutableList<String>,
    mtg: MtgSearchRequest
) {
    if (mtg.selectedColors.isNotEmpty()) {
        val colorQuery = mtg.selectedColors.joinToString(" OR ") {
            "colors:${it.symbol}"
        }
        parts.add("($colorQuery)")
    }

    mtg.type?.let { parts.add("types:$it") }
    mtg.subtype?.let { parts.add("subtypes:$it") }
    mtg.supertype?.let { parts.add("supertypes:$it") }
    mtg.keyword?.let { parts.add("keywords:$it") }
    mtg.artist?.let { parts.add("artist:\"$it\"") }

    // ranges
    if (mtg.manaValueMin != null || mtg.manaValueMax != null) {
        val min = mtg.manaValueMin ?: "*"
        val max = mtg.manaValueMax ?: "*"
        parts.add("mana_value:[$min TO $max]")
    }

    if (mtg.powerMin != null || mtg.powerMax != null) {
        val min = mtg.powerMin ?: "*"
        val max = mtg.powerMax ?: "*"
        parts.add("power:[$min TO $max]")
    }

    if (mtg.toughnessMin != null || mtg.toughnessMax != null) {
        val min = mtg.toughnessMin ?: "*"
        val max = mtg.toughnessMax ?: "*"
        parts.add("toughness:[$min TO $max]")
    }

    mtg.layout?.let {
        parts.add("layout:${it.label.lowercase()}")
    }

    if (mtg.hasRulesText) {
        parts.add("rules:*")
    }
}

private fun addPokemonFilters(
    parts: MutableList<String>,
    pokemon: PokemonSearchRequest
) {
    pokemon.pokemonType?.let {
        parts.add("types:${it.label}")
    }

    pokemon.stage?.let {
        parts.add("subtypes:\"${it.label}\"")
    }

    pokemon.subtype?.let {
        parts.add("subtypes:$it")
    }

    pokemon.artist?.let {
        parts.add("artist:\"$it\"")
    }

    pokemon.evolvesFrom?.let {
        parts.add("evolves_from:$it")
    }

    if (pokemon.hpMin != null || pokemon.hpMax != null) {
        val min = pokemon.hpMin ?: "*"
        val max = pokemon.hpMax ?: "*"
        parts.add("hp:[$min TO $max]")
    }

    pokemon.weaknessType?.let {
        parts.add("weaknesses.type:${it.label}")
    }

    pokemon.retreatCostMax?.let {
        parts.add("converted_retreat_cost:[* TO $it]")
    }

    if (pokemon.hasAbility) {
        parts.add("abilities.name:*")
    }

    if (pokemon.hasAttack) {
        parts.add("attacks.name:*")
    }

    if (pokemon.hasRuleBox) {
        parts.add("rules:*")
    }
}

private fun LanguageOption.toApiValue(): String {
    return when (this) {
        LanguageOption.ENGLISH -> "EN"
        LanguageOption.JAPANESE -> "JA"
        else -> ""
    }
}