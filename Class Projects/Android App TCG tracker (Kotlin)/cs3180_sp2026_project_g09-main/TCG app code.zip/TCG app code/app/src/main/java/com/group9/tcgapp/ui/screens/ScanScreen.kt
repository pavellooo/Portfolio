package com.group9.tcgapp.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.group9.tcgapp.CardCollectionApplication
import com.group9.tcgapp.data.repository.ScannedCardEntry
import com.group9.tcgapp.ui.AppRoute
import com.group9.tcgapp.ui.TestTags
import com.group9.tcgapp.viewmodel.GameType
import com.group9.tcgapp.viewmodel.ScanViewModel
import com.group9.tcgapp.viewmodel.ScanViewModelFactory

@Composable
fun CameraPreviewBox(
    modifier: Modifier = Modifier,
    scanningEnabled: Boolean = true,
    flashlightEnabled: Boolean = false,
    onTextFound: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val currentScanningEnabled = rememberUpdatedState(scanningEnabled)
    val currentOnTextFound = rememberUpdatedState(onTextFound)

    var camera by remember { mutableStateOf<Camera?>(null) }

    LaunchedEffect(camera, flashlightEnabled) {
        camera?.cameraControl?.enableTorch(flashlightEnabled)
    }

    val cameraExecutor = remember {
        java.util.concurrent.Executors.newSingleThreadExecutor()
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
        )
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(modifier = modifier) {
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = androidx.camera.core.Preview.Builder()
                            .build()
                            .also { cameraPreview ->
                                cameraPreview.setSurfaceProvider(previewView.surfaceProvider)
                            }

                        val imageAnalysis = androidx.camera.core.ImageAnalysis.Builder()
                            .setBackpressureStrategy(
                                androidx.camera.core.ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                            )
                            .build()
                            .also { analysis ->
                                analysis.setAnalyzer(
                                    cameraExecutor,
                                    com.group9.tcgapp.data.scanner.CardOcrAnalyzer(
                                        shouldAnalyze = {
                                            currentScanningEnabled.value
                                        },
                                        onTextFound = { text ->
                                            currentOnTextFound.value(text)
                                        }
                                    )
                                )
                            }

                        try {
                            cameraProvider.unbindAll()

                            camera = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                imageAnalysis
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                text = "Camera permission required",
                modifier = Modifier.align(Alignment.Center),
                color = Color.Gray
            )
        }
    }
}

@Composable
fun ScanScreen(
    modifier: Modifier = Modifier,
    navController: NavHostController? = null
) {
    val app = LocalContext.current.applicationContext as CardCollectionApplication

    val scanViewModel: ScanViewModel = viewModel(
        factory = ScanViewModelFactory(
            searchRepository = app.container.searchRepository,
            scannedCardBinRepository = app.container.scannedCardBinRepository,
            cardRepository = app.container.cardRepository,
            collectionRepository = app.container.collectionRepository
        )
    )

    val uiState by scanViewModel.uiState.collectAsStateWithLifecycle()

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 80.dp, start = 16.dp, end = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = uiState.selectedGame == GameType.POKEMON,
                        onClick = { scanViewModel.onGameSelected(GameType.POKEMON) },
                        label = { Text("Pokémon") }
                    )

                    FilterChip(
                        selected = uiState.selectedGame == GameType.MTG,
                        onClick = { scanViewModel.onGameSelected(GameType.MTG) },
                        label = { Text("MTG") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .size(340.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color.Black)
                        .border(1.dp, Color.Black, RoundedCornerShape(32.dp))
                ) {
                    CameraPreviewBox(
                        modifier = Modifier.fillMaxSize(),
                        scanningEnabled = !uiState.showSelectionDialog &&
                                !uiState.showBinPanel &&
                                !uiState.isSearching &&
                                !uiState.isSaving,
                        flashlightEnabled = uiState.isFlashlightOn,
                        onTextFound = { rawText ->
                            scanViewModel.onTextRecognized(rawText)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = scanViewModel::toggleFlashlight,
                    modifier = Modifier.testTag(TestTags.SCAN_FLASHLIGHT_BUTTON)
                ) {
                    Text(
                        if (uiState.isFlashlightOn) {
                            "Flashlight Off"
                        } else {
                            "Flashlight On"
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = uiState.lastScanMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (uiState.isSearching) {
                    Spacer(modifier = Modifier.height(8.dp))
                    CircularProgressIndicator()
                }

                if (uiState.isSaving) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Saving...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (uiState.candidateCardName.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Detected: ${uiState.candidateCardName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (uiState.errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = uiState.errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Scanned Bin: ${uiState.scannedBin.size}",
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    text = "Use the Bin button to review, edit, or save scanned cards.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.weight(1f))
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 40.dp, start = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = scanViewModel::openBinPanel,
                    modifier = Modifier.testTag(TestTags.SCAN_BIN_BUTTON)
                ) {
                    Text("Bin (${uiState.scannedBin.size})")
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 40.dp, end = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { navController?.navigate(AppRoute.Settings.route) }
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        modifier = Modifier.size(28.dp),
                        tint = Color.Black
                    )
                }
            }

            if (uiState.showSelectionDialog) {
                CardSelectionDialog(
                    candidateName = uiState.candidateCardName,
                    matches = uiState.possibleMatches,
                    onCardSelected = scanViewModel::onCardSelected,
                    onDismiss = scanViewModel::dismissSelectionDialog
                )
            }

            if (uiState.showBinPanel) {
                ScannedBinPanel(
                    entries = uiState.scannedBin,
                    isSaving = uiState.isSaving,
                    errorMessage = uiState.errorMessage,
                    statusMessage = uiState.lastScanMessage,
                    onDismiss = scanViewModel::dismissBinPanel,
                    onSaveOne = scanViewModel::saveOneToCollection,
                    onRemoveOne = { entry ->
                        scanViewModel.removeFromBin(entry.localId)
                    },
                    onSaveAll = scanViewModel::saveAllToCollection,
                    onClearAll = scanViewModel::clearBin,
                    onFoilChanged = { entry, isFoil ->
                        scanViewModel.setBinEntryFoilStatus(entry.localId, isFoil)
                    }
                )
            }
        }
    }
}

@Composable
fun ScannedBinPanel(
    entries: List<ScannedCardEntry>,
    isSaving: Boolean,
    errorMessage: String?,
    statusMessage: String?,
    onDismiss: () -> Unit,
    onSaveOne: (ScannedCardEntry) -> Unit,
    onRemoveOne: (ScannedCardEntry) -> Unit,
    onSaveAll: () -> Unit,
    onClearAll: () -> Unit,
    onFoilChanged: (ScannedCardEntry, Boolean) -> Unit
) {
    AlertDialog(
        modifier = Modifier.testTag(TestTags.SCANNED_BIN_DIALOG),
        onDismissRequest = onDismiss,
        title = {
            Text("Scanned Card Bin")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                if (isSaving) {
                    Text(
                        text = "Saving...",
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                } else if (!statusMessage.isNullOrBlank()) {
                    Text(
                        text = statusMessage,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (entries.isEmpty()) {
                    Text(
                        text = "No scanned cards in the bin.",
                        modifier = Modifier.testTag(TestTags.SCANNED_BIN_EMPTY_TEXT)
                    )
                } else {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onSaveAll,
                            enabled = !isSaving,
                            modifier = Modifier.testTag(TestTags.SCANNED_BIN_SAVE_ALL)
                        ) {
                            Text("Save All")
                        }

                        Button(
                            onClick = onClearAll,
                            enabled = !isSaving,
                            modifier = Modifier.testTag(TestTags.SCANNED_BIN_CLEAR_ALL)
                        ) {
                            Text("Clear All")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        entries.forEach { entry ->
                            ScannedBinEntryRow(
                                entry = entry,
                                isSaving = isSaving,
                                onSave = { onSaveOne(entry) },
                                onRemove = { onRemoveOne(entry) },
                                onFoilChanged = { isFoil ->
                                    onFoilChanged(entry, isFoil)
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun ScannedBinEntryRow(
    entry: ScannedCardEntry,
    isSaving: Boolean,
    onSave: () -> Unit,
    onRemove: () -> Unit,
    onFoilChanged: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(TestTags.SCANNED_BIN_ENTRY_PREFIX + entry.localId)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = entry.card.name,
                style = MaterialTheme.typography.titleMedium
            )

            Text(
                text = entry.card.subtitle,
                style = MaterialTheme.typography.bodySmall
            )

            if (entry.card.hasFoilVariant) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = entry.isFoil,
                        onCheckedChange = onFoilChanged,
                        enabled = !isSaving,
                        modifier = Modifier.testTag(
                            TestTags.SCANNED_BIN_FOIL_PREFIX + entry.localId
                        )
                    )

                    Text("Foil")
                }
            } else {
                Text(
                    text = "Non-foil only",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    onClick = onSave,
                    enabled = !isSaving,
                    modifier = Modifier.testTag(
                        TestTags.SCANNED_BIN_SAVE_PREFIX + entry.localId
                    )
                ) {
                    Text("Add to Collection")
                }

                TextButton(
                    onClick = onRemove,
                    enabled = !isSaving,
                    modifier = Modifier.testTag(
                        TestTags.SCANNED_BIN_REMOVE_PREFIX + entry.localId
                    )
                ) {
                    Text("Remove")
                }
            }
        }
    }
}

@Preview
@Composable
fun ScanScreenPreview() {
    Surface {
        Text("Scan preview disabled: camera and repositories required.")
    }
}