package com.group9.tcgapp.viewmodel

import com.group9.tcgapp.data.repository.ScannedCardEntry

data class ScanUiState(
    val selectedGame: GameType = GameType.POKEMON,

    val recognizedText: String = "",
    val candidateCardName: String = "",

    val isSearching: Boolean = false,
    val isSaving: Boolean = false,
    val isFlashlightOn: Boolean = false,
    val errorMessage: String? = null,

    val possibleMatches: List<CardSearchResult> = emptyList(),
    val showSelectionDialog: Boolean = false,

    val showBinPanel: Boolean = false,
    val scannedBin: List<ScannedCardEntry> = emptyList(),
    val lastScanMessage: String = "Place a card in view."
)