package com.group9.tcgapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expansions")
data class ExpansionEntity(
    @PrimaryKey
    val id: String,
    val name: String?,
    val code: String?,
    val type: String?,
    val block: String?,
    val total: Int?,
    val releaseDate: String?,
    val isFoilOnly: Boolean?,
    val isOnlineOnly: Boolean?,
    val logoUrl: String?,
    val symbolUrl: String?
)

@Entity(
    tableName = "card_rules",
    primaryKeys = ["cardId", "ruleIndex"]
)
data class CardRuleEntity(
    val cardId: String,
    val ruleIndex: Int,
    val text: String
)

@Entity(
    tableName = "card_rulings",
    primaryKeys = ["cardId", "date", "text"]
)
data class CardRulingEntity(
    val cardId: String,
    val date: String,
    val text: String
)

@Entity(
    tableName = "card_types",
    primaryKeys = ["cardId", "type"]
)
data class CardTypeEntity(
    val cardId: String,
    val type: String
)

@Entity(
    tableName = "card_subtypes",
    primaryKeys = ["cardId", "subtype"]
)
data class CardSubtypeEntity(
    val cardId: String,
    val subtype: String
)

@Entity(
    tableName = "card_supertypes",
    primaryKeys = ["cardId", "supertype"]
)
data class CardSupertypeEntity(
    val cardId: String,
    val supertype: String
)

@Entity(
    tableName = "card_colors",
    primaryKeys = ["cardId", "color"]
)
data class CardColorEntity(
    val cardId: String,
    val color: String
)

@Entity(
    tableName = "card_color_identity",
    primaryKeys = ["cardId", "color"]
)
data class CardColorIdentityEntity(
    val cardId: String,
    val color: String
)

@Entity(
    tableName = "card_keywords",
    primaryKeys = ["cardId", "keyword"]
)
data class CardKeywordEntity(
    val cardId: String,
    val keyword: String
)
