package com.group9.tcgapp.viewmodel

enum class GameType {
    POKEMON,
    MTG
}

data class CardSearchResult(
    val id: String,
    val name: String,
    val subtitle: String,
    val imageUrl: String? = null,
    val game: GameType,
    val hasFoilVariant: Boolean = false
)

enum class SortOption {
    NAME_ASC,
    NAME_DESC,
    NUMBER_ASC,
    RARITY_ASC,
    RELEASE_DATE_DESC
}

enum class RarityOption(val label: String) {
    ANY("Any"),
    COMMON("Common"),
    UNCOMMON("Uncommon"),
    RARE("Rare"),
    MYTHIC("Mythic"),
    PROMO("Promo"),
    ULTRA_RARE("Ultra Rare"),
    SECRET_RARE("Secret Rare")
}

enum class LanguageOption(val label: String) {
    ANY("Any"),
    ENGLISH("English"),
    JAPANESE("Japanese"),
    GERMAN("German"),
    FRENCH("French"),
    ITALIAN("Italian"),
    SPANISH("Spanish"),
    PORTUGUESE("Portuguese"),
    KOREAN("Korean"),
    CHINESE("Chinese")
}

data class SharedSearchFilters(
    val query: String = "",
    val setNameOrCode: String = "",
    val cardNumber: String = "",
    val rarity: RarityOption = RarityOption.ANY,
    val language: LanguageOption = LanguageOption.ANY,
    val sort: SortOption = SortOption.NAME_ASC
)

enum class MtgColor(val symbol: String) {
    WHITE("W"),
    BLUE("U"),
    BLACK("B"),
    RED("R"),
    GREEN("G"),
    COLORLESS("C")
}

enum class MtgLayoutOption(val label: String) {
    ANY("Any"),
    NORMAL("Normal"),
    SPLIT("Split"),
    TRANSFORM("Transform"),
    MODAL_DFC("Modal DFC"),
    SAGA("Saga"),
    ADVENTURE("Adventure"),
    TOKEN("Token")
}

data class MtgFilters(
    val selectedColors: Set<MtgColor> = emptySet(),
    val selectedColorIdentity: Set<MtgColor> = emptySet(),
    val type: String = "",
    val subtype: String = "",
    val supertype: String = "",
    val keyword: String = "",
    val artist: String = "",
    val manaValueMin: Int? = null,
    val manaValueMax: Int? = null,
    val powerMin: Int? = null,
    val powerMax: Int? = null,
    val toughnessMin: Int? = null,
    val toughnessMax: Int? = null,
    val layout: MtgLayoutOption = MtgLayoutOption.ANY,
    val hasRulesText: Boolean = false
)

enum class PokemonTypeOption(val label: String) {
    ANY("Any"),
    GRASS("Grass"),
    FIRE("Fire"),
    WATER("Water"),
    LIGHTNING("Lightning"),
    PSYCHIC("Psychic"),
    FIGHTING("Fighting"),
    DARKNESS("Darkness"),
    METAL("Metal"),
    DRAGON("Dragon"),
    FAIRY("Fairy"),
    COLORLESS("Colorless")
}

enum class PokemonStageOption(val label: String) {
    ANY("Any"),
    BASIC("Basic"),
    STAGE1("Stage 1"),
    STAGE2("Stage 2")
}

data class PokemonFilters(
    val pokemonType: PokemonTypeOption = PokemonTypeOption.ANY,
    val stage: PokemonStageOption = PokemonStageOption.ANY,
    val subtype: String = "",
    val artist: String = "",
    val evolvesFrom: String = "",
    val hpMin: Int? = null,
    val hpMax: Int? = null,
    val weaknessType: PokemonTypeOption = PokemonTypeOption.ANY,
    val retreatCostMax: Int? = null,
    val hasAbility: Boolean = false,
    val hasAttack: Boolean = false,
    val hasRuleBox: Boolean = false
)
