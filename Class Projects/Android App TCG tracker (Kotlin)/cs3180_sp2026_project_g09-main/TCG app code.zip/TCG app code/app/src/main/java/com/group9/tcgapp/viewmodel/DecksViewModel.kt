package com.group9.tcgapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group9.tcgapp.data.local.dao.DeckDao
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.local.entity.DeckEntity
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.DeckRepository
import com.group9.tcgapp.data.repository.DeckRuleSet
import com.group9.tcgapp.data.repository.DeckUpdateResult
import com.group9.tcgapp.data.repository.isDeckSizeValid
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DecksViewModel(
	private val deckRepository: DeckRepository? = null,
	private val collectionRepository: CollectionRepository? = null
) : ViewModel() {

	var selectedCollection by mutableStateOf(CollectionGame.POKEMON)
		private set

	var decks by mutableStateOf<List<DeckEntity>>(emptyList())
		private set

	var selectedDeck by mutableStateOf<DeckEntity?>(null)
		private set

	var deckCards by mutableStateOf<List<DeckDao.DeckCardRow>>(emptyList())
		private set

	var availableCollectionCards by mutableStateOf<List<CardEntity>>(emptyList())
		private set

	var totalCardsInDeck by mutableStateOf(0)
		private set

	var deckCardCounts by mutableStateOf<Map<Long, Int>>(emptyMap())
		private set

	var deckSizeValidity by mutableStateOf<Map<Long, Boolean>>(emptyMap())
		private set

	var activeRules by mutableStateOf<DeckRuleSet?>(null)
		private set

	var statusMessage by mutableStateOf<String?>(null)
		private set

	var showCreateDeckDialog by mutableStateOf(false)
		private set

	var newDeckName by mutableStateOf("")
		private set

	private var observeDecksJob: Job? = null
	private var observeDeckDetailsJob: Job? = null
	private var observeDeckTotalJob: Job? = null
	private var observeCollectionCardsJob: Job? = null

	init {
		if (deckRepository != null && collectionRepository != null) {
			observeDecks()
			observeCollectionCards()
			activeRules = deckRepository.getRulesForGame(selectedCollection.apiPath)
		}
	}

	fun onCollectionSelected(game: CollectionGame) {
		if (selectedCollection == game) {
			return
		}

		selectedCollection = game
		selectedDeck = null
		deckCards = emptyList()
		totalCardsInDeck = 0
		activeRules = deckRepository?.getRulesForGame(selectedCollection.apiPath)

		observeDecks()
		observeCollectionCards()
	}

	private fun observeDecks() {
		val repository = deckRepository ?: return

		observeDecksJob?.cancel()
		observeDecksJob = viewModelScope.launch {
			repository.getDeckSummariesByGameFlow(selectedCollection.apiPath).collectLatest { summaries ->
				decks = summaries.map { summary ->
					DeckEntity(
						deckId = summary.deckId,
						gameType = summary.gameType,
						name = summary.name,
						description = summary.description,
						createdAt = summary.createdAt
					)
				}

				val counts = mutableMapOf<Long, Int>()
				val validity = mutableMapOf<Long, Boolean>()
				summaries.forEach { summary ->
					counts[summary.deckId] = summary.totalCards
					val rules = repository.getRulesForGame(summary.gameType)
					validity[summary.deckId] = rules.isDeckSizeValid(summary.totalCards)
				}

				deckCardCounts = counts
				deckSizeValidity = validity
			}
		}
	}

	private fun observeCollectionCards() {
		val repository = collectionRepository ?: return

		observeCollectionCardsJob?.cancel()
		observeCollectionCardsJob = viewModelScope.launch {
			repository.getOwnedCardsByGameFlow(selectedCollection.apiPath).collectLatest { cards ->
				availableCollectionCards = cards
			}
		}
	}

	fun onDeckSelected(deckId: Long) {
		val repository = deckRepository ?: return
		val deck = decks.firstOrNull { it.deckId == deckId } ?: return

		selectedDeck = deck
		activeRules = repository.getRulesForGame(deck.gameType)

		observeDeckDetailsJob?.cancel()
		observeDeckDetailsJob = viewModelScope.launch {
			repository.getDeckCardRowsFlow(deckId).collectLatest { rows ->
				deckCards = rows
			}
		}

		observeDeckTotalJob?.cancel()
		observeDeckTotalJob = viewModelScope.launch {
			repository.getTotalCardCountForDeckFlow(deckId).collectLatest { total ->
				totalCardsInDeck = total
			}
		}
	}

	fun clearSelectedDeck() {
		selectedDeck = null
		deckCards = emptyList()
		totalCardsInDeck = 0
		activeRules = deckRepository?.getRulesForGame(selectedCollection.apiPath)
		observeDeckDetailsJob?.cancel()
		observeDeckTotalJob?.cancel()
	}

	fun openCreateDeckDialog() {
		showCreateDeckDialog = true
		newDeckName = ""
	}

	fun dismissCreateDeckDialog() {
		showCreateDeckDialog = false
		newDeckName = ""
	}

	fun onNewDeckNameChanged(value: String) {
		newDeckName = value
	}

	fun createDeck() {
		val repository = deckRepository ?: return
		val name = newDeckName.trim()

		if (name.isBlank()) {
			statusMessage = "Enter a deck name."
			return
		}

		viewModelScope.launch {
			repository.createDeck(
				gameType = selectedCollection.apiPath,
				name = name
			)
			statusMessage = "Created deck: $name"
			dismissCreateDeckDialog()
		}
	}

	fun addCardToSelectedDeck(cardId: String) {
		val repository = deckRepository ?: return
		val deckId = selectedDeck?.deckId ?: return

		viewModelScope.launch {
			statusMessage = when (val result = repository.addOneCopy(deckId, cardId)) {
				DeckUpdateResult.Success -> "Card added to deck."
				is DeckUpdateResult.CardNotOwned -> "Only cards in your collection can be added."
				is DeckUpdateResult.ExceedsDeckSize -> "Deck limit reached (${result.limit})."
				is DeckUpdateResult.ExceedsOwnedCopies -> "You only own ${result.ownedCopies} copy/copies."
				is DeckUpdateResult.ExceedsPerCardLimit -> "Per-card limit reached (${result.limit})."
				is DeckUpdateResult.DeckNotFound -> "Deck no longer exists."
			}
		}
	}

	fun removeOneFromSelectedDeck(cardId: String) {
		val repository = deckRepository ?: return
		val deckId = selectedDeck?.deckId ?: return

		viewModelScope.launch {
			repository.removeOneCopy(deckId, cardId)
			statusMessage = "Card quantity updated."
		}
	}

	fun deleteDeck(deckId: Long) {
		val repository = deckRepository ?: return

		viewModelScope.launch {
			repository.deleteDeck(deckId)
			if (selectedDeck?.deckId == deckId) {
				clearSelectedDeck()
			}
			statusMessage = "Deck deleted."
		}
	}

	fun clearStatusMessage() {
		statusMessage = null
	}

	fun selectedDeckIsValid(): Boolean {
		val deck = selectedDeck ?: return false
		val rules = activeRules ?: return false
		return rules.isDeckSizeValid(totalCardsInDeck) && (deckSizeValidity[deck.deckId] ?: false)
	}
}