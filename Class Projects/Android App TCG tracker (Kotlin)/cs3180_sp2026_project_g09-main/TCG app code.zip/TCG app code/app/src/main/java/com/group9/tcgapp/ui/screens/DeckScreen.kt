package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.group9.tcgapp.CardCollectionApplication
import com.group9.tcgapp.viewmodel.CollectionGame
import com.group9.tcgapp.viewmodel.DecksViewModel
import com.group9.tcgapp.ui.AppRoute
import androidx.navigation.NavHostController
import com.group9.tcgapp.ui.theme.rememberBinderTileColors
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private enum class DeckCardSortOption(val label: String) {
    NAME_ASC("Name A-Z"),
    NAME_DESC("Name Z-A"),
    QTY_DESC("Quantity high-low")
}

@Composable
fun DecksScreen(
    navController: NavHostController,
    decksViewModel: DecksViewModel? = null
) {
    val context = LocalContext.current.applicationContext as CardCollectionApplication
    val resolvedViewModel = decksViewModel ?: viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(DecksViewModel::class.java)) {
                    return DecksViewModel(
                        deckRepository = context.container.deckRepository,
                        collectionRepository = context.container.collectionRepository
                    ) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        }
    )

    val statusMessage = resolvedViewModel.statusMessage
    var showDeleteDeckConfirm by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var selectedSortOption by remember { mutableStateOf(DeckCardSortOption.NAME_ASC) }

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            delay(3500)
            if (resolvedViewModel.statusMessage == statusMessage) {
                resolvedViewModel.clearStatusMessage()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Decks", color = Color.White)
            }

            Row {
                IconButton(onClick = { navController.navigate(AppRoute.Settings.route) }) {
                    Icon(Icons.Default.Settings, contentDescription = "settings")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CollectionGame.entries.forEach { game ->
                FilterChip(
                    selected = resolvedViewModel.selectedCollection == game,
                    onClick = { resolvedViewModel.onCollectionSelected(game) },
                    label = { Text(game.label) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        statusMessage?.let {
            Text(it, color = Color(0xFF2E7D32))
            Spacer(Modifier.height(8.dp))
        }

        val selectedDeck = resolvedViewModel.selectedDeck
        if (selectedDeck == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${resolvedViewModel.selectedCollection.label} decks (${resolvedViewModel.decks.size})")
                TextButton(
                    onClick = resolvedViewModel::openCreateDeckDialog,
                    modifier = Modifier.background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        RoundedCornerShape(8.dp)
                    )
                ) {
                    Text("Add Deck")
                }
            }

            if (resolvedViewModel.decks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No decks yet. Create one to begin.")
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.heightIn(max = 600.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    itemsIndexed(
                        items = resolvedViewModel.decks,
                        key = { _, deck -> deck.deckId }
                    ) { index, deck ->
                        val tileColors = rememberBinderTileColors(index)
                        val cardCount = resolvedViewModel.deckCardCounts[deck.deckId] ?: 0
                        val rules = resolvedViewModel.activeRules
                        val minRequired = rules?.minMainDeckSize ?: 0
                        val sizeLabel = "$cardCount/$minRequired"
                        val isValid = resolvedViewModel.deckSizeValidity[deck.deckId] ?: false
                        val validityLabel = if (isValid) "valid" else "invalid"

                        Box(
                            modifier = Modifier
                                .aspectRatio(0.75f)
                                .border(2.dp, Color.Black, RoundedCornerShape(14.dp))
                                .background(tileColors.background, RoundedCornerShape(14.dp))
                                .clickable { resolvedViewModel.onDeckSelected(deck.deckId) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(8.dp)
                                    .fillMaxWidth()
                                    .background(tileColors.labelBackground, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.align(Alignment.Center),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = sizeLabel,
                                        color = tileColors.labelText,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = validityLabel,
                                        color = if (isValid) Color(0xFF2E7D32) else Color(0xFFB00020),
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = deck.name,
                                        color = tileColors.labelText,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = resolvedViewModel::clearSelectedDeck,
                    modifier = Modifier.background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        RoundedCornerShape(8.dp)
                    )
                ) {
                    Text("Back to Decks")
                }

                Button(
                    onClick = { showDeleteDeckConfirm = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB00020),
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete Deck")
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionBar()
            Spacer(Modifier.height(8.dp))

            Text(selectedDeck.name)

            resolvedViewModel.activeRules?.let { rules ->
                Text("Cards per deck")
                Text("${resolvedViewModel.totalCardsInDeck}/${rules.minMainDeckSize}")
                Text(if (resolvedViewModel.selectedDeckIsValid()) "valid" else "invalid")
                Text("Per-card limit: ${rules.maxCopiesPerCard}")
            }

            Spacer(Modifier.height(8.dp))
            SectionBar()
            Spacer(Modifier.height(12.dp))

            Text("Cards In Deck")
            if (resolvedViewModel.deckCards.isEmpty()) {
                Text("No cards in deck yet.")
            } else {
                resolvedViewModel.deckCards.forEach { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${row.cardName} x${row.quantityInDeck}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { resolvedViewModel.removeOneFromSelectedDeck(row.cardId) }) {
                                Text("-")
                            }
                            TextButton(onClick = { resolvedViewModel.addCardToSelectedDeck(row.cardId) }) {
                                Text("+")
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionBar()
            Spacer(Modifier.height(16.dp))

            Text("Card Preview")
            Box {
                TextButton(onClick = { sortMenuExpanded = true }) {
                    Text("Sort: ${selectedSortOption.label}")
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false }
                ) {
                    DeckCardSortOption.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.label) },
                            onClick = {
                                selectedSortOption = option
                                sortMenuExpanded = false
                            }
                        )
                    }
                }
            }

            val previewCards = when (selectedSortOption) {
                DeckCardSortOption.NAME_ASC -> resolvedViewModel.deckCards.sortedBy { it.cardName.lowercase() }
                DeckCardSortOption.NAME_DESC -> resolvedViewModel.deckCards.sortedByDescending { it.cardName.lowercase() }
                DeckCardSortOption.QTY_DESC -> resolvedViewModel.deckCards.sortedByDescending { it.quantityInDeck }
            }

            if (previewCards.isEmpty()) {
                Text("No preview cards to show.")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(previewCards, key = { it.cardId }) { row ->
                        Box(
                            modifier = Modifier
                                .aspectRatio(0.72f)
                                .border(1.dp, Color.Black, RoundedCornerShape(8.dp))
                                .background(Color.White, RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = row.imageSmall ?: row.imageMedium ?: row.imageLarge,
                                contentDescription = row.cardName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(Color(0xAA000000))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "x${row.quantityInDeck}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionBar()
            Spacer(Modifier.height(8.dp))

            Text("Add From Collection")
            if (resolvedViewModel.availableCollectionCards.isEmpty()) {
                Text("No owned cards available for this game.")
            } else {
                resolvedViewModel.availableCollectionCards.forEach { card ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(card.name)
                        TextButton(onClick = { resolvedViewModel.addCardToSelectedDeck(card.id) }) {
                            Text("Add")
                        }
                    }
                }
            }
        }
    }

    if (resolvedViewModel.showCreateDeckDialog) {
        AlertDialog(
            onDismissRequest = resolvedViewModel::dismissCreateDeckDialog,
            title = { Text("Create Deck") },
            text = {
                OutlinedTextField(
                    value = resolvedViewModel.newDeckName,
                    onValueChange = resolvedViewModel::onNewDeckNameChanged,
                    label = { Text("Deck name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = resolvedViewModel::createDeck) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = resolvedViewModel::dismissCreateDeckDialog) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDeleteDeckConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteDeckConfirm = false },
            title = { Text("Delete deck?") },
            text = { Text("This will permanently remove the deck and all of its card links.") },
            confirmButton = {
                Button(
                    onClick = {
                        resolvedViewModel.selectedDeck?.let { resolvedViewModel.deleteDeck(it.deckId) }
                        showDeleteDeckConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB00020),
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete Deck")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDeckConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SectionBar() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(4.dp)
            .background(Color.LightGray, RoundedCornerShape(2.dp))
    )
}
