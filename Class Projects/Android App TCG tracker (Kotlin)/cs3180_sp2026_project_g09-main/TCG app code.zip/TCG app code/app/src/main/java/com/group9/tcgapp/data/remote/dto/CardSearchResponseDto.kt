package com.group9.tcgapp.data.remote.dto

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CardSearchResponseDto(
    val data: List<CardDto>? = emptyList()
)