package com.group9.tcgapp.data.remote.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)

data class CardDto(
    val id: String,
    val name: String,

    val supertypes: List<String> = emptyList(),
    val subtypes: List<String> = emptyList(),
    val types: List<String> = emptyList(),

    val type: String? = null,
    val number: String? = null,

    @Json(name = "color_identity")
    val colorIdentity: List<String> = emptyList(),

    val colors: List<String> = emptyList(),

    @Json(name = "mana_cost")
    val manaCost: String? = null,

    @Json(name = "mana_value")
    val manaValue: Int? = null,

    val power: String? = null,
    val toughness: String? = null,

    val rules: List<String> = emptyList(),
    val rarity: String? = null,
    val artist: String? = null,
    val keywords: List<String> = emptyList(),
    val layout: String? = null,
    val faces: List<CardFaceDto> = emptyList(),
    val images: List<CardImageDto> = emptyList(),
    val variants: List<CardVariantDto> = emptyList(),
    val rulings: List<CardRulingDto> = emptyList(),
    val expansion: ExpansionDto? = null,
    val language: String? = null,

    @Json(name = "language_code")
    val languageCode: String? = null,

    @Json(name = "expansion_sort_order")
    val expansionSortOrder: Int? = null
)

@JsonClass(generateAdapter = true)
data class CardFaceDto(
    val name: String? = null,
    val type: String? = null,
    @Json(name = "mana_cost")
    val manaCost: String? = null,
    val power: String? = null,
    val toughness: String? = null,
    val rules: List<String> = emptyList(),
    val images: List<CardImageDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class CardImageDto(
    val type: String? = null,
    val small: String? = null,
    val medium: String? = null,
    val large: String? = null
)

@JsonClass(generateAdapter = true)
data class CardVariantDto(
    val name: String? = null,
    val images: List<CardImageDto> = emptyList(),

    @Json(name = "border_color")
    val borderColor: String? = null
)

@JsonClass(generateAdapter = true)
data class CardRulingDto(
    val date: String? = null,
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class ExpansionDto(
    val id: String,
    val name: String? = null,
    val code: String? = null,
    val type: String? = null,
    val block: String? = null,
    val total: Int? = null,
    @Json(name = "release_date")
    val releaseDate: String? = null,
    @Json(name = "is_foil_only")
    val isFoilOnly: Boolean? = null,
    @Json(name = "is_online_only")
    val isOnlineOnly: Boolean? = null,
    val logo: String? = null,
    val symbol: String? = null
)