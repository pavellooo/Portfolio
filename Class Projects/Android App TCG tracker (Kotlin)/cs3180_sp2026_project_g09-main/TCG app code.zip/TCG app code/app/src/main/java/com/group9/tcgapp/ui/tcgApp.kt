package com.group9.tcgapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navOptions
import androidx.navigation.navArgument
import androidx.compose.ui.draw.shadow
import com.group9.tcgapp.CardCollectionApplication
import com.group9.tcgapp.data.local.entity.BinderEntity
import com.group9.tcgapp.data.local.entity.CardWithDetails
import com.group9.tcgapp.data.repository.BinderRepository
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.ui.theme.TCGAppTheme
import com.group9.tcgapp.ui.theme.CardTileLabelBackground
import com.group9.tcgapp.ui.theme.CardTileLabelText
import com.group9.tcgapp.ui.theme.CardTileSurface
import com.group9.tcgapp.ui.theme.rememberBinderTileColors
import com.group9.tcgapp.ui.screens.DecksScreen
import com.group9.tcgapp.ui.screens.SearchScreen
import com.group9.tcgapp.ui.screens.ScanScreen
import coil.compose.AsyncImage
import com.group9.tcgapp.viewmodel.CollectionGame
import com.group9.tcgapp.viewmodel.CollectionViewModel
import com.group9.tcgapp.viewmodel.DecksViewModel
import com.group9.tcgapp.viewmodel.HomeViewModel
import com.group9.tcgapp.viewmodel.PreviewViewModel
import com.group9.tcgapp.viewmodel.ScanViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

sealed class AppRoute(val route: String) {
    object Home : AppRoute("home")
    object Search : AppRoute("search")
    object Collection : AppRoute("collection")
    object Binder : AppRoute("binder")
    object Card : AppRoute("card")
    object Decks : AppRoute("decks")
    object Scan : AppRoute("scan")
    object Preview : AppRoute("preview")
    object Settings : AppRoute("settings")
}

@Composable
fun tcgApp() {
    val navController = rememberNavController()
    val context = LocalContext.current.applicationContext as CardCollectionApplication
    
    val homeViewModel: HomeViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return HomeViewModel(
                    collectionRepository = context.container.collectionRepository,
                    binderRepository = context.container.binderRepository,
                    deckRepository = context.container.deckRepository
                ) as T
            }
        }
    )

    Scaffold(
        topBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsTopHeight(WindowInsets.statusBars),
                color = MaterialTheme.colorScheme.surface
            ) {}
        },
        bottomBar = {
            BottomNavBar(navController)
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = AppRoute.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(AppRoute.Home.route) { HomeScreen(navController, homeViewModel) }
            composable(AppRoute.Search.route) { SearchScreen() }
            composable(AppRoute.Collection.route) { CollectionScreen(navController) }
            composable(
                route = "${AppRoute.Binder.route}/{binderId}",
                arguments = listOf(navArgument("binderId") { type = NavType.LongType })
            ) { backStackEntry ->
                val binderId = backStackEntry.arguments?.getLong("binderId") ?: -1L
                BinderDetailScreen(
                    binderId = binderId,
                    navController = navController
                )
            }
            composable(
                route = "${AppRoute.Card.route}/{cardId}?fromBinder={fromBinder}",
                arguments = listOf(
                    navArgument("cardId") { type = NavType.StringType },
                    navArgument("fromBinder") {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                )
            ) { backStackEntry ->
                val cardId = backStackEntry.arguments?.getString("cardId").orEmpty()
                val fromBinder = backStackEntry.arguments?.getBoolean("fromBinder") ?: false
                CardPreviewScreen(
                    cardId = cardId,
                    allowAddToBinder = !fromBinder,
                    navController = navController
                )
            }
            composable(AppRoute.Decks.route) { DecksScreen(navController = navController) }
            composable(AppRoute.Scan.route) { ScanScreen(navController = navController) }
            composable(AppRoute.Preview.route) { PreviewScreen() }
            composable(AppRoute.Settings.route) { SettingsScreen(navController) }
        }
    }
}

data class BinderDetailUiState(
    val binder: BinderEntity? = null,
    val cards: List<com.group9.tcgapp.data.local.entity.CardEntity> = emptyList(),
    val cardQuantities: Map<String, Int> = emptyMap(),
    val binderName: String = "",
    val statusMessage: String? = null
)

class BinderDetailViewModel(
    private val binderRepository: BinderRepository,
    private val collectionRepository: CollectionRepository,
    private val binderId: Long
) : ViewModel() {
    private val _uiState = MutableStateFlow(BinderDetailUiState())
    val uiState: StateFlow<BinderDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            binderRepository.getBinderWithCardsFlow(binderId).collectLatest { binderWithCards ->
                val cards = binderWithCards?.cards.orEmpty()
                _uiState.value = BinderDetailUiState(
                    binder = binderWithCards?.binder,
                    cards = cards,
                    binderName = binderWithCards?.binder?.name.orEmpty(),
                    statusMessage = _uiState.value.statusMessage
                )

                // Fetch collection quantities for each card in the binder
                cards.forEach { card ->
                    launch {
                        collectionRepository.getCollectionEntryFlow(card.id).collectLatest { entry ->
                            val updatedQuantities = _uiState.value.cardQuantities.toMutableMap()
                            updatedQuantities[card.id] = entry?.quantityOwned ?: 1
                            _uiState.value = _uiState.value.copy(cardQuantities = updatedQuantities)
                        }
                    }
                }
            }
        }
    }

    fun onBinderNameChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            binderName = value,
            statusMessage = null
        )
    }

    fun renameBinder() {
        val current = _uiState.value
        val name = current.binderName.trim()

        if (name.isBlank()) {
            _uiState.value = current.copy(statusMessage = "Enter a binder name.")
            return
        }

        viewModelScope.launch {
            binderRepository.renameBinder(
                binderId = binderId,
                name = name,
                description = current.binder?.description
            )
            _uiState.value = _uiState.value.copy(statusMessage = "Binder renamed.")
        }
    }

    fun deleteBinder(onDeleted: () -> Unit) {
        viewModelScope.launch {
            binderRepository.deleteBinder(binderId)
            onDeleted()
        }
    }
}

data class CardPreviewUiState(
    val cardWithDetails: CardWithDetails? = null,
    val binders: List<BinderEntity> = emptyList(),
    val linkedBinderIds: Set<Long> = emptySet(),
    val ownedQuantity: Int = 0,
    val selectedBinderIds: Set<Long> = emptySet(),
    val showAddToBinderDialog: Boolean = false,
    val statusMessage: String? = null
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class CardPreviewViewModel(
    private val cardRepository: CardRepository,
    private val binderRepository: BinderRepository,
    private val collectionRepository: CollectionRepository,
    private val cardId: String
) : ViewModel() {
    private val _uiState = MutableStateFlow(CardPreviewUiState())
    val uiState: StateFlow<CardPreviewUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            cardRepository.getCardDetailsFlow(cardId).collectLatest { cardWithDetails ->
                _uiState.value = _uiState.value.copy(
                    cardWithDetails = cardWithDetails,
                    statusMessage = null
                )
            }
        }

        viewModelScope.launch {
            cardRepository.getCardDetailsFlow(cardId)
                .map { details -> details?.card?.game }
                .filterNotNull()
                .distinctUntilChanged()
                .flatMapLatest { gameType -> binderRepository.getBindersByGameFlow(gameType) }
                .collectLatest { values ->
                    _uiState.value = _uiState.value.copy(binders = values)
                }
        }

        viewModelScope.launch {
            binderRepository.getBinderIdsForCardFlow(cardId).collectLatest { binderIds ->
                _uiState.value = _uiState.value.copy(linkedBinderIds = binderIds.toSet())
            }
        }

        viewModelScope.launch {
            collectionRepository.getCollectionEntryFlow(cardId).collectLatest { entry ->
                _uiState.value = _uiState.value.copy(ownedQuantity = entry?.quantityOwned ?: 0)
            }
        }
    }

    fun incrementQuantity() {
        viewModelScope.launch {
            collectionRepository.incrementOwnedQuantity(cardId)
        }
    }

    fun decrementQuantity() {
        val current = _uiState.value.ownedQuantity
        if (current > 1) {
            viewModelScope.launch {
                collectionRepository.decrementOwnedQuantity(cardId)
                _uiState.value = _uiState.value.copy(statusMessage = "Quantity updated.")
            }
        } else {
            _uiState.value = _uiState.value.copy(statusMessage = "Minimum quantity is 1. Use 'Remove' to delete.")
        }
    }

    fun openAddToBinderDialog() {
        if (_uiState.value.binders.isEmpty()) {
            _uiState.value = _uiState.value.copy(statusMessage = "Create a binder first.")
            return
        }

        _uiState.value = _uiState.value.copy(
            showAddToBinderDialog = true,
            selectedBinderIds = _uiState.value.linkedBinderIds,
            statusMessage = null
        )
    }

    fun dismissAddToBinderDialog() {
        _uiState.value = _uiState.value.copy(
            showAddToBinderDialog = false,
            selectedBinderIds = emptySet()
        )
    }

    fun toggleBinderSelection(binderId: Long) {
        val current = _uiState.value.selectedBinderIds.toMutableSet()
        if (binderId in current) current.remove(binderId) else current.add(binderId)

        _uiState.value = _uiState.value.copy(selectedBinderIds = current)
    }

    fun addCardToSelectedBinders() {
        val binderIds = _uiState.value.selectedBinderIds.toList()
        val linkedBinderIds = _uiState.value.linkedBinderIds
        val bindersById = _uiState.value.binders.associateBy { it.binderId }

        viewModelScope.launch {
            bindersById.keys.forEach { binderIdValue ->
                val shouldBeLinked = binderIdValue in binderIds
                val isLinked = binderIdValue in linkedBinderIds

                when {
                    shouldBeLinked && !isLinked -> binderRepository.addCardToBinder(binderIdValue, cardId)
                    !shouldBeLinked && isLinked -> binderRepository.removeCardFromBinder(binderIdValue, cardId)
                }
            }

            _uiState.value = _uiState.value.copy(
                showAddToBinderDialog = false,
                selectedBinderIds = emptySet(),
                statusMessage = when {
                    binderIds.isEmpty() && linkedBinderIds.isNotEmpty() -> "Removed from binders."
                    binderIds.isNotEmpty() && linkedBinderIds.isEmpty() -> "Added to ${binderIds.size} binder(s)."
                    else -> "Binder links updated."
                }
            )
        }
    }

    fun removeFromCollection() {
        val quantity = _uiState.value.ownedQuantity
        if (quantity <= 0) {
            _uiState.value = _uiState.value.copy(statusMessage = "Card is not in your collection.")
            return
        }

        viewModelScope.launch {
            collectionRepository.decrementOwnedQuantity(cardId)
            val remaining = (quantity - 1).coerceAtLeast(0)

            if (remaining == 0) {
                cardRepository.deleteCardAndRelated(cardId)
            }

            _uiState.value = _uiState.value.copy(
                statusMessage = if (remaining == 0) {
                    "Removed card and related data."
                } else {
                    "Collection quantity: $remaining"
                }
            )
        }
    }
}

@Composable
fun BottomNavBar(navController: NavHostController) {
    val currentDestination = navController.currentBackStackEntryAsState().value?.destination

    fun navigateTo(route: String) {
        if (navController.popBackStack(route, false)) {
            return
        }

        navController.navigate(route, navOptions {
            launchSingleTop = true
            restoreState = true
            popUpTo(navController.graph.startDestinationId) {
                saveState = true
            }
        })
    }

    NavigationBar {
        NavigationBarItem(
            selected = currentDestination?.route == AppRoute.Home.route,
            onClick = { navigateTo(AppRoute.Home.route) },
            label = { Text("Home") },
            icon = {}
        )

        NavigationBarItem(
            selected = currentDestination?.route == AppRoute.Search.route,
            onClick = { navigateTo(AppRoute.Search.route) },
            label = { Text("Search") },
            icon = {}
        )

        NavigationBarItem(
            selected = currentDestination?.route == AppRoute.Collection.route,
            onClick = { navigateTo(AppRoute.Collection.route) },
            label = { Text("Collection") },
            icon = {}
        )

        NavigationBarItem(
            selected = currentDestination?.route == AppRoute.Decks.route,
            onClick = { navigateTo(AppRoute.Decks.route) },
            label = { Text("Decks") },
            icon = {}
        )

        NavigationBarItem(
            selected = currentDestination?.route == AppRoute.Scan.route,
            onClick = { navigateTo(AppRoute.Scan.route) },
            label = { Text("Scan") },
            icon = {}
        )
    }
}

@Composable
fun HomeScreen(
    navController: NavHostController = rememberNavController(),
    homeViewModel: HomeViewModel
) {
    val uiState by homeViewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Home", color = Color.White)
            }

            Row {
                IconButton(onClick = { navController.navigate(AppRoute.Settings.route) }) {
                    Icon(Icons.Default.Settings, contentDescription = "settings")
                }
            }
        }

//        Spacer(modifier = Modifier.height(20.dp))
//
//        TextField(
//            value = homeViewModel.searchText,
//            onValueChange = { homeViewModel.onSearchTextChanged(it) },
//            placeholder = { Text("Search") },
//            modifier = Modifier.fillMaxWidth()
//        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ShortcutCard(
                title = "Recent Binder",
                name = uiState.recentBinder?.first?.name ?: "No Binders",
                count = uiState.recentBinder?.second ?: 0,
                modifier = Modifier.weight(1f),
                onClick = { uiState.recentBinder?.let { navController.navigate("${AppRoute.Binder.route}/${it.first.binderId}") } }
            )
            ShortcutCard(
                title = "Recent Deck",
                name = uiState.recentDeck?.first?.name ?: "No Decks",
                count = uiState.recentDeck?.second ?: 0,
                modifier = Modifier.weight(1f),
                onClick = { navController.navigate(AppRoute.Decks.route) }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("Collection Stats", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatRow("Total Owned", "${uiState.totalCards} Cards")
            StatRow("Pokemon", "${uiState.pokemonCount}")
            StatRow("Magic: The Gathering", "${uiState.mtgCount}")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("Your Binders", style = MaterialTheme.typography.titleSmall)
        uiState.binders.forEach { (binder, count) ->
            StatListItem(
                name = binder.name,
                count = "$count cards",
                onClick = { navController.navigate("${AppRoute.Binder.route}/${binder.binderId}") }
            )
        }
        if (uiState.binders.isEmpty()) Text("No binders created.", color = Color.Gray, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text("Your Decks", style = MaterialTheme.typography.titleSmall)
        uiState.decks.forEach { (deck, count) ->
            StatListItem(
                name = deck.name,
                count = "$count cards",
                onClick = { navController.navigate(AppRoute.Decks.route) }
            )
        }
        if (uiState.decks.isEmpty()) Text("No decks created.", color = Color.Gray, fontSize = 12.sp)
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun ShortcutCard(
    title: String,
    name: String,
    count: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(4.dp))
        Text(name, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("$count cards", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatListItem(name: String, count: String, onClick: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("• $name", modifier = Modifier.weight(1f))
        Text(count, color = Color.Gray, fontSize = 14.sp)
    }
}

//
//@Composable
//fun SearchScreen(searchViewModel: SearchViewModel = viewModel()) {
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(16.dp)
//    ) {
//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.SpaceBetween
//        ) {
//            Box(
//                modifier = Modifier
//                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
//                    .padding(horizontal = 16.dp, vertical = 8.dp)
//            ) {
//                Text("Search", color = Color.White)
//            }
//
//            Row {
//                Icon(Icons.Default.Settings, contentDescription = "settings")
//                Spacer(Modifier.width(12.dp))
//                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
//            }
//        }
//
//        Spacer(modifier = Modifier.height(16.dp))
//
//        Text("Game")
//        Spacer(modifier = Modifier.height(8.dp))
//        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
//            listItems(searchViewModel.availableGames) { game ->
//                FilterChip(
//                    selected = game == searchViewModel.selectedGame,
//                    onClick = { searchViewModel.selectGame(game) },
//                    label = { Text(game) }
//                )
//            }
//        }
//
//        Spacer(modifier = Modifier.height(12.dp))
//
//        TextField(
//            value = searchViewModel.query,
//            onValueChange = { searchViewModel.onQueryChanged(it) },
//            placeholder = { Text("Search") },
//            modifier = Modifier.fillMaxWidth(),
//            trailingIcon = {
//                if (searchViewModel.query.isNotBlank()) {
//                    IconButton(onClick = { searchViewModel.clearQuery() }) {
//                        Icon(Icons.Default.Clear, contentDescription = "clear search")
//                    }
//                }
//            }
//        )
//
//        Spacer(modifier = Modifier.height(16.dp))
//
//        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
//            Button(onClick = { searchViewModel.filterByLabel() }) {
//                Text("Label")
//            }
//            Button(onClick = { searchViewModel.filterByValue() }) {
//                Text("Value")
//            }
//        }
//
//        Spacer(modifier = Modifier.height(10.dp))
//
//        if (searchViewModel.filterMode == "Label") {
//            Text("Labels")
//            Spacer(modifier = Modifier.height(8.dp))
//            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
//                listItems(searchViewModel.availableLabels) { label ->
//                    FilterChip(
//                        selected = label in searchViewModel.selectedLabels,
//                        onClick = { searchViewModel.toggleLabel(label) },
//                        label = { Text(label) }
//                    )
//                }
//            }
//        } else {
//            Text(
//                "Value: ${searchViewModel.selectedValueRange.start.toInt()}-${searchViewModel.selectedValueRange.endInclusive.toInt()}"
//            )
//            RangeSlider(
//                value = searchViewModel.selectedValueRange,
//                onValueChange = { searchViewModel.onValueRangeChanged(it) },
//                valueRange = 0f..searchViewModel.maxCardValue
//            )
//        }
//
//        Spacer(modifier = Modifier.height(10.dp))
//
//        Text("Results: ${searchViewModel.resultCount}")
//
//        Spacer(modifier = Modifier.height(12.dp))
//
//        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
//            listItems(searchViewModel.filteredResults, key = { it.id }) { card ->
//                Box(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .background(Color.LightGray, RoundedCornerShape(8.dp))
//                        .padding(12.dp)
//                ) {
//                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
//                        Text("${card.name} (${card.setName})")
//                        Text("Game: ${card.game}")
//                        Text("Labels: ${card.labels.joinToString()}")
//                        Text("Value: ${card.value}")
//                    }
//                }
//            }
//        }
//    }
//}

@Composable
fun CollectionScreen(navController: NavHostController) {
    val context = LocalContext.current.applicationContext as CardCollectionApplication

    val collectionViewModel: CollectionViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(CollectionViewModel::class.java)) {
                    return CollectionViewModel(
                        collectionRepository = context.container.collectionRepository,
                        binderRepository = context.container.binderRepository
                    ) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        }
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val statusMessage = collectionViewModel.statusMessage

        LaunchedEffect(statusMessage) {
            if (statusMessage != null) {
                delay(5000)
                if (collectionViewModel.statusMessage == statusMessage) {
                    collectionViewModel.clearStatusMessage()
                }
            }
        }

        AnimatedVisibility(
            visible = statusMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
                .padding(horizontal = 16.dp)
                .shadow(8.dp, RoundedCornerShape(16.dp))
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFFE8F5E9), RoundedCornerShape(16.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(statusMessage.orEmpty(), color = Color(0xFF2E7D32))
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text("Collection", color = Color.White)
                    }

                    Row {
                        IconButton(onClick = { navController.navigate(AppRoute.Settings.route) }) {
                            Icon(Icons.Default.Settings, contentDescription = "settings")
                        }
                        //Spacer(Modifier.width(12.dp))
                        //Icon(Icons.Default.AccountCircle, contentDescription = "profile")
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .border(2.dp, Color.Black, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Favorite, contentDescription = "image")
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CollectionGame.entries.forEach { game ->
                        FilterChip(
                            selected = collectionViewModel.selectedCollection == game,
                            onClick = { collectionViewModel.onCollectionSelected(game) },
                            label = { Text(game.label) }
                        )
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Total binders: ${collectionViewModel.binders.size}")

                    TextButton(onClick = collectionViewModel::openCreateBinderDialog) {
                        Text("Add Binder")
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(collectionViewModel.bindersTitle)
            }

            if (collectionViewModel.binders.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .border(2.dp, Color.Black, RoundedCornerShape(12.dp))
                            .clickable { collectionViewModel.openCreateBinderDialog() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("+ Binder")
                    }
                }
            } else {
                gridItemsIndexed(
                    items = collectionViewModel.binders,
                    key = { _, binder -> binder.binderId }
                ) { index, binder ->
                    val tileColors = rememberBinderTileColors(index)
                    val cardCount = collectionViewModel.binderCardCounts[binder.binderId] ?: 0

                    Box(
                        modifier = Modifier
                            .aspectRatio(0.72f)
                            .border(2.dp, Color.Black, RoundedCornerShape(14.dp))
                            .background(tileColors.background, RoundedCornerShape(14.dp))
                            .clickable { navController.navigate("${AppRoute.Binder.route}/${binder.binderId}") }
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(8.dp)
                                .fillMaxWidth()
                                .background(tileColors.labelBackground, RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "$cardCount cards",
                                    color = tileColors.labelText,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = binder.name,
                                    color = tileColors.labelText
                                )
                            }
                        }
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Color.LightGray, RoundedCornerShape(4.dp))
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.LightGray)
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(collectionViewModel.collectionValue)
                }
            }

            if (collectionViewModel.cardsInCollection.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("No saved cards in this collection yet.")
                }
            } else {
                gridItems(
                    items = collectionViewModel.cardsInCollection,
                    key = { card -> card.id }
                ) { card ->
                    CardThumbnailTile(
                        name = card.name,
                        imageModel = card.imageSmall ?: card.imageMedium ?: card.imageLarge,
                        onClick = {
                            navController.navigate("${AppRoute.Card.route}/${card.id}?fromBinder=false")
                        }
                    )
                }
            }

        }

        if (collectionViewModel.showCreateBinderDialog) {
            CreateBinderDialog(
                binderName = collectionViewModel.newBinderName,
                onBinderNameChanged = collectionViewModel::onNewBinderNameChanged,
                onDismiss = collectionViewModel::dismissCreateBinderDialog,
                onConfirm = collectionViewModel::createBinder
            )
        }
    }
}

@Composable
fun BinderDetailScreen(
    binderId: Long,
    navController: NavHostController
) {
    val context = LocalContext.current.applicationContext as CardCollectionApplication

    val binderViewModel: BinderDetailViewModel = viewModel(
        key = "binder-$binderId",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(BinderDetailViewModel::class.java)) {
                    return BinderDetailViewModel(
                        binderRepository = context.container.binderRepository,
                        collectionRepository = context.container.collectionRepository,
                        binderId = binderId
                    ) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        }
    )

    val uiState by binderViewModel.uiState.collectAsStateWithLifecycle()
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.background(
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    RoundedCornerShape(8.dp)
                )
            ) {
                Text("Back")
            }

            Text("Binder Details")

            TextButton(onClick = { showDeleteConfirm = true }) {
                Text("Delete")
            }
        }

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = uiState.binderName,
            onValueChange = binderViewModel::onBinderNameChanged,
            label = { Text("Binder name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Button(onClick = binderViewModel::renameBinder) {
            Text("Rename Binder")
        }

        uiState.statusMessage?.let { status ->
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color(0xFF2E7D32))
        }

        Spacer(Modifier.height(20.dp))

        val expandedCards = remember(uiState.cards, uiState.cardQuantities) {
            uiState.cards.flatMap { card ->
                List(uiState.cardQuantities[card.id] ?: 1) { card }
            }
        }

        Text("Unique cards: ${uiState.cards.size}")
        Text("Total cards: ${expandedCards.size}")

        Spacer(Modifier.height(12.dp))

        if (uiState.cards.isEmpty()) {
            Text("No cards in this binder yet.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                gridItemsIndexed(expandedCards, key = { index, card -> "${card.id}-$index" }) { _, card ->
                    CardThumbnailTile(
                        name = card.name,
                        imageModel = card.imageSmall ?: card.imageMedium ?: card.imageLarge,
                        onClick = {
                            navController.navigate("${AppRoute.Card.route}/${card.id}?fromBinder=true")
                        }
                    )
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete binder?") },
            text = { Text("This will remove the binder and its card links.") },
            confirmButton = {
                Button(onClick = { binderViewModel.deleteBinder { navController.popBackStack() } }) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CardPreviewScreen(
    cardId: String,
    allowAddToBinder: Boolean,
    navController: NavHostController
) {
    val context = LocalContext.current.applicationContext as CardCollectionApplication

    val viewModel: CardPreviewViewModel = viewModel(
        key = "card-$cardId",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(CardPreviewViewModel::class.java)) {
                    return CardPreviewViewModel(
                        cardRepository = context.container.cardRepository,
                        binderRepository = context.container.binderRepository,
                        collectionRepository = context.container.collectionRepository,
                        cardId = cardId
                    ) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        }
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.background(
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    RoundedCornerShape(8.dp)
                )
            ) {
                Text("Back")
            }

            Text("Card Preview")

            if (allowAddToBinder) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = viewModel::removeFromCollection,
                        modifier = Modifier.background(
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                            RoundedCornerShape(8.dp)
                        )
                    ) {
                        Text("Remove")
                    }
                    TextButton(
                        onClick = viewModel::openAddToBinderDialog,
                        modifier = Modifier.background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                    ) {
                        Text("Add to Binder")
                    }
                }
            } else {
                TextButton(
                    onClick = viewModel::removeFromCollection,
                    modifier = Modifier.background(
                        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                        RoundedCornerShape(8.dp)
                    )
                ) {
                    Text("Remove")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        val cardWithDetails = uiState.cardWithDetails
        val card = cardWithDetails?.card
        if (card == null) {
            Text("Card not found.")
        } else {
            AsyncImage(
                model = card.imageLarge ?: card.imageMedium ?: card.imageSmall,
                contentDescription = card.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .border(2.dp, Color.Black, RoundedCornerShape(16.dp))
                    .background(Color.White),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(16.dp))

            Text(card.name)
            Text(card.typeLine.orEmpty())
            Text("Rarity: ${card.rarity ?: "Unknown"}")
            Text("Set: ${cardWithDetails.expansion?.name ?: "Unknown"}")
            Text("Game: ${card.game}")
            Text("Collector #: ${card.number ?: "N/A"}")

            Spacer(Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("In collection: ${uiState.ownedQuantity}")
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = viewModel::decrementQuantity,
                        modifier = Modifier.size(32.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                    ) {
                        Text("-", style = MaterialTheme.typography.titleMedium)
                    }
                    
                    Spacer(Modifier.width(8.dp))

                    IconButton(
                        onClick = viewModel::incrementQuantity,
                        modifier = Modifier.size(32.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                    ) {
                        Text("+", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (!card.manaCost.isNullOrBlank()) {
                Text("Mana cost: ${card.manaCost}")
            }

            if (!card.power.isNullOrBlank() || !card.toughness.isNullOrBlank()) {
                Text("Power / Toughness: ${card.power ?: "?"}/${card.toughness ?: "?"}")
            }

            if (cardWithDetails.rules.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Rules")
                cardWithDetails.rules.forEach { rule ->
                    Text("• ${rule.text}")
                }
            }

            if (cardWithDetails.keywords.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Keywords: ${cardWithDetails.keywords.joinToString { it.keyword }}")
            }

            uiState.statusMessage?.let { status ->
                Spacer(Modifier.height(8.dp))
                Text(status, color = Color(0xFF2E7D32))
            }
        }
    }

    val dialogCardWithDetails = uiState.cardWithDetails
    if (allowAddToBinder && uiState.showAddToBinderDialog && dialogCardWithDetails != null) {
        AddCardToBinderDialog(
            cardName = dialogCardWithDetails.card.name,
            binders = uiState.binders,
            linkedBinderIds = uiState.linkedBinderIds,
            selectedBinderIds = uiState.selectedBinderIds,
            onBinderToggled = viewModel::toggleBinderSelection,
            onDismiss = viewModel::dismissAddToBinderDialog,
            onConfirm = viewModel::addCardToSelectedBinders
        )
    }
}

@Composable
private fun AddCardToBinderDialog(
    cardName: String,
    binders: List<BinderEntity>,
    linkedBinderIds: Set<Long>,
    selectedBinderIds: Set<Long>,
    onBinderToggled: (Long) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add $cardName to binders") },
        text = {
            if (binders.isEmpty()) {
                Text("Create a binder first.")
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    binders.forEach { binder ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = binder.binderId in selectedBinderIds,
                                onCheckedChange = { onBinderToggled(binder.binderId) }
                            )
                            Text(binder.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = binders.isNotEmpty() && (selectedBinderIds.isNotEmpty() || linkedBinderIds.isNotEmpty())
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun CreateBinderDialog(
    binderName: String,
    onBinderNameChanged: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Binder") },
        text = {
            OutlinedTextField(
                value = binderName,
                onValueChange = onBinderNameChanged,
                label = { Text("Binder name") }
            )
        },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun CardThumbnailTile(
    name: String,
    imageModel: Any?,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(0.72f)
            .border(2.dp, Color.Black, RoundedCornerShape(14.dp))
            .background(CardTileSurface, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = imageModel,
            contentDescription = name,
            modifier = Modifier
                .fillMaxSize(),
            contentScale = ContentScale.Fit
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(8.dp)
                .fillMaxWidth()
                .background(CardTileLabelBackground, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Text(
                text = name,
                color = CardTileLabelText,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
fun SettingsScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.background(
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    RoundedCornerShape(8.dp)
                )
            ) {
                Text("Back")
            }
            Spacer(Modifier.width(16.dp))
            Text("Settings", style = MaterialTheme.typography.headlineSmall)
        }

        Spacer(Modifier.height(24.dp))

        Text("Preferences", style = MaterialTheme.typography.titleMedium)
        
        Spacer(Modifier.height(8.dp))

        // Light Gray background boxes as requested for UI consistency
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    RoundedCornerShape(12.dp)
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Theme Mode")
                Text("System Sync", color = MaterialTheme.colorScheme.primary)
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("App Language")
                Text("English")
            }
        }
    }
}

@Composable
fun PreviewScreen(previewViewModel: PreviewViewModel = viewModel()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(Color.LightGray),
            contentAlignment = Alignment.Center
        ) {
            Text("Image Preview")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row {
            Button(onClick = { previewViewModel.onSave() }) {
                Text("Save")
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(onClick = { previewViewModel.onCancel() }) {
                Text("Cancel")
            }
        }
    }
}

@Preview(showBackground = true, name = "Home")
@Composable
fun HomeScreenPreview() {
    TCGAppTheme {
        HomeScreen(homeViewModel = PreviewModels.homeViewModel)
    }
}

//@Preview(showBackground = true, name = "Search")
//@Composable
//fun SearchScreenPreview() {
//    TCGAppTheme {
//        SearchScreen(searchViewModel = PreviewModels.searchViewModel)
//    }
//}

@Preview(showBackground = true, name = "Collection")
@Composable
fun CollectionScreenPreview() {
    TCGAppTheme {
        CollectionScreen(rememberNavController())
    }
}

@Preview(showBackground = true, name = "Decks")
@Composable
fun DecksScreenPreview() {
    TCGAppTheme {
        DecksScreen(
            navController = rememberNavController(),
            decksViewModel = PreviewModels.decksViewModel
        )
    }
}

@Preview(showBackground = true, name = "Scan")
@Composable
fun ScanScreenPreview() {
    TCGAppTheme {
        Text("Scan screen preview disabled because it requires camera and repositories.")
    }
}


@Preview(showBackground = true, name = "Preview Screen")
@Composable
fun PreviewScreenPreview() {
    TCGAppTheme {
        PreviewScreen(previewViewModel = PreviewModels.previewViewModel)
    }
}

private object PreviewModels {
    // Preview-only instances to avoid constructing ViewModels inside composables.
    val homeViewModel = HomeViewModel()
//    val searchViewModel = SearchViewModel()
    val decksViewModel = DecksViewModel()
    //val scanViewModel = ScanViewModel()
    val previewViewModel = PreviewViewModel()
}
