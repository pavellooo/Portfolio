package com.group9.tcgapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "decks")
data class DeckEntity(
    @PrimaryKey(autoGenerate = true)
    val deckId: Long = 0,
    val gameType: String,
    val name: String,
    val description: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
