package com.group9.tcgapp.data.scanner

object CardTextParser {

    fun extractCandidateName(rawText: String): String {
        val lines = rawText
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .filter { it.length in 2..40 }
            .filterNot { it.matches(Regex("^\\d+$")) }
            .filterNot { it.contains("HP", ignoreCase = true) }
            .filterNot { it.contains("weakness", ignoreCase = true) }
            .filterNot { it.contains("resistance", ignoreCase = true) }
            .filterNot { it.contains("retreat", ignoreCase = true) }
            .filterNot { it.contains("illustrator", ignoreCase = true) }
            .filterNot { it.contains("©") }

        return lines
            .maxByOrNull { scoreLikelyCardName(it) }
            .orEmpty()
    }

    private fun scoreLikelyCardName(line: String): Int {
        var score = 0

        if (line.any { it.isLetter() }) score += 3
        if (!line.any { it.isDigit() }) score += 2
        if (line.firstOrNull()?.isUpperCase() == true) score += 1
        if (line.length in 3..30) score += 2

        val badTerms = listOf(
            "basic",
            "stage",
            "trainer",
            "energy",
            "attack",
            "damage",
            "evolves",
            "during",
            "discard"
        )

        if (badTerms.any { line.contains(it, ignoreCase = true) }) {
            score -= 4
        }

        return score
    }
}