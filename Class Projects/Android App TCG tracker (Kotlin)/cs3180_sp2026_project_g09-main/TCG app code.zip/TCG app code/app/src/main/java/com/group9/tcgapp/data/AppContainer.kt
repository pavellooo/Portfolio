package com.group9.tcgapp.data

import android.content.Context
import androidx.room.Room
import com.group9.tcgapp.BuildConfig
import com.group9.tcgapp.data.local.db.AppDatabase
import com.group9.tcgapp.data.remote.api.RetrofitProvider
import com.group9.tcgapp.data.remote.api.ScrydexAPI
import com.group9.tcgapp.data.repository.BinderRepository
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.DeckRepository
import com.group9.tcgapp.data.repository.ScannedCardBinRepository
import com.group9.tcgapp.data.repository.SearchRepository

class AppContainer(
    context: Context
) {
    private val database: AppDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "tcg_app.db"
        ).fallbackToDestructiveMigration().build()
    }

    private val cardDao by lazy { database.cardDao() }
    private val collectionDao by lazy { database.collectionDao() }
    private val binderDao by lazy { database.binderDao() }
    private val deckDao by lazy { database.deckDao() }

    val scrydexAPI: ScrydexAPI by lazy {
        RetrofitProvider.create(
            apiKey = BuildConfig.SCRYDEX_API_KEY,
            teamId = BuildConfig.SCRYDEX_TEAM_ID
        )
    }

    val cardRepository: CardRepository by lazy {
        CardRepository(scrydexAPI, cardDao)
    }

    val collectionRepository: CollectionRepository by lazy {
        CollectionRepository(collectionDao)
    }

    val binderRepository: BinderRepository by lazy {
        BinderRepository(binderDao)
    }

    val deckRepository: DeckRepository by lazy {
        DeckRepository(deckDao, collectionRepository)
    }

    val searchRepository: SearchRepository by lazy {
        SearchRepository(scrydexAPI)
    }

    val scannedCardBinRepository: ScannedCardBinRepository by lazy {
        ScannedCardBinRepository()
    }
}