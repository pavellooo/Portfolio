package com.group9.tcgapp.data.local.dao

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.group9.tcgapp.data.local.entity.DeckCardCrossRef
import com.group9.tcgapp.data.local.entity.DeckEntity
import com.group9.tcgapp.data.local.entity.DeckWithCards
import kotlinx.coroutines.flow.Flow

@Dao
interface DeckDao {

    data class DeckSummaryRow(
        @ColumnInfo(name = "deckId")
        val deckId: Long,
        @ColumnInfo(name = "gameType")
        val gameType: String,
        @ColumnInfo(name = "name")
        val name: String,
        @ColumnInfo(name = "description")
        val description: String?,
        @ColumnInfo(name = "createdAt")
        val createdAt: Long,
        @ColumnInfo(name = "totalCards")
        val totalCards: Int
    )

    data class DeckCardRow(
        @ColumnInfo(name = "cardId")
        val cardId: String,
        @ColumnInfo(name = "quantityInDeck")
        val quantityInDeck: Int,
        @ColumnInfo(name = "cardName")
        val cardName: String,
        @ColumnInfo(name = "imageSmall")
        val imageSmall: String?,
        @ColumnInfo(name = "imageMedium")
        val imageMedium: String?,
        @ColumnInfo(name = "imageLarge")
        val imageLarge: String?
    )

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeck(deck: DeckEntity): Long

    @Query("SELECT * FROM decks ORDER BY createdAt DESC")
    fun getAllDecksFlow(): Flow<List<DeckEntity>>

    @Query("SELECT * FROM decks WHERE gameType = :gameType ORDER BY createdAt DESC")
    fun getDecksByGameFlow(gameType: String): Flow<List<DeckEntity>>

    @Query(
        """
        SELECT
            decks.deckId AS deckId,
            decks.gameType AS gameType,
            decks.name AS name,
            decks.description AS description,
            decks.createdAt AS createdAt,
            COALESCE(SUM(deck_cards.quantityInDeck), 0) AS totalCards
        FROM decks
        LEFT JOIN deck_cards ON deck_cards.deckId = decks.deckId
        WHERE decks.gameType = :gameType
        GROUP BY decks.deckId, decks.gameType, decks.name, decks.description, decks.createdAt
        ORDER BY decks.createdAt DESC
        """
    )
    fun getDeckSummariesByGameFlow(gameType: String): Flow<List<DeckSummaryRow>>

    @Query(
        """
        SELECT
            decks.deckId AS deckId,
            decks.gameType AS gameType,
            decks.name AS name,
            decks.description AS description,
            decks.createdAt AS createdAt,
            COALESCE(SUM(deck_cards.quantityInDeck), 0) AS totalCards
        FROM decks
        LEFT JOIN deck_cards ON deck_cards.deckId = decks.deckId
        GROUP BY decks.deckId, decks.gameType, decks.name, decks.description, decks.createdAt
        ORDER BY decks.createdAt DESC
        """
    )
    fun getAllDeckSummariesFlow(): Flow<List<DeckSummaryRow>>

    @Query("SELECT * FROM decks WHERE deckId = :deckId LIMIT 1")
    fun getDeckByIdFlow(deckId: Long): Flow<DeckEntity?>

    @Query("SELECT * FROM decks WHERE deckId = :deckId LIMIT 1")
    suspend fun getDeckById(deckId: Long): DeckEntity?

    @Transaction
    @Query("SELECT * FROM decks WHERE deckId = :deckId LIMIT 1")
    fun getDeckWithCardsFlow(deckId: Long): Flow<DeckWithCards?>

    @Query("SELECT COALESCE(SUM(quantityInDeck), 0) FROM deck_cards WHERE deckId = :deckId")
    suspend fun getTotalCardQuantityForDeck(deckId: Long): Int

    @Query("SELECT COALESCE(SUM(quantityInDeck), 0) FROM deck_cards WHERE deckId = :deckId")
    fun getTotalCardQuantityForDeckFlow(deckId: Long): Flow<Int>

    @Query("SELECT quantityInDeck FROM deck_cards WHERE deckId = :deckId AND cardId = :cardId LIMIT 1")
    suspend fun getQuantityForCard(deckId: Long, cardId: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDeckCard(crossRef: DeckCardCrossRef)

    @Query("DELETE FROM deck_cards WHERE deckId = :deckId AND cardId = :cardId")
    suspend fun removeCardFromDeck(deckId: Long, cardId: String)

    @Query("DELETE FROM decks WHERE deckId = :deckId")
    suspend fun deleteDeck(deckId: Long)

    @Query(
        """
        UPDATE decks
        SET name = :name, description = :description
        WHERE deckId = :deckId
        """
    )
    suspend fun updateDeck(deckId: Long, name: String, description: String? = null)

    @Query(
        """
        SELECT
            deck_cards.cardId AS cardId,
            deck_cards.quantityInDeck AS quantityInDeck,
            cards.name AS cardName,
            cards.imageSmall AS imageSmall,
            cards.imageMedium AS imageMedium,
            cards.imageLarge AS imageLarge
        FROM deck_cards
        INNER JOIN cards ON cards.id = deck_cards.cardId
        WHERE deck_cards.deckId = :deckId
        ORDER BY cards.name ASC
        """
    )
    fun getDeckCardRowsFlow(deckId: Long): Flow<List<DeckCardRow>>
}
