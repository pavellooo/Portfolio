package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.group9.tcgapp.viewmodel.PokemonStageOption
import com.group9.tcgapp.viewmodel.PokemonTypeOption
import com.group9.tcgapp.viewmodel.SearchUiState
import com.group9.tcgapp.viewmodel.SearchViewModel

@Composable
fun PokemonFiltersSection(
    vm: SearchViewModel,
    uiState: SearchUiState
) {
    val filters = uiState.pokemon

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Pokémon Filters",
            style = MaterialTheme.typography.titleMedium
        )

        Text(text = "Type")
        ChipGroupPokemonType(
            selected = filters.pokemonType,
            onSelected = vm::onPokemonTypeChanged
        )

        Text(text = "Stage")
        ChipGroupPokemonStage(
            selected = filters.stage,
            onSelected = vm::onPokemonStageChanged
        )

        OutlinedTextField(
            value = filters.subtype,
            onValueChange = vm::onPokemonSubtypeChanged,
            label = { Text("Subtype") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (uiState.showAdvancedFilters) {
            OutlinedTextField(
                value = filters.artist,
                onValueChange = vm::onPokemonArtistChanged,
                label = { Text("Artist") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = filters.evolvesFrom,
                onValueChange = vm::onPokemonEvolvesFromChanged,
                label = { Text("Evolves From") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = filters.hpMin?.toString().orEmpty(),
                    onValueChange = vm::onPokemonHpMinChanged,
                    label = { Text("HP Min") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(12.dp))

                OutlinedTextField(
                    value = filters.hpMax?.toString().orEmpty(),
                    onValueChange = vm::onPokemonHpMaxChanged,
                    label = { Text("HP Max") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            Text(text = "Weakness")
            ChipGroupPokemonType(
                selected = filters.weaknessType,
                onSelected = vm::onPokemonWeaknessTypeChanged
            )

            OutlinedTextField(
                value = filters.retreatCostMax?.toString().orEmpty(),
                onValueChange = vm::onPokemonRetreatCostMaxChanged,
                label = { Text("Retreat Cost Max") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            LabeledCheckbox(
                checked = filters.hasAbility,
                onCheckedChange = vm::onPokemonHasAbilityChanged,
                label = "Has Ability"
            )

            LabeledCheckbox(
                checked = filters.hasAttack,
                onCheckedChange = vm::onPokemonHasAttackChanged,
                label = "Has Attack"
            )

            LabeledCheckbox(
                checked = filters.hasRuleBox,
                onCheckedChange = vm::onPokemonHasRuleBoxChanged,
                label = "Has Rule Box"
            )
        }
    }
}

@Composable
private fun ChipGroupPokemonType(
    selected: PokemonTypeOption,
    onSelected: (PokemonTypeOption) -> Unit
) {
    val options = listOf(
        PokemonTypeOption.ANY,
        PokemonTypeOption.GRASS,
        PokemonTypeOption.FIRE,
        PokemonTypeOption.WATER,
        PokemonTypeOption.LIGHTNING,
        PokemonTypeOption.PSYCHIC,
        PokemonTypeOption.FIGHTING,
        PokemonTypeOption.DARKNESS,
        PokemonTypeOption.METAL,
        PokemonTypeOption.DRAGON,
        PokemonTypeOption.FAIRY,
        PokemonTypeOption.COLORLESS
    )

    FlowingChipRows(
        labels = options.map { it.label },
        selectedIndex = options.indexOf(selected),
        onClick = { index -> onSelected(options[index]) }
    )
}

@Composable
private fun ChipGroupPokemonStage(
    selected: PokemonStageOption,
    onSelected: (PokemonStageOption) -> Unit
) {
    val options = listOf(
        PokemonStageOption.ANY,
        PokemonStageOption.BASIC,
        PokemonStageOption.STAGE1,
        PokemonStageOption.STAGE2
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = selected == option,
                onClick = { onSelected(option) },
                label = { Text(option.label) }
            )
        }
    }
}

@Composable
private fun FlowingChipRows(
    labels: List<String>,
    selectedIndex: Int,
    onClick: (Int) -> Unit
) {
    val chunked = labels.chunked(4)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        chunked.forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { label ->
                    val actualIndex = labels.indexOf(label)
                    FilterChip(
                        selected = selectedIndex == actualIndex,
                        onClick = { onClick(actualIndex) },
                        label = { Text(label) }
                    )
                }
            }
        }
    }
}

@Composable
private fun LabeledCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    label: String
) {
    Row {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}