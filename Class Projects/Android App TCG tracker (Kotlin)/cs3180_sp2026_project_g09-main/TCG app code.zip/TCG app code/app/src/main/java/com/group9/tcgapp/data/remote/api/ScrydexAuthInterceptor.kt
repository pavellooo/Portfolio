package com.group9.tcgapp.data.remote.api

import okhttp3.Interceptor
import okhttp3.Response

class ScrydexAuthInterceptor(
    private val apiKey: String,
    private val teamId: String
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
            .newBuilder()
            .addHeader("X-Api-Key", apiKey)
            .addHeader("X-Team-ID", teamId)
            .build()

        return chain.proceed(request)
    }
}