package com.group9.tcgapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class PreviewViewModel : ViewModel() {
	var statusMessage by mutableStateOf("")

	fun onSave() {
		statusMessage = "Saved"
	}

	fun onCancel() {
		statusMessage = "Canceled"
	}
}