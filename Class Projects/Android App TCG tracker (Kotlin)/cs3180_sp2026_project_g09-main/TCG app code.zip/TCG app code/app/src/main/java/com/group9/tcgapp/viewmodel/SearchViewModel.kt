package com.group9.tcgapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.SearchRepository
import com.group9.tcgapp.data.repository.toSearchRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel(
    private val searchRepository: SearchRepository,
    private val cardRepository: CardRepository,
    private val collectionRepository: CollectionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun onGameSelected(game: GameType) {
        _uiState.value = _uiState.value.copy(
            selectedGame = game,
            errorMessage = null,
            statusMessage = null
        )
    }

    fun onQueryChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(query = value)
        )
    }

    fun onSetNameOrCodeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(setNameOrCode = value)
        )
    }

    fun onCardNumberChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(cardNumber = value)
        )
    }

    fun onRarityChanged(value: RarityOption) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(rarity = value)
        )
    }

    fun onLanguageChanged(value: LanguageOption) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(language = value)
        )
    }

    fun onSortChanged(value: SortOption) {
        _uiState.value = _uiState.value.copy(
            shared = _uiState.value.shared.copy(sort = value)
        )
    }

    fun toggleAdvancedFilters() {
        _uiState.value = _uiState.value.copy(
            showAdvancedFilters = !_uiState.value.showAdvancedFilters
        )
    }

    fun onMtgTypeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(type = value)
        )
    }

    fun onMtgSubtypeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(subtype = value)
        )
    }

    fun onMtgSupertypeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(supertype = value)
        )
    }

    fun onMtgKeywordChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(keyword = value)
        )
    }

    fun onMtgArtistChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(artist = value)
        )
    }

    fun onMtgManaValueMinChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(manaValueMin = value.toIntOrNull())
        )
    }

    fun onMtgManaValueMaxChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(manaValueMax = value.toIntOrNull())
        )
    }

    fun onMtgLayoutChanged(value: MtgLayoutOption) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(layout = value)
        )
    }

    fun onMtgHasRulesTextChanged(value: Boolean) {
        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(hasRulesText = value)
        )
    }

    fun toggleMtgColor(color: MtgColor) {
        val current = _uiState.value.mtg.selectedColors.toMutableSet()
        if (current.contains(color)) current.remove(color) else current.add(color)

        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(selectedColors = current)
        )
    }

    fun toggleMtgColorIdentity(color: MtgColor) {
        val current = _uiState.value.mtg.selectedColorIdentity.toMutableSet()
        if (current.contains(color)) current.remove(color) else current.add(color)

        _uiState.value = _uiState.value.copy(
            mtg = _uiState.value.mtg.copy(selectedColorIdentity = current)
        )
    }

    fun onPokemonTypeChanged(value: PokemonTypeOption) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(pokemonType = value)
        )
    }

    fun onPokemonStageChanged(value: PokemonStageOption) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(stage = value)
        )
    }

    fun onPokemonSubtypeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(subtype = value)
        )
    }

    fun onPokemonArtistChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(artist = value)
        )
    }

    fun onPokemonEvolvesFromChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(evolvesFrom = value)
        )
    }

    fun onPokemonHpMinChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(hpMin = value.toIntOrNull())
        )
    }

    fun onPokemonHpMaxChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(hpMax = value.toIntOrNull())
        )
    }

    fun onPokemonWeaknessTypeChanged(value: PokemonTypeOption) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(weaknessType = value)
        )
    }

    fun onPokemonRetreatCostMaxChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(retreatCostMax = value.toIntOrNull())
        )
    }

    fun onPokemonHasAbilityChanged(value: Boolean) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(hasAbility = value)
        )
    }

    fun onPokemonHasAttackChanged(value: Boolean) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(hasAttack = value)
        )
    }

    fun onPokemonHasRuleBoxChanged(value: Boolean) {
        _uiState.value = _uiState.value.copy(
            pokemon = _uiState.value.pokemon.copy(hasRuleBox = value)
        )
    }

    fun clearAllFilters() {
        _uiState.value = SearchUiState(
            selectedGame = _uiState.value.selectedGame
        )
    }

    fun searchCards() {
        val current = _uiState.value

        viewModelScope.launch {
            _uiState.value = current.copy(
                isLoading = true,
                errorMessage = null,
                statusMessage = null,
                results = emptyList()
            )

            try {
                val request = _uiState.value.toSearchRequest()
                val results = searchRepository.searchCards(request)

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    results = results,
                    errorMessage = null,
                    statusMessage = if (results.isEmpty()) {
                        "No cards found."
                    } else {
                        null
                    }
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = t.message ?: t::class.java.simpleName
                )
            }
        }
    }

    fun addCardToCollection(cardId: String) {
        val current = _uiState.value

        viewModelScope.launch {
            _uiState.value = current.copy(
                isSaving = true,
                errorMessage = null,
                statusMessage = null
            )

            try {
                val gamePath = _uiState.value.selectedGame.toApiGamePath()
                cardRepository.fetchSingleCard(gamePath, cardId)
                collectionRepository.incrementOwnedQuantity(cardId)

                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    statusMessage = "Added to ${_uiState.value.selectedGame.name} collection."
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    errorMessage = t.message ?: t::class.java.simpleName
                )
            }
        }
    }
}

private fun GameType.toApiGamePath(): String {
    return when (this) {
        GameType.POKEMON -> "pokemon"
        GameType.MTG -> "magicthegathering"
    }
}