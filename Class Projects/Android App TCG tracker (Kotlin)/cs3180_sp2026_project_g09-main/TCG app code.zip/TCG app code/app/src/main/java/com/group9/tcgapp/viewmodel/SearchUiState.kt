package com.group9.tcgapp.viewmodel

data class SearchUiState(
    val selectedGame: GameType = GameType.POKEMON,
    val shared: SharedSearchFilters = SharedSearchFilters(),
    val mtg: MtgFilters = MtgFilters(),
    val pokemon: PokemonFilters = PokemonFilters(),

    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
    val statusMessage: String? = null,
    val results: List<CardSearchResult> = emptyList(),

    val showAdvancedFilters: Boolean = false
)