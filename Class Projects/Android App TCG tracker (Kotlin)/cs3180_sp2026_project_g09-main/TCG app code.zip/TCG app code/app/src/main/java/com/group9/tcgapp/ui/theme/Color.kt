package com.group9.tcgapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

data class BinderTileColors(
	val background: Color,
	val labelBackground: Color,
	val labelText: Color
)

val Purple80 = Color(0xFF8686AC)
val PurpleGrey80 = Color(0xFF505081)
val Pink80 = Color(0xFF272757)

val Purple40 = Color(0xFF0F0E47)
val PurpleGrey40 = Color(0xFF272757)
val Pink40 = Color(0xFF505081)
val AppBackground = Color(0xFFE8E8E8)
val CardTileSurface = Color(0xFFF9F9F9)
val CardTileLabelBackground = Color(0xE0FFFFFF)
val CardTileLabelText = Color(0xFF1F1F1F)

private val BinderPalette = listOf(
	Color(0xFF7E88D9),
	Color(0xFF6E7FD3),
	Color(0xFF5F74CB),
	Color(0xFF546AC2),
	Color(0xFF6B63C8),
	Color(0xFF5A5AB6),
	Color(0xFF4B56A8),
	Color(0xFF424A96)
)

@Composable
fun rememberBinderTileColors(sequenceIndex: Int): BinderTileColors {
	val safeIndex = if (sequenceIndex >= 0) sequenceIndex else 0
	val background = BinderPalette[safeIndex % BinderPalette.size]

	val labelBackground = MaterialTheme.colorScheme.surface.copy(alpha = 0.24f)
	val labelText = if (background.luminance() > 0.5f) CardTileLabelText else Color.White

	return BinderTileColors(
		background = background,
		labelBackground = labelBackground,
		labelText = labelText
	)
}
