package com.group9.tcgapp.data.local.entity

import androidx.room.Entity

@Entity(
    tableName = "binder_cards",
    primaryKeys = ["binderId", "cardId"]
)
data class BinderCardCrossRef(
    val binderId: Long,
    val cardId: String,
    val quantityInBinder: Int = 1,
    val addedAt: Long = System.currentTimeMillis()
)