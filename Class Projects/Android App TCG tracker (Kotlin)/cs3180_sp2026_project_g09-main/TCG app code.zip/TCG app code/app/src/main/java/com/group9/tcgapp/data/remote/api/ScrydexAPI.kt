package com.group9.tcgapp.data.remote.api

import com.group9.tcgapp.data.remote.dto.CardSearchResponseDto
import com.group9.tcgapp.data.remote.dto.CardSingleResponseDto
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ScrydexAPI {

    @GET("{game}/v1/cards/{id}")
    suspend fun getCardById(
        @Path("game") game: String,
        @Path("id") cardId: String
    ): CardSingleResponseDto

    @GET("{game}/v1/cards")
    suspend fun searchCards(
        @Path("game") game: String,
        @Query("q") query: String,
        @Query("page") page: Int = 1,
        @Query("page_size") pageSize: Int = 50
    ): CardSearchResponseDto
}