package com.group9.tcgapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.ScannedCardBinRepository
import com.group9.tcgapp.data.repository.ScannedCardEntry
import com.group9.tcgapp.data.repository.SearchRepository
import com.group9.tcgapp.data.scanner.CardTextParser
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ScanViewModel(
    private val searchRepository: SearchRepository,
    private val scannedCardBinRepository: ScannedCardBinRepository,
    private val cardRepository: CardRepository,
    private val collectionRepository: CollectionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ScanUiState())
    val uiState: StateFlow<ScanUiState> = _uiState.asStateFlow()

    private var lastSearchedCandidate: String = ""
    private var lastConfirmedCandidate: String = ""
    private var lastConfirmedCardId: String = ""
    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            scannedCardBinRepository.scannedCards.collect { cards ->
                _uiState.value = _uiState.value.copy(scannedBin = cards)
            }
        }
    }

    fun openBinPanel() {
        _uiState.value = _uiState.value.copy(showBinPanel = true)
    }

    fun dismissBinPanel() {
        _uiState.value = _uiState.value.copy(showBinPanel = false)
    }

    fun setBinEntryFoilStatus(localId: String, isFoil: Boolean) {
        scannedCardBinRepository.setFoilStatus(localId, isFoil)
    }
    fun onGameSelected(game: GameType) {
        _uiState.value = _uiState.value.copy(
            selectedGame = game,
            possibleMatches = emptyList(),
            showSelectionDialog = false,
            errorMessage = null,
            lastScanMessage = "Scanning ${game.name} cards."
        )

        lastSearchedCandidate = ""
        lastConfirmedCandidate = ""
        lastConfirmedCardId = ""
    }

    fun toggleFlashlight() {
        _uiState.value = _uiState.value.copy(
            isFlashlightOn = !_uiState.value.isFlashlightOn
        )
    }

    fun onTextRecognized(rawText: String) {
        val current = _uiState.value

        if (current.showSelectionDialog || current.isSearching || current.isSaving) {
            return
        }

        val candidate = CardTextParser.extractCandidateName(rawText)

        _uiState.value = current.copy(
            recognizedText = rawText,
            candidateCardName = candidate,
            errorMessage = null
        )

        if (candidate.isBlank()) {
            _uiState.value = _uiState.value.copy(
                lastScanMessage = "Text found, but no card name detected."
            )
            return
        }

        if (candidate.equals(lastConfirmedCandidate, ignoreCase = true)) {
            _uiState.value = _uiState.value.copy(
                lastScanMessage = "Already scanned $candidate. Move to a different card."
            )
            return
        }

        if (candidate.equals(lastSearchedCandidate, ignoreCase = true)) {
            return
        }

        lastSearchedCandidate = candidate

        _uiState.value = _uiState.value.copy(
            lastScanMessage = "Detected: $candidate"
        )

        searchCandidate(candidate)
    }

    fun searchCandidate(candidateName: String = _uiState.value.candidateCardName) {
        if (candidateName.isBlank()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "No readable card name found."
            )
            return
        }

        searchJob?.cancel()

        searchJob = viewModelScope.launch {
            val game = _uiState.value.selectedGame

            _uiState.value = _uiState.value.copy(
                isSearching = true,
                errorMessage = null,
                possibleMatches = emptyList(),
                showSelectionDialog = false
            )

            try {
                val results = searchRepository.searchByScannedName(
                    game = game,
                    candidateName = candidateName,
                    pageSize = 8
                ).filterNot { result ->
                    result.id == lastConfirmedCardId && candidateName.equals(
                        lastConfirmedCandidate,
                        ignoreCase = true
                    )
                }

                _uiState.value = _uiState.value.copy(
                    isSearching = false,
                    possibleMatches = results,
                    showSelectionDialog = results.isNotEmpty(),
                    lastScanMessage = if (results.isEmpty()) {
                        "No new Scrydex matches found for $candidateName."
                    } else {
                        "Select the correct card."
                    }
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isSearching = false,
                    errorMessage = t.message ?: "Scan search failed.",
                    showSelectionDialog = false
                )
            }
        }
    }

    fun onCardSelected(card: CardSearchResult, isFoil: Boolean) {
        val added = scannedCardBinRepository.addCard(card, isFoil)

        lastConfirmedCandidate = _uiState.value.candidateCardName
        lastConfirmedCardId = card.id
        lastSearchedCandidate = ""

        _uiState.value = _uiState.value.copy(
            showSelectionDialog = false,
            possibleMatches = emptyList(),
            lastScanMessage = if (added) {
                "Saved ${card.name}${if (isFoil) " foil" else ""} to scanned card bin."
            } else {
                "${card.name} was already the last scanned card."
            }
        )
    }

    fun dismissSelectionDialog() {
        _uiState.value = _uiState.value.copy(
            showSelectionDialog = false,
            possibleMatches = emptyList(),
            lastScanMessage = "Selection dismissed. Continue scanning."
        )

        lastSearchedCandidate = ""
    }

    fun removeFromBin(localId: String) {
        scannedCardBinRepository.removeEntry(localId)
    }

    fun clearBin() {
        scannedCardBinRepository.clearBin()
        _uiState.value = _uiState.value.copy(
            lastScanMessage = "Scanned bin cleared."
        )
    }
    fun saveOneToCollection(entry: ScannedCardEntry) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isSaving = true,
                errorMessage = null,
                lastScanMessage = "Saving ${entry.card.name}..."
            )

            try {
                val gamePath = entry.card.game.toApiGamePath()
                val cardId = entry.card.id

                // Same save path used by SearchViewModel.addCardToCollection()
                cardRepository.fetchSingleCard(gamePath, cardId)
                collectionRepository.incrementOwnedQuantity(cardId)

                scannedCardBinRepository.removeEntry(entry.localId)

                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    lastScanMessage = "Saved ${entry.card.name} to collection."
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    errorMessage = t.message ?: t::class.java.simpleName,
                    lastScanMessage = "Could not save ${entry.card.name}."
                )
            }
        }
    }

    fun saveAllToCollection() {
        val entries = _uiState.value.scannedBin

        if (entries.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                lastScanMessage = "Scanned bin is empty."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isSaving = true,
                errorMessage = null,
                lastScanMessage = "Saving ${entries.size} card(s)..."
            )

            var savedCount = 0

            try {
                entries.forEach { entry ->
                    val gamePath = entry.card.game.toApiGamePath()
                    val cardId = entry.card.id

                    // Same save path used by SearchViewModel.addCardToCollection()
                    cardRepository.fetchSingleCard(gamePath, cardId)
                    collectionRepository.incrementOwnedQuantity(cardId)

                    scannedCardBinRepository.removeEntry(entry.localId)
                    savedCount++
                }

                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    showBinPanel = false,
                    lastScanMessage = "Saved $savedCount card(s) to collection."
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    errorMessage = t.message ?: t::class.java.simpleName,
                    lastScanMessage = "Saved $savedCount card(s), then failed."
                )
            }
        }
    }
}

private fun GameType.toApiGamePath(): String {
    return when (this) {
        GameType.POKEMON -> "pokemon"
        GameType.MTG -> "magicthegathering"
    }
}