package com.group9.tcgapp.data.mapper

import com.group9.tcgapp.data.local.entity.*
import com.group9.tcgapp.data.remote.dto.CardDto

data class CardInsertBundle(
    val card: CardEntity,
    val expansion: ExpansionEntity?,
    val rules: List<CardRuleEntity>,
    val rulings: List<CardRulingEntity>,
    val types: List<CardTypeEntity>,
    val subtypes: List<CardSubtypeEntity>,
    val supertypes: List<CardSupertypeEntity>,
    val colors: List<CardColorEntity>,
    val colorIdentity: List<CardColorIdentityEntity>,
    val keywords: List<CardKeywordEntity>
)

fun CardDto.toInsertBundle(game: String): CardInsertBundle {
    val frontImage = images.firstOrNull() ?: faces.firstOrNull()?.images?.firstOrNull()

    val cardEntity = CardEntity(
        id = id,
        game = game,
        name = name,
        typeLine = type,
        number = number,
        rarity = rarity,
        artist = artist,
        manaCost = manaCost,
        manaValue = manaValue,
        power = power,
        toughness = toughness,
        imageSmall = frontImage?.small,
        imageMedium = frontImage?.medium,
        imageLarge = frontImage?.large,
        expansionId = expansion?.id,
        language = language,
        languageCode = languageCode,
        layout = layout,
        expansionSortOrder = expansionSortOrder
    )

    val expansionEntity = expansion?.let {
        ExpansionEntity(
            id = it.id,
            name = it.name,
            code = it.code,
            type = it.type,
            block = it.block,
            total = it.total,
            releaseDate = it.releaseDate,
            isFoilOnly = it.isFoilOnly,
            isOnlineOnly = it.isOnlineOnly,
            logoUrl = it.logo,
            symbolUrl = it.symbol
        )
    }

    val ruleEntities = rules.mapIndexed { index, text ->
        CardRuleEntity(
            cardId = id,
            ruleIndex = index,
            text = text
        )
    }

    val rulingEntities = rulings.mapNotNull { ruling ->
        val date = ruling.date
        val text = ruling.text
        if (date != null && text != null) {
            CardRulingEntity(
                cardId = id,
                date = date,
                text = text
            )
        } else {
            null
        }
    }

    val typeEntities = types.map { CardTypeEntity(id, it) }
    val subtypeEntities = subtypes.map { CardSubtypeEntity(id, it) }
    val supertypeEntities = supertypes.map { CardSupertypeEntity(id, it) }
    val colorEntities = colors.map { CardColorEntity(id, it) }
    val colorIdentityEntities = colorIdentity.map { CardColorIdentityEntity(id, it) }
    val keywordEntities = keywords.map { CardKeywordEntity(id, it) }

    return CardInsertBundle(
        card = cardEntity,
        expansion = expansionEntity,
        rules = ruleEntities,
        rulings = rulingEntities,
        types = typeEntities,
        subtypes = subtypeEntities,
        supertypes = supertypeEntities,
        colors = colorEntities,
        colorIdentity = colorIdentityEntities,
        keywords = keywordEntities
    )
}