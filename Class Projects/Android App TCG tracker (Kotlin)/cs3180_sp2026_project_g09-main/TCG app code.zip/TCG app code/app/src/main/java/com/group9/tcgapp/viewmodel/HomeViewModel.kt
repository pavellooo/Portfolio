package com.group9.tcgapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group9.tcgapp.data.local.entity.BinderEntity
import com.group9.tcgapp.data.local.entity.DeckEntity
import com.group9.tcgapp.data.local.dao.DeckDao
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.remote.api.ScrydexConfig
import com.group9.tcgapp.data.repository.BinderRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import com.group9.tcgapp.data.repository.DeckRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class HomeUiState(
    val totalCards: Int = 0,
    val pokemonCount: Int = 0,
    val mtgCount: Int = 0,
    val recentBinder: Pair<BinderEntity, Int>? = null,
    val recentDeck: Pair<DeckEntity, Int>? = null,
    val binders: List<Pair<BinderEntity, Int>> = emptyList(),
    val decks: List<Pair<DeckEntity, Int>> = emptyList()
)

class HomeViewModel(
    private val collectionRepository: CollectionRepository? = null,
    private val binderRepository: BinderRepository? = null,
    private val deckRepository: DeckRepository? = null
) : ViewModel() {
    var searchText by mutableStateOf("")

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        val colRepo = collectionRepository
        val binRepo = binderRepository
        val decRepo = deckRepository

        if (colRepo != null && binRepo != null && decRepo != null) {
            viewModelScope.launch {
                combine(
                    colRepo.getOwnedCardsByGameFlow(ScrydexConfig.GAME_POKEMON),
                    colRepo.getOwnedCardsByGameFlow(ScrydexConfig.GAME_MAGIC),
                    binRepo.getAllBindersFlow(),
                    decRepo.getAllDeckSummariesFlow() // Line 48 starts here
                ) { pks: List<CardEntity>, mtgs: List<CardEntity>, binders: List<BinderEntity>, deckSummaries: List<DeckDao.DeckSummaryRow> ->
                    // Suspend-aware mapping for binder card counts
                    val binderPairs = mutableListOf<Pair<BinderEntity, Int>>()
                    for (binder in binders) {
                        val count = binRepo.getCardCountForBinder(binder.binderId)
                        binderPairs.add(binder to count)
                    }

                    val deckPairs = deckSummaries.map { 
                        DeckEntity(it.deckId, it.gameType, it.name, it.description, it.createdAt) to it.totalCards 
                    }

                    HomeUiState(
                        totalCards = pks.size + mtgs.size,
                        pokemonCount = pks.size,
                        mtgCount = mtgs.size,
                        recentBinder = binderPairs.firstOrNull(),
                        recentDeck = deckPairs.firstOrNull(),
                        binders = binderPairs,
                        decks = deckPairs
                    )
                }.collect { _uiState.value = it }
            }
        }
    }

    fun onSearchTextChanged(value: String) {
        searchText = value
    }
}
