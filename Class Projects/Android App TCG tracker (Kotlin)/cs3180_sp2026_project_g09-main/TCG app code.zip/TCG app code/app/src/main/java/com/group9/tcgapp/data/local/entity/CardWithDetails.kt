package com.group9.tcgapp.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation

data class CardWithDetails(
    @Embedded val card: CardEntity,

    @Relation(
        parentColumn = "expansionId",
        entityColumn = "id"
    )
    val expansion: ExpansionEntity?,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val rules: List<CardRuleEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val rulings: List<CardRulingEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val types: List<CardTypeEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val subtypes: List<CardSubtypeEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val supertypes: List<CardSupertypeEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val colors: List<CardColorEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val colorIdentity: List<CardColorIdentityEntity>,

    @Relation(
        parentColumn = "id",
        entityColumn = "cardId"
    )
    val keywords: List<CardKeywordEntity>
)