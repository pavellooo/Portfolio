package com.group9.tcgapp.data

data class Card(
    val id: String,
    val name: String,
    val setName: String = "",
    val imageUrl: String = ""
)