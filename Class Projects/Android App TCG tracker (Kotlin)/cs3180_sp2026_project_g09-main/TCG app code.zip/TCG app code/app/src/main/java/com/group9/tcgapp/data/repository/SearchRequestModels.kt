package com.group9.tcgapp.data.repository

import com.group9.tcgapp.viewmodel.GameType
import com.group9.tcgapp.viewmodel.LanguageOption
import com.group9.tcgapp.viewmodel.MtgColor
import com.group9.tcgapp.viewmodel.MtgLayoutOption
import com.group9.tcgapp.viewmodel.PokemonStageOption
import com.group9.tcgapp.viewmodel.PokemonTypeOption
import com.group9.tcgapp.viewmodel.RarityOption
import com.group9.tcgapp.viewmodel.SearchUiState
import com.group9.tcgapp.viewmodel.SortOption

data class CardSearchRequest(
    val game: GameType,
    val shared: SharedSearchRequest,
    val mtg: MtgSearchRequest? = null,
    val pokemon: PokemonSearchRequest? = null
)

data class SharedSearchRequest(
    val query: String,
    val setNameOrCode: String?,
    val cardNumber: String?,
    val rarity: RarityOption?,
    val language: LanguageOption?,
    val sort: SortOption?
)

data class MtgSearchRequest(
    val selectedColors: Set<MtgColor>,
    val selectedColorIdentity: Set<MtgColor>,
    val type: String?,
    val subtype: String?,
    val supertype: String?,
    val keyword: String?,
    val artist: String?,
    val manaValueMin: Int?,
    val manaValueMax: Int?,
    val powerMin: Int?,
    val powerMax: Int?,
    val toughnessMin: Int?,
    val toughnessMax: Int?,
    val layout: MtgLayoutOption?,
    val hasRulesText: Boolean
)

data class PokemonSearchRequest(
    val pokemonType: PokemonTypeOption?,
    val stage: PokemonStageOption?,
    val subtype: String?,
    val artist: String?,
    val evolvesFrom: String?,
    val hpMin: Int?,
    val hpMax: Int?,
    val weaknessType: PokemonTypeOption?,
    val retreatCostMax: Int?,
    val hasAbility: Boolean,
    val hasAttack: Boolean,
    val hasRuleBox: Boolean
)

fun SearchUiState.toSearchRequest(): CardSearchRequest {
    return CardSearchRequest(
        game = selectedGame,
        shared = SharedSearchRequest(
            query = shared.query.trim(),
            setNameOrCode = shared.setNameOrCode.trim().ifBlank { null },
            cardNumber = shared.cardNumber.trim().ifBlank { null },
            rarity = shared.rarity.takeUnless { it == RarityOption.ANY },
            language = shared.language.takeUnless { it == LanguageOption.ANY },
            sort = shared.sort
        ),
        mtg = if (selectedGame == GameType.MTG) {
            MtgSearchRequest(
                selectedColors = mtg.selectedColors,
                selectedColorIdentity = mtg.selectedColorIdentity,
                type = mtg.type.trim().ifBlank { null },
                subtype = mtg.subtype.trim().ifBlank { null },
                supertype = mtg.supertype.trim().ifBlank { null },
                keyword = mtg.keyword.trim().ifBlank { null },
                artist = mtg.artist.trim().ifBlank { null },
                manaValueMin = mtg.manaValueMin,
                manaValueMax = mtg.manaValueMax,
                powerMin = mtg.powerMin,
                powerMax = mtg.powerMax,
                toughnessMin = mtg.toughnessMin,
                toughnessMax = mtg.toughnessMax,
                layout = mtg.layout.takeUnless { it == MtgLayoutOption.ANY },
                hasRulesText = mtg.hasRulesText
            )
        } else {
            null
        },
        pokemon = if (selectedGame == GameType.POKEMON) {
            PokemonSearchRequest(
                pokemonType = pokemon.pokemonType.takeUnless { it == PokemonTypeOption.ANY },
                stage = pokemon.stage.takeUnless { it == PokemonStageOption.ANY },
                subtype = pokemon.subtype.trim().ifBlank { null },
                artist = pokemon.artist.trim().ifBlank { null },
                evolvesFrom = pokemon.evolvesFrom.trim().ifBlank { null },
                hpMin = pokemon.hpMin,
                hpMax = pokemon.hpMax,
                weaknessType = pokemon.weaknessType.takeUnless { it == PokemonTypeOption.ANY },
                retreatCostMax = pokemon.retreatCostMax,
                hasAbility = pokemon.hasAbility,
                hasAttack = pokemon.hasAttack,
                hasRuleBox = pokemon.hasRuleBox
            )
        } else {
            null
        }
    )
}