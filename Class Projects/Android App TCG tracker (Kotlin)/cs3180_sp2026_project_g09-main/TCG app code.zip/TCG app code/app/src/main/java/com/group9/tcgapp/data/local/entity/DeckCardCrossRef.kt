package com.group9.tcgapp.data.local.entity

import androidx.room.Entity

@Entity(
    tableName = "deck_cards",
    primaryKeys = ["deckId", "cardId"]
)
data class DeckCardCrossRef(
    val deckId: Long,
    val cardId: String,
    val quantityInDeck: Int = 1,
    val addedAt: Long = System.currentTimeMillis()
)
