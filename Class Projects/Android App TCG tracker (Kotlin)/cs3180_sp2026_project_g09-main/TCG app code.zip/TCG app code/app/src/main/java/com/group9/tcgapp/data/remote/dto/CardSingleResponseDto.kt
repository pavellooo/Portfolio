package com.group9.tcgapp.data.remote.dto

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CardSingleResponseDto(
    val data: CardDto? = null
)