package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.local.dao.CardDao
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.local.entity.CardWithDetails
import com.group9.tcgapp.data.mapper.CardInsertBundle
import com.group9.tcgapp.data.mapper.toInsertBundle
import com.group9.tcgapp.data.remote.api.ScrydexAPI
import com.group9.tcgapp.data.remote.dto.CardDto
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow


class CardRepository(
    private val api: ScrydexAPI,
    private val cardDao: CardDao
) {

    fun getAllCardsFlow(game: String): Flow<List<CardEntity>> {
        return cardDao.getAllCardsFlow(game)
    }

    fun searchCardsFlow(game: String, query: String): Flow<List<CardEntity>> {
        return cardDao.searchCardsFlow(game, query)
    }

    fun getCardDetailsFlow(cardId: String): Flow<CardWithDetails?> {
        return cardDao.getCardWithDetailsFlow(cardId)
    }

    suspend fun deleteCardAndRelated(cardId: String) {
        cardDao.deleteCardAndRelated(cardId)
    }

    suspend fun fetchSingleCard(game: String, cardId: String) {
        //The function below is for showing mock data only. Comment/Remove this!
//        if (cardId.startsWith("mock-")) {
//            val dto = mockCardFromJson(cardId)
//            val bundle = dto.toInsertBundle(game)
//            insertBundle(bundle)
//            return
//        }

        val dto = api.getCardById(
            game = game,
            cardId = cardId
        ).data ?: error("Card response did not contain data for id=$cardId")

        val bundle = dto.toInsertBundle(game)

        insertBundle(bundle)
    }

    suspend fun ensureCardLoaded(game: String, cardId: String) {
        val current = cardDao.getCardCount(game)
        if (current == 0) {
            fetchSingleCard(game, cardId)
        }
    }

    private suspend fun insertBundle(bundle: CardInsertBundle) {
        bundle.expansion?.let { cardDao.insertExpansions(listOf(it)) }
        cardDao.insertCards(listOf(bundle.card))
        cardDao.insertRules(bundle.rules)
        cardDao.insertRulings(bundle.rulings)
        cardDao.insertTypes(bundle.types)
        cardDao.insertSubtypes(bundle.subtypes)
        cardDao.insertSupertypes(bundle.supertypes)
        cardDao.insertColors(bundle.colors)
        cardDao.insertColorIdentity(bundle.colorIdentity)
        cardDao.insertKeywords(bundle.keywords)
    }
}

// TODO: everything below is for showing mock data only. Comment/Remove this!
// private fun mockCardFromJson(cardId: String): CardDto {
//         val json = mockCardJsonPayload(cardId)
//         return requireNotNull(mockCardAdapter.fromJson(json)) {
//                 "Unable to parse mock card JSON for $cardId"
//         }
// }

// private fun mockCardJsonPayload(cardId: String): String {
//         return when (cardId) {
//                 "mock-pokemon-base1-4" -> MOCK_POKEMON_CHARIZARD_JSON
//                 "mock-pokemon-base1-58" -> MOCK_POKEMON_PIKACHU_JSON
//                 "mock-mtg-lightning-bolt" -> MOCK_MTG_LIGHTNING_BOLT_JSON
//                 "mock-mtg-serra-angel" -> MOCK_MTG_SERRA_ANGEL_JSON
//                 else -> MOCK_POKEMON_PIKACHU_JSON
//         }
// }

// private val mockCardAdapter = Moshi.Builder()
//         .add(KotlinJsonAdapterFactory())
//         .build()
//         .adapter(CardDto::class.java)

// private const val MOCK_POKEMON_CHARIZARD_JSON = """
// {
//     "id": "mock-pokemon-base1-4",
//     "name": "Charizard",
//     "supertype": "Pokémon",
//     "subtypes": ["Stage 2"],
//     "types": ["Fire"],
//     "hp": "120",
//     "abilities": [
//         {
//             "type": "Pokémon Power",
//             "name": "Energy Burn",
//             "text": "As often as you like during your turn (before your attack), you may turn all Energy attached to Charizard into Fire Energy for the rest of the turn."
//         }
//     ],
//     "attacks": [
//         {
//             "cost": ["Fire", "Fire", "Fire", "Fire"],
//             "converted_energy_cost": 4,
//             "name": "Fire Spin",
//             "text": "Discard 2 Energy cards attached to Charizard in order to use this attack.",
//             "damage": "100"
//         }
//     ],
//     "number": "4",
//     "rarity": "Rare Holo",
//     "rarity_code": "★H",
//     "artist": "Mitsuhiro Arita",
//     "national_pokedex_numbers": [6],
//     "images": [
//         {
//             "type": "front",
//             "small": "https://images.scrydex.com/pokemon/base1-4/small",
//             "medium": "https://images.scrydex.com/pokemon/base1-4/medium",
//             "large": "https://images.scrydex.com/pokemon/base1-4/large"
//         }
//     ],
//     "expansion": {
//         "id": "base1",
//         "name": "Base",
//         "series": "Base",
//         "total": 102,
//         "printed_total": 102,
//         "language": "English",
//         "language_code": "EN",
//         "release_date": "1999/01/09",
//         "is_online_only": false
//     },
//     "language": "English",
//     "language_code": "EN",
//     "expansion_sort_order": 4,
//     "variants": [
//         {
//             "name": "unlimitedHolofoil",
//             "prices": []
//         }
//     ]
// }
// """

// private const val MOCK_POKEMON_PIKACHU_JSON = """
// {
//     "id": "mock-pokemon-base1-58",
//     "name": "Pikachu",
//     "supertype": "Pokémon",
//     "subtypes": ["Basic"],
//     "types": ["Lightning"],
//     "hp": "40",
//     "attacks": [
//         {
//             "cost": ["Lightning"],
//             "converted_energy_cost": 1,
//             "name": "Gnaw",
//             "text": "",
//             "damage": "10"
//         }
//     ],
//     "number": "58",
//     "rarity": "Common",
//     "artist": "Mitsuhiro Arita",
//     "images": [
//         {
//             "type": "front",
//             "small": "https://images.scrydex.com/pokemon/base1-58/small",
//             "medium": "https://images.scrydex.com/pokemon/base1-58/medium",
//             "large": "https://images.scrydex.com/pokemon/base1-58/large"
//         }
//     ],
//     "expansion": {
//         "id": "base1",
//         "name": "Base",
//         "total": 102,
//         "release_date": "1999/01/09",
//         "is_online_only": false
//     },
//     "language": "English",
//     "language_code": "EN",
//     "expansion_sort_order": 58
// }
// """

// private const val MOCK_MTG_LIGHTNING_BOLT_JSON = """
// {
//     "id": "mock-mtg-lightning-bolt",
//     "name": "Lightning Bolt",
//     "supertypes": [],
//     "subtypes": [],
//     "types": ["Instant"],
//     "type": "Instant",
//     "number": "146",
//     "color_identity": ["R"],
//     "colors": ["R"],
//     "mana_cost": "{R}",
//     "mana_value": 1,
//     "rules": ["Lightning Bolt deals 3 damage to any target."],
//     "rarity": "Common",
//     "artist": "Christopher Moeller",
//     "keywords": [],
//     "layout": "normal",
//     "images": [
//         {
//             "type": "front",
//             "small": "https://cards.scryfall.io/small/front/7/7/77c6fa74-5543-42ac-9ead-0e890b188e99.jpg?1706239968",
//             "medium": "https://cards.scryfall.io/normal/front/7/7/77c6fa74-5543-42ac-9ead-0e890b188e99.jpg?1706239968",
//             "large": "https://cards.scryfall.io/large/front/7/7/77c6fa74-5543-42ac-9ead-0e890b188e99.jpg?1706239968"
//         }
//     ],
//     "expansion": {
//         "id": "m10",
//         "name": "Magic 2010",
//         "code": "M10",
//         "total": 249,
//         "release_date": "2009-07-17",
//         "is_online_only": false
//     },
//     "language": "English",
//     "language_code": "EN",
//     "expansion_sort_order": 146
// }
// """

// private const val MOCK_MTG_SERRA_ANGEL_JSON = """
// {
//     "id": "mock-mtg-serra-angel",
//     "name": "Serra Angel",
//     "supertypes": [],
//     "subtypes": ["Angel"],
//     "types": ["Creature"],
//     "type": "Creature - Angel",
//     "number": "34",
//     "color_identity": ["W"],
//     "colors": ["W"],
//     "mana_cost": "{3}{W}{W}",
//     "mana_value": 5,
//     "power": "4",
//     "toughness": "4",
//     "rules": ["Flying", "Vigilance"],
//     "rarity": "Uncommon",
//     "artist": "Greg Staples",
//     "keywords": ["Flying", "Vigilance"],
//     "layout": "normal",
//     "images": [
//         {
//             "type": "front",
//             "small": "https://cards.scryfall.io/small/front/3/c/3cee9303-9d65-45a2-93d4-ef4aba59141b.jpg?1730489152",
//             "medium": "https://cards.scryfall.io/normal/front/3/c/3cee9303-9d65-45a2-93d4-ef4aba59141b.jpg?1730489152",
//             "large": "https://cards.scryfall.io/large/front/3/c/3cee9303-9d65-45a2-93d4-ef4aba59141b.jpg?1730489152"
//         }
//     ],
//     "expansion": {
//         "id": "m10",
//         "name": "Magic 2010",
//         "code": "M10",
//         "total": 249,
//         "release_date": "2009-07-17",
//         "is_online_only": false
//     },
//     "language": "English",
//     "language_code": "EN",
//     "expansion_sort_order": 34
// }
// """