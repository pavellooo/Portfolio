package com.group9.tcgapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import com.group9.tcgapp.ui.tcgApp
import com.group9.tcgapp.ui.theme.TCGAppTheme

/*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
*/


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            TCGAppTheme {
                tcgApp()
            }
        }
    }
}

/*

@Composable
fun MainApp() {
    val navController = rememberNavController()
    Scaffold(

        bottomBar = {
            BottomNavBar(navController)
        }

    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {

            composable("home") { HomeScreen() }
            composable("search") { SearchScreen() }
            composable("collection") { CollectionScreen() }
            composable("decks") { DecksScreen() }
            composable("scan") { ScanScreen() }
            composable("preview") { PreviewScreen() }

        }

    }
}
@Composable
fun BottomNavBar(navController: NavHostController) {

    NavigationBar {

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("home") },
            label = { Text("Home") },
            icon = {}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("search") },
            label = { Text("Search") },
            icon = {}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("collection") },
            label = { Text("Collection") },
            icon = {}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("decks") },
            label = { Text("Decks") },
            icon = {}
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("scan") },
            label = { Text("Scan") },
            icon = {}
        )
    }
}
@Preview
@Composable
fun HomeScreen() {

    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        //box containing home screen text field and the two account icons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Home", color = Color.White)
            }

            Row {
                Icon(Icons.Default.Settings, contentDescription = "settings")
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
        //Text Field
        TextField(
            value = text,
            onValueChange = { text = it },
            placeholder = { Text("Search") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(20.dp))

        //Recently Viewed Box...havent done the colors for it.
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {

            Box(
                modifier = Modifier
                    .width(200.dp)
                    .height(100.dp)
                    .background(Color.LightGray, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Recently Viewed")
            }

        }
        Spacer(modifier = Modifier.height(16.dp))
        //Recently Viewed Cards
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color.LightGray, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ){
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(50.dp),
                contentPadding = PaddingValues(horizontal = 16.dp)
            ) {
                //For whatever reason I can't get the boxes to work right...
                items(5) { index ->

                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .background(Color.LightGray, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Box ${index + 1}")
                    }

                }
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
        //News Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color.LightGray, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("News")
        }
    }
}
@Preview
@Composable
fun SearchScreen() {

    var search by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        //Search title thingy and icons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Search", color = Color.White)
            }

            Row {
                Icon(Icons.Default.Settings, contentDescription = "settings")
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        //Search Box
        TextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Search") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {}) {
            Text("Filter by Label")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(onClick = {}) {
            Text("Filter by Value")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Results will appear here")
    }
}
@Composable
fun CollectionScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Collection", color = Color.White)
            }

            Row {
                Icon(Icons.Default.Settings, contentDescription = "settings")
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
            }
        }

        Spacer(Modifier.height(30.dp))

        //Image placeholder
        Box(
            modifier = Modifier
                .size(100.dp)
                .align(Alignment.CenterHorizontally)
                .border(2.dp, Color.Black, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Favorite, contentDescription = "image")
        }

        Spacer(Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Collection Value")
        }

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Binders")
        }

        Spacer(Modifier.height(24.dp))

        //Grid of binder boxes
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            items(4) {

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .border(2.dp, Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Binder")
                }

            }
        }

    }
}
@Composable
fun DecksScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        //Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Decks", color = Color.White)
            }

            Row {
                Icon(Icons.Default.Settings, contentDescription = "settings")
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
            }
        }

        Spacer(Modifier.height(20.dp))

        // Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("Decks", color = Color(0xFF7A6DAF))
            Text("Explore")
        }

        Spacer(Modifier.height(20.dp))

        //Dropdown
        OutlinedTextField(
            value = "Value",
            onValueChange = {},
            label = { Text("Label") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        //Search bar
        OutlinedTextField(
            value = "",
            onValueChange = {},
            placeholder = { Text("Hinted search text") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = {
                Icon(Icons.Default.Menu, contentDescription = "menu")
            },
            trailingIcon = {
                Icon(Icons.Default.Search, contentDescription = "search")
            }
        )

        Spacer(Modifier.height(24.dp))

        // Deck grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            items(4) {

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .border(2.dp, Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Deck")
                }

            }

        }

    }
}
@Preview
@Composable
fun ScanScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //Scan Screen / icons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .background(Color(0xFF7A6DAF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Scan", color = Color.White)
            }

            Row {
                Icon(Icons.Default.Settings, contentDescription = "settings")
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AccountCircle, contentDescription = "profile")
            }
        }

        Box(
            modifier = Modifier
                .size(250.dp)
                .background(Color.LightGray, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Camera Preview")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {}) {
            Text("Scan")
        }

    }
}
@Preview
@Composable
fun PreviewScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(Color.LightGray),
            contentAlignment = Alignment.Center
        ) {
            Text("Image Preview")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row {

            Button(onClick = {}) {
                Text("Save")
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(onClick = {}) {
                Text("Cancel")
            }

        }

    }
}

*/
