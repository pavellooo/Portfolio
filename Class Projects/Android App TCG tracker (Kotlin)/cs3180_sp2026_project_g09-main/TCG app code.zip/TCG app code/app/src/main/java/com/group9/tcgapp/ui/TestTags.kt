package com.group9.tcgapp.ui

object TestTags {
    const val SCAN_BIN_BUTTON = "scan_bin_button"
    const val SCAN_FLASHLIGHT_BUTTON = "scan_flashlight_button"

    const val CARD_SELECTION_DIALOG = "card_selection_dialog"
    const val CARD_SELECTION_ITEM_PREFIX = "card_selection_item_"
    const val CARD_SELECTION_FOIL_PREFIX = "card_selection_foil_"

    const val SCANNED_BIN_DIALOG = "scanned_bin_dialog"
    const val SCANNED_BIN_SAVE_ALL = "scanned_bin_save_all"
    const val SCANNED_BIN_CLEAR_ALL = "scanned_bin_clear_all"
    const val SCANNED_BIN_EMPTY_TEXT = "scanned_bin_empty_text"
    const val SCANNED_BIN_ENTRY_PREFIX = "scanned_bin_entry_"
    const val SCANNED_BIN_SAVE_PREFIX = "scanned_bin_save_"
    const val SCANNED_BIN_REMOVE_PREFIX = "scanned_bin_remove_"
    const val SCANNED_BIN_FOIL_PREFIX = "scanned_bin_foil_"
}