package com.group9.tcgapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.group9.tcgapp.viewmodel.LanguageOption
import com.group9.tcgapp.viewmodel.RarityOption
import com.group9.tcgapp.viewmodel.SearchUiState
import com.group9.tcgapp.viewmodel.SearchViewModel
import com.group9.tcgapp.viewmodel.SortOption
import androidx.compose.ui.unit.dp

@Composable
fun SharedFiltersSection(
    vm: SearchViewModel,
    uiState: SearchUiState
) {
    val filters = uiState.shared

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Shared Filters",
            style = MaterialTheme.typography.titleMedium
        )

        OutlinedTextField(
            value = filters.setNameOrCode,
            onValueChange = vm::onSetNameOrCodeChanged,
            label = { Text("Set / Expansion") },
            modifier = Modifier,
            singleLine = true
        )

        OutlinedTextField(
            value = filters.cardNumber,
            onValueChange = vm::onCardNumberChanged,
            label = { Text("Card Number") },
            modifier = Modifier,
            singleLine = true
        )

        Text(text = "Rarity")
        FilterChipRow(
            options = listOf(
                RarityOption.ANY,
                RarityOption.COMMON,
                RarityOption.UNCOMMON,
                RarityOption.RARE,
                RarityOption.MYTHIC
            ),
            selected = filters.rarity,
            labelFor = { it.label },
            onSelected = vm::onRarityChanged
        )

        if (uiState.showAdvancedFilters) {
            Text(text = "Language")
            FilterChipRow(
                options = listOf(
                    LanguageOption.ANY,
                    LanguageOption.ENGLISH,
                    LanguageOption.JAPANESE
                ),
                selected = filters.language,
                labelFor = { it.label },
                onSelected = vm::onLanguageChanged
            )

            Text(text = "Sort")
            FilterChipRow(
                options = listOf(
                    SortOption.NAME_ASC,
                    SortOption.NAME_DESC,
                    SortOption.NUMBER_ASC
                ),
                selected = filters.sort,
                labelFor = {
                    when (it) {
                        SortOption.NAME_ASC -> "Name ↑"
                        SortOption.NAME_DESC -> "Name ↓"
                        SortOption.NUMBER_ASC -> "Number ↑"
                        SortOption.RARITY_ASC -> "Rarity"
                        SortOption.RELEASE_DATE_DESC -> "Newest"
                    }
                },
                onSelected = vm::onSortChanged
            )
        }
    }
}

@Composable
private fun <T> FilterChipRow(
    options: List<T>,
    selected: T,
    labelFor: (T) -> String,
    onSelected: (T) -> Unit
) {
    val rows = options.chunked(4)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { rowOptions ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowOptions.forEach { option ->
                    FilterChip(
                        selected = selected == option,
                        onClick = { onSelected(option) },
                        label = { Text(labelFor(option)) }
                    )
                }
            }
        }
    }
}