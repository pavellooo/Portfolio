package com.group9.tcgapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group9.tcgapp.data.local.entity.BinderEntity
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.remote.api.ScrydexConfig
import com.group9.tcgapp.data.repository.BinderRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class CollectionGame(val label: String, val apiPath: String) {
	POKEMON("Pokemon", ScrydexConfig.GAME_POKEMON),
	MTG("MTG", ScrydexConfig.GAME_MAGIC)
}

class CollectionViewModel(
	private val collectionRepository: CollectionRepository? = null,
	private val binderRepository: BinderRepository? = null
) : ViewModel() {
	var collectionValue by mutableStateOf("Collection Value")
		private set

	var bindersTitle by mutableStateOf("Binders")
		private set

	var selectedCollection by mutableStateOf(CollectionGame.POKEMON)
		private set

	var cardsInCollection by mutableStateOf<List<CardEntity>>(emptyList())
		private set

	var binders by mutableStateOf<List<BinderEntity>>(emptyList())
		private set

	var binderCardCounts by mutableStateOf<Map<Long, Int>>(emptyMap())
		private set

	var selectedCardForBinder by mutableStateOf<CardEntity?>(null)
		private set

	var selectedBinderIds by mutableStateOf<Set<Long>>(emptySet())
		private set

	var showCreateBinderDialog by mutableStateOf(false)
		private set

	var newBinderName by mutableStateOf("")
		private set

	var statusMessage by mutableStateOf<String?>(null)
		private set

	private var observeCardsJob: Job? = null
	private var observeBindersJob: Job? = null

	init {
		observeSelectedCollection()
		observeBinders()
	}

	fun onCollectionSelected(value: CollectionGame) {
		if (selectedCollection == value) {
			return
		}

		selectedCollection = value
		observeSelectedCollection()
		observeBinders()
	}

	private fun observeSelectedCollection() {
		val repo = collectionRepository ?: return
		observeCardsJob?.cancel()
		observeCardsJob = viewModelScope.launch {
			repo.getOwnedCardsByGameFlow(selectedCollection.apiPath).collectLatest { cards ->
				cardsInCollection = cards
				collectionValue = "${selectedCollection.label} cards: ${cards.size}"
			}
		}
	}

	private fun observeBinders() {
		val repo = binderRepository ?: return
		observeBindersJob?.cancel()
		observeBindersJob = viewModelScope.launch {
			repo.getBindersByGameFlow(selectedCollection.apiPath).collectLatest { values ->
				binders = values
				bindersTitle = "${selectedCollection.label} binders (${values.size})"
				
				// Fetch card counts for all binders
				val counts = mutableMapOf<Long, Int>()
				values.forEach { binder ->
					counts[binder.binderId] = repo.getCardCountForBinder(binder.binderId)
				}
				binderCardCounts = counts
			}
		}
	}

	fun onCardSelected(card: CardEntity) {
		selectedCardForBinder = card
		selectedBinderIds = emptySet()
	}

	fun dismissCardDialog() {
		selectedCardForBinder = null
		selectedBinderIds = emptySet()
	}

	fun toggleBinderSelection(binderId: Long) {
		selectedBinderIds = if (binderId in selectedBinderIds) {
			selectedBinderIds - binderId
		} else {
			selectedBinderIds + binderId
		}
	}

	fun addSelectedCardToBinders() {
		val card = selectedCardForBinder ?: return
		val binderIds = selectedBinderIds.toList()
		val repo = binderRepository ?: return

		if (binderIds.isEmpty()) {
			statusMessage = "Select at least one binder."
			return
		}

		viewModelScope.launch {
			binderIds.forEach { binderId ->
				repo.addCardToBinder(binderId, card.id)
			}
			statusMessage = "Added ${card.name} to ${binderIds.size} binder(s)."
			dismissCardDialog()
		}
	}

	fun openCreateBinderDialog() {
		showCreateBinderDialog = true
		newBinderName = ""
	}

	fun dismissCreateBinderDialog() {
		showCreateBinderDialog = false
		newBinderName = ""
	}

	fun onNewBinderNameChanged(value: String) {
		newBinderName = value
	}

	fun createBinder() {
		val binderName = newBinderName.trim()
		val repo = binderRepository ?: return
		if (binderName.isBlank()) {
			statusMessage = "Enter a binder name."
			return
		}

		viewModelScope.launch {
			repo.createBinder(gameType = selectedCollection.apiPath, name = binderName)
			statusMessage = "Created binder: $binderName"
			dismissCreateBinderDialog()
		}
	}

	fun clearStatusMessage() {
		statusMessage = null
	}
}