package com.group9.tcgapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.local.entity.UserCollectionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollectionEntry(entry: UserCollectionEntity)

    @Query("SELECT * FROM user_collection ORDER BY lastUpdated DESC")
    fun getUserCollectionFlow(): Flow<List<UserCollectionEntity>>

    @Query("SELECT * FROM user_collection WHERE cardId = :cardId LIMIT 1")
    fun getCollectionEntryFlow(cardId: String): Flow<UserCollectionEntity?>

    @Query(
        """
        SELECT cards.* FROM cards
        INNER JOIN user_collection ON user_collection.cardId = cards.id
        WHERE cards.game = :game
        ORDER BY cards.name ASC
        """
    )
    fun getOwnedCardsByGameFlow(game: String): Flow<List<CardEntity>>

    @Query("DELETE FROM user_collection WHERE cardId = :cardId")
    suspend fun deleteCollectionEntry(cardId: String)
}