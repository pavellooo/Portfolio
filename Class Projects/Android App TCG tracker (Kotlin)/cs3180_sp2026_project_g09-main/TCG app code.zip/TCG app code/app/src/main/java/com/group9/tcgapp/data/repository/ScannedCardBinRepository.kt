package com.group9.tcgapp.data.repository

import com.group9.tcgapp.viewmodel.CardSearchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ScannedCardEntry(
    val card: CardSearchResult,
    val isFoil: Boolean = false,
    val scannedAt: Long = System.currentTimeMillis()
) {
    val localId: String = "${card.game}-${card.id}-$scannedAt"
}

class ScannedCardBinRepository {

    private val _scannedCards = MutableStateFlow<List<ScannedCardEntry>>(emptyList())
    val scannedCards: StateFlow<List<ScannedCardEntry>> = _scannedCards.asStateFlow()

    fun addCard(card: CardSearchResult, isFoil: Boolean): Boolean {
        val last = _scannedCards.value.lastOrNull()

        if (last?.card?.id == card.id && last.card.game == card.game) {
            return false
        }

        _scannedCards.value = _scannedCards.value + ScannedCardEntry(
            card = card,
            isFoil = isFoil
        )

        return true
    }

    fun setFoilStatus(localId: String, isFoil: Boolean) {
        _scannedCards.value = _scannedCards.value.map { entry ->
            if (entry.localId == localId) {
                entry.copy(isFoil = isFoil)
            } else {
                entry
            }
        }
    }

    fun removeEntry(localId: String) {
        _scannedCards.value = _scannedCards.value.filterNot { entry ->
            entry.localId == localId
        }
    }

    fun clearBin() {
        _scannedCards.value = emptyList()
    }
}