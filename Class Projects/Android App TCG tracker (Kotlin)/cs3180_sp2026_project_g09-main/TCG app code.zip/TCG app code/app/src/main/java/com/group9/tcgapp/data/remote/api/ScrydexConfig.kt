package com.group9.tcgapp.data.remote.api

object ScrydexConfig {
    const val GAME_MAGIC = "magicthegathering"
    const val GAME_POKEMON = "pokemon"
}