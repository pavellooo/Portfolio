package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.local.dao.DeckDao
import com.group9.tcgapp.data.local.entity.DeckCardCrossRef
import com.group9.tcgapp.data.local.entity.DeckEntity
import kotlinx.coroutines.flow.Flow

sealed interface DeckUpdateResult {
    data object Success : DeckUpdateResult
    data class DeckNotFound(val deckId: Long) : DeckUpdateResult
    data class CardNotOwned(val cardId: String) : DeckUpdateResult
    data class ExceedsOwnedCopies(val ownedCopies: Int) : DeckUpdateResult
    data class ExceedsPerCardLimit(val limit: Int) : DeckUpdateResult
    data class ExceedsDeckSize(val limit: Int) : DeckUpdateResult
}

class DeckRepository(
    private val deckDao: DeckDao,
    private val collectionRepository: CollectionRepository,
    private val rulesProvider: DeckRulesProvider = DeckRulesConfig
) {

    fun getDecksByGameFlow(gameType: String): Flow<List<DeckEntity>> {
        return deckDao.getDecksByGameFlow(gameType)
    }

    fun getDeckSummariesByGameFlow(gameType: String): Flow<List<DeckDao.DeckSummaryRow>> {
        return deckDao.getDeckSummariesByGameFlow(gameType)
    }

    fun getAllDeckSummariesFlow(): Flow<List<DeckDao.DeckSummaryRow>> {
        return deckDao.getAllDeckSummariesFlow()
    }

    fun getDeckByIdFlow(deckId: Long): Flow<DeckEntity?> {
        return deckDao.getDeckByIdFlow(deckId)
    }

    fun getDeckCardRowsFlow(deckId: Long): Flow<List<DeckDao.DeckCardRow>> {
        return deckDao.getDeckCardRowsFlow(deckId)
    }

    fun getTotalCardCountForDeckFlow(deckId: Long): Flow<Int> {
        return deckDao.getTotalCardQuantityForDeckFlow(deckId)
    }

    suspend fun getTotalCardCountForDeck(deckId: Long): Int {
        return deckDao.getTotalCardQuantityForDeck(deckId)
    }

    suspend fun createDeck(gameType: String, name: String, description: String? = null): Long {
        return deckDao.insertDeck(
            DeckEntity(
                gameType = gameType,
                name = name,
                description = description
            )
        )
    }

    suspend fun renameDeck(deckId: Long, name: String, description: String? = null) {
        deckDao.updateDeck(deckId, name, description)
    }

    suspend fun deleteDeck(deckId: Long) {
        deckDao.deleteDeck(deckId)
    }

    suspend fun addOneCopy(deckId: Long, cardId: String): DeckUpdateResult {
        val deck = deckDao.getDeckById(deckId) ?: return DeckUpdateResult.DeckNotFound(deckId)
        val rules = rulesProvider.rulesForGame(deck.gameType)

        val ownedCopies = collectionRepository.getOwnedQuantity(cardId)
        if (!rules.allowUnownedCards && ownedCopies <= 0) {
            return DeckUpdateResult.CardNotOwned(cardId)
        }

        val currentCardCopies = deckDao.getQuantityForCard(deckId, cardId) ?: 0
        val proposedCardCopies = currentCardCopies + 1
        if (proposedCardCopies > rules.maxCopiesPerCard) {
            return DeckUpdateResult.ExceedsPerCardLimit(rules.maxCopiesPerCard)
        }

        if (rules.enforceOwnedCopyLimit && proposedCardCopies > ownedCopies) {
            return DeckUpdateResult.ExceedsOwnedCopies(ownedCopies)
        }

        val totalCardsInDeck = deckDao.getTotalCardQuantityForDeck(deckId)
        val proposedDeckSize = totalCardsInDeck + 1
        if (proposedDeckSize > rules.maxMainDeckSize) {
            return DeckUpdateResult.ExceedsDeckSize(rules.maxMainDeckSize)
        }

        deckDao.upsertDeckCard(
            DeckCardCrossRef(
                deckId = deckId,
                cardId = cardId,
                quantityInDeck = proposedCardCopies
            )
        )

        return DeckUpdateResult.Success
    }

    suspend fun removeOneCopy(deckId: Long, cardId: String) {
        val current = deckDao.getQuantityForCard(deckId, cardId) ?: return
        val next = current - 1

        if (next <= 0) {
            deckDao.removeCardFromDeck(deckId, cardId)
            return
        }

        deckDao.upsertDeckCard(
            DeckCardCrossRef(
                deckId = deckId,
                cardId = cardId,
                quantityInDeck = next
            )
        )
    }

    suspend fun removeCard(deckId: Long, cardId: String) {
        deckDao.removeCardFromDeck(deckId, cardId)
    }

    fun getRulesForGame(gameType: String): DeckRuleSet {
        return rulesProvider.rulesForGame(gameType)
    }

    suspend fun isDeckSizeValid(deckId: Long): Boolean {
        val deck = deckDao.getDeckById(deckId) ?: return false
        val rules = rulesProvider.rulesForGame(deck.gameType)
        val total = deckDao.getTotalCardQuantityForDeck(deckId)
        return rules.isDeckSizeValid(total)
    }
}
