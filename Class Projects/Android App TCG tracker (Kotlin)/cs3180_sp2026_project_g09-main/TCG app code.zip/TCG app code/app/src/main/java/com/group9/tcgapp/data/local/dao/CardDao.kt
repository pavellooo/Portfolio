package com.group9.tcgapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.group9.tcgapp.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CardDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<CardEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpansions(expansions: List<ExpansionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRules(rules: List<CardRuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRulings(rulings: List<CardRulingEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTypes(types: List<CardTypeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubtypes(subtypes: List<CardSubtypeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupertypes(supertypes: List<CardSupertypeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColors(colors: List<CardColorEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColorIdentity(colors: List<CardColorIdentityEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeywords(keywords: List<CardKeywordEntity>)

    @Query("SELECT * FROM cards WHERE game = :game ORDER BY name ASC")
    fun getAllCardsFlow(game: String): Flow<List<CardEntity>>

    @Query("SELECT * FROM cards WHERE id = :cardId LIMIT 1")
    fun getCardByIdFlow(cardId: String): Flow<CardEntity?>

    @Transaction
    @Query("SELECT * FROM cards WHERE id = :cardId LIMIT 1")
    fun getCardWithDetailsFlow(cardId: String): Flow<CardWithDetails?>

    @Query("""
        SELECT * FROM cards
        WHERE game = :game AND name LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun searchCardsFlow(game: String, query: String): Flow<List<CardEntity>>

    @Query("SELECT COUNT(*) FROM cards WHERE game = :game")
    suspend fun getCardCount(game: String): Int

    @Query("SELECT expansionId FROM cards WHERE id = :cardId LIMIT 1")
    suspend fun getExpansionIdForCard(cardId: String): String?

    @Query("DELETE FROM card_rules WHERE cardId = :cardId")
    suspend fun deleteRulesForCard(cardId: String)

    @Query("DELETE FROM card_rulings WHERE cardId = :cardId")
    suspend fun deleteRulingsForCard(cardId: String)

    @Query("DELETE FROM card_types WHERE cardId = :cardId")
    suspend fun deleteTypesForCard(cardId: String)

    @Query("DELETE FROM card_subtypes WHERE cardId = :cardId")
    suspend fun deleteSubtypesForCard(cardId: String)

    @Query("DELETE FROM card_supertypes WHERE cardId = :cardId")
    suspend fun deleteSupertypesForCard(cardId: String)

    @Query("DELETE FROM card_colors WHERE cardId = :cardId")
    suspend fun deleteColorsForCard(cardId: String)

    @Query("DELETE FROM card_color_identity WHERE cardId = :cardId")
    suspend fun deleteColorIdentityForCard(cardId: String)

    @Query("DELETE FROM card_keywords WHERE cardId = :cardId")
    suspend fun deleteKeywordsForCard(cardId: String)

    @Query("DELETE FROM binder_cards WHERE cardId = :cardId")
    suspend fun deleteBinderLinksForCard(cardId: String)

    @Query("DELETE FROM deck_cards WHERE cardId = :cardId")
    suspend fun deleteDeckLinksForCard(cardId: String)

    @Query("DELETE FROM user_collection WHERE cardId = :cardId")
    suspend fun deleteCollectionEntryForCard(cardId: String)

    @Query("DELETE FROM cards WHERE id = :cardId")
    suspend fun deleteCardById(cardId: String)

    @Query("DELETE FROM expansions WHERE id = :expansionId AND NOT EXISTS (SELECT 1 FROM cards WHERE expansionId = :expansionId)")
    suspend fun deleteExpansionIfOrphaned(expansionId: String)

    @Query("DELETE FROM cards WHERE game = :game")
    suspend fun deleteAllCardsForGame(game: String)

    @Query("DELETE FROM card_rules WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteRulesForGame(game: String)

    @Query("DELETE FROM card_rulings WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteRulingsForGame(game: String)

    @Query("DELETE FROM card_types WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteTypesForGame(game: String)

    @Query("DELETE FROM card_subtypes WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteSubtypesForGame(game: String)

    @Query("DELETE FROM card_supertypes WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteSupertypesForGame(game: String)

    @Query("DELETE FROM card_colors WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteColorsForGame(game: String)

    @Query("DELETE FROM card_color_identity WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteColorIdentityForGame(game: String)

    @Query("DELETE FROM card_keywords WHERE cardId IN (SELECT id FROM cards WHERE game = :game)")
    suspend fun deleteKeywordsForGame(game: String)

    @Transaction
    suspend fun deleteCardAndRelated(cardId: String) {
        val expansionId = getExpansionIdForCard(cardId)

        deleteRulesForCard(cardId)
        deleteRulingsForCard(cardId)
        deleteTypesForCard(cardId)
        deleteSubtypesForCard(cardId)
        deleteSupertypesForCard(cardId)
        deleteColorsForCard(cardId)
        deleteColorIdentityForCard(cardId)
        deleteKeywordsForCard(cardId)
        deleteBinderLinksForCard(cardId)
        deleteDeckLinksForCard(cardId)
        deleteCollectionEntryForCard(cardId)
        deleteCardById(cardId)

        if (expansionId != null) {
            deleteExpansionIfOrphaned(expansionId)
        }
    }

    @Transaction
    suspend fun replaceAllCardsForGame(
        game: String,
        cards: List<CardEntity>,
        expansions: List<ExpansionEntity>,
        rules: List<CardRuleEntity>,
        rulings: List<CardRulingEntity>,
        types: List<CardTypeEntity>,
        subtypes: List<CardSubtypeEntity>,
        supertypes: List<CardSupertypeEntity>,
        colors: List<CardColorEntity>,
        colorIdentity: List<CardColorIdentityEntity>,
        keywords: List<CardKeywordEntity>
    ) {
        deleteRulesForGame(game)
        deleteRulingsForGame(game)
        deleteTypesForGame(game)
        deleteSubtypesForGame(game)
        deleteSupertypesForGame(game)
        deleteColorsForGame(game)
        deleteColorIdentityForGame(game)
        deleteKeywordsForGame(game)
        deleteAllCardsForGame(game)

        insertExpansions(expansions)
        insertCards(cards)
        insertRules(rules)
        insertRulings(rulings)
        insertTypes(types)
        insertSubtypes(subtypes)
        insertSupertypes(supertypes)
        insertColors(colors)
        insertColorIdentity(colorIdentity)
        insertKeywords(keywords)
    }
}