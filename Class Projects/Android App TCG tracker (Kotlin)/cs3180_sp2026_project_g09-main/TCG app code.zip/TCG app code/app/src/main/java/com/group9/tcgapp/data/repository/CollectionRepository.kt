package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.local.dao.CollectionDao
import com.group9.tcgapp.data.local.entity.CardEntity
import com.group9.tcgapp.data.local.entity.UserCollectionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class CollectionRepository(
    private val collectionDao: CollectionDao
) {
    fun getOwnedCardsByGameFlow(game: String): Flow<List<CardEntity>> {
        return collectionDao.getOwnedCardsByGameFlow(game)
    }

    fun getUserCollectionFlow(): Flow<List<UserCollectionEntity>> {
        return collectionDao.getUserCollectionFlow()
    }

    fun getCollectionEntryFlow(cardId: String): Flow<UserCollectionEntity?> {
        return collectionDao.getCollectionEntryFlow(cardId)
    }

    suspend fun getOwnedQuantity(cardId: String): Int {
        return getCollectionEntryFlow(cardId).first()?.quantityOwned ?: 0
    }

    suspend fun updateOwnedQuantity(
        cardId: String,
        quantity: Int,
        condition: String? = null,
        notes: String? = null,
        isFavorite: Boolean = false
    ) {
        if (quantity <= 0) {
            collectionDao.deleteCollectionEntry(cardId)
            return
        }

        collectionDao.upsertCollectionEntry(
            UserCollectionEntity(
                cardId = cardId,
                quantityOwned = quantity,
                condition = condition,
                notes = notes,
                isFavorite = isFavorite
            )
        )
    }

    suspend fun incrementOwnedQuantity(cardId: String) {
        val existing = getCollectionEntryFlow(cardId).first()
        val nextQuantity = (existing?.quantityOwned ?: 0) + 1

        updateOwnedQuantity(
            cardId = cardId,
            quantity = nextQuantity,
            condition = existing?.condition,
            notes = existing?.notes,
            isFavorite = existing?.isFavorite ?: false
        )
    }

    suspend fun decrementOwnedQuantity(cardId: String) {
        val existing = getCollectionEntryFlow(cardId).first() ?: return
        val nextQuantity = existing.quantityOwned - 1

        updateOwnedQuantity(
            cardId = cardId,
            quantity = nextQuantity,
            condition = existing.condition,
            notes = existing.notes,
            isFavorite = existing.isFavorite
        )
    }
}