package com.group9.tcgapp.data.repository

import com.group9.tcgapp.data.remote.api.ScrydexConfig

data class DeckRuleSet(
    val minMainDeckSize: Int,
    val maxMainDeckSize: Int,
    val maxCopiesPerCard: Int,
    val allowUnownedCards: Boolean,
    val enforceOwnedCopyLimit: Boolean
)

fun interface DeckRulesProvider {
    fun rulesForGame(gameType: String): DeckRuleSet
}

object DeckRulesConfig : DeckRulesProvider {
    private val defaultRules = DeckRuleSet(
        minMainDeckSize = 60,
        maxMainDeckSize = 60,
        maxCopiesPerCard = 4,
        allowUnownedCards = false,
        enforceOwnedCopyLimit = true
    )

    private val rulesByGame: MutableMap<String, DeckRuleSet> = mutableMapOf(
        ScrydexConfig.GAME_POKEMON to defaultRules,
        ScrydexConfig.GAME_MAGIC to defaultRules
    )

    override fun rulesForGame(gameType: String): DeckRuleSet {
        return rulesByGame[gameType] ?: defaultRules
    }

    fun setRulesForGame(gameType: String, rules: DeckRuleSet) {
        rulesByGame[gameType] = rules
    }
}

fun DeckRuleSet.isDeckSizeValid(totalCards: Int): Boolean {
    return totalCards in minMainDeckSize..maxMainDeckSize
}
