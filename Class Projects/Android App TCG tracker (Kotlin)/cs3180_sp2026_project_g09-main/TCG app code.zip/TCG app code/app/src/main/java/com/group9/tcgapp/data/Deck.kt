package com.group9.tcgapp.data

data class Deck(
    val id: String,
    val name: String,
    val cardIds: List<String> = emptyList()
)