package com.group9.tcgapp.ui

import com.group9.tcgapp.viewmodel.CollectionGame
import com.group9.tcgapp.viewmodel.DecksViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class DecksViewModelTest {

    private lateinit var viewModel: DecksViewModel

    @Before
    fun setup() {
        // For basic state testing, we can pass null repositories 
        // if the methods we test don't trigger observations immediately.
        viewModel = DecksViewModel(null, null)
    }

    @Test
    fun `onCollectionSelected updates selectedCollection and clears selectedDeck`() {
        // Given
        viewModel.onCollectionSelected(CollectionGame.MTG)
        
        // When switching
        viewModel.onCollectionSelected(CollectionGame.POKEMON)

        // Then
        assertEquals(CollectionGame.POKEMON, viewModel.selectedCollection)
        assertNull(viewModel.selectedDeck)
    }

    @Test
    fun `openCreateDeckDialog resets state and shows dialog`() {
        // When
        viewModel.openCreateDeckDialog()

        // Then
        assertTrue(viewModel.showCreateDeckDialog)
        assertEquals("", viewModel.newDeckName)
    }

    @Test
    fun `onNewDeckNameChanged updates newDeckName`() {
        // Given
        val name = "My Fire Deck"

        // When
        viewModel.onNewDeckNameChanged(name)

        // Then
        assertEquals(name, viewModel.newDeckName)
    }
}