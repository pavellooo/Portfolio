package com.group9.tcgapp

import com.group9.tcgapp.viewmodel.SearchViewModel
import com.group9.tcgapp.data.repository.SearchRepository
import com.group9.tcgapp.data.repository.CardRepository
import com.group9.tcgapp.data.repository.CollectionRepository
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class SearchViewModelBasicTest {
    private lateinit var viewModel: SearchViewModel

    // Provide working dummy implementations for required interfaces
    @Before
    fun setup() {
        val dummyApi = object : com.group9.tcgapp.data.remote.api.ScrydexAPI {
            override suspend fun getCardById(
                game: String,
                cardId: String
            ): com.group9.tcgapp.data.remote.dto.CardSingleResponseDto {
                return com.group9.tcgapp.data.remote.dto.CardSingleResponseDto(null)
            }
            override suspend fun searchCards(
                game: String,
                query: String,
                page: Int,
                pageSize: Int
            ): com.group9.tcgapp.data.remote.dto.CardSearchResponseDto {
                return com.group9.tcgapp.data.remote.dto.CardSearchResponseDto(emptyList())
            }
        }
        val dummyCardDao = object : com.group9.tcgapp.data.local.dao.CardDao {
            override suspend fun insertCards(cards: List<com.group9.tcgapp.data.local.entity.CardEntity>) {}
            override suspend fun insertExpansions(expansions: List<com.group9.tcgapp.data.local.entity.ExpansionEntity>) {}
            override suspend fun insertRules(rules: List<com.group9.tcgapp.data.local.entity.CardRuleEntity>) {}
            override suspend fun insertRulings(rulings: List<com.group9.tcgapp.data.local.entity.CardRulingEntity>) {}
            override suspend fun insertTypes(types: List<com.group9.tcgapp.data.local.entity.CardTypeEntity>) {}
            override suspend fun insertSubtypes(subtypes: List<com.group9.tcgapp.data.local.entity.CardSubtypeEntity>) {}
            override suspend fun insertSupertypes(supertypes: List<com.group9.tcgapp.data.local.entity.CardSupertypeEntity>) {}
            override suspend fun insertColors(colors: List<com.group9.tcgapp.data.local.entity.CardColorEntity>) {}
            override suspend fun insertColorIdentity(colors: List<com.group9.tcgapp.data.local.entity.CardColorIdentityEntity>) {}
            override suspend fun insertKeywords(keywords: List<com.group9.tcgapp.data.local.entity.CardKeywordEntity>) {}
            override fun getAllCardsFlow(game: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.group9.tcgapp.data.local.entity.CardEntity>())
            override fun getCardByIdFlow(cardId: String) = kotlinx.coroutines.flow.flowOf(null)
            override fun getCardWithDetailsFlow(cardId: String) = kotlinx.coroutines.flow.flowOf(null)
            override fun searchCardsFlow(game: String, query: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.group9.tcgapp.data.local.entity.CardEntity>())
            override suspend fun getCardCount(game: String) = 0
            override suspend fun getExpansionIdForCard(cardId: String) = null
            override suspend fun deleteRulesForCard(cardId: String) {}
            override suspend fun deleteRulingsForCard(cardId: String) {}
            override suspend fun deleteTypesForCard(cardId: String) {}
            override suspend fun deleteSubtypesForCard(cardId: String) {}
            override suspend fun deleteSupertypesForCard(cardId: String) {}
            override suspend fun deleteColorsForCard(cardId: String) {}
            override suspend fun deleteColorIdentityForCard(cardId: String) {}
            override suspend fun deleteKeywordsForCard(cardId: String) {}
            override suspend fun deleteBinderLinksForCard(cardId: String) {}
            override suspend fun deleteDeckLinksForCard(cardId: String) {}
            override suspend fun deleteCollectionEntryForCard(cardId: String) {}
            override suspend fun deleteCardById(cardId: String) {}
            override suspend fun deleteExpansionIfOrphaned(expansionId: String) {}
            override suspend fun deleteAllCardsForGame(game: String) {}
            override suspend fun deleteRulesForGame(game: String) {}
            override suspend fun deleteRulingsForGame(game: String) {}
            override suspend fun deleteTypesForGame(game: String) {}
            override suspend fun deleteSubtypesForGame(game: String) {}
            override suspend fun deleteSupertypesForGame(game: String) {}
            override suspend fun deleteColorsForGame(game: String) {}
            override suspend fun deleteColorIdentityForGame(game: String) {}
            override suspend fun deleteKeywordsForGame(game: String) {}
        }
        val dummyCollectionDao = object : com.group9.tcgapp.data.local.dao.CollectionDao {
            override suspend fun upsertCollectionEntry(entry: com.group9.tcgapp.data.local.entity.UserCollectionEntity) {}
            override fun getUserCollectionFlow() = kotlinx.coroutines.flow.flowOf(emptyList<com.group9.tcgapp.data.local.entity.UserCollectionEntity>())
            override fun getCollectionEntryFlow(cardId: String) = kotlinx.coroutines.flow.flowOf(null)
            override fun getOwnedCardsByGameFlow(game: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.group9.tcgapp.data.local.entity.CardEntity>())
            override suspend fun deleteCollectionEntry(cardId: String) {}
        }
        val searchRepository = com.group9.tcgapp.data.repository.SearchRepository(dummyApi)
        val cardRepository = com.group9.tcgapp.data.repository.CardRepository(dummyApi, dummyCardDao)
        val collectionRepository = com.group9.tcgapp.data.repository.CollectionRepository(dummyCollectionDao)
        viewModel = SearchViewModel(searchRepository, cardRepository, collectionRepository)
    }

    @Test
    fun `onQueryChanged updates query in state`() {
        viewModel.onQueryChanged("Charizard")
        assertEquals("Charizard", viewModel.uiState.value.shared.query)
    }

    @Test
    fun `onGameSelected updates selectedGame`() {
        val game = com.group9.tcgapp.viewmodel.GameType.MTG
        viewModel.onGameSelected(game)
        assertEquals(game, viewModel.uiState.value.selectedGame)
    }
}
