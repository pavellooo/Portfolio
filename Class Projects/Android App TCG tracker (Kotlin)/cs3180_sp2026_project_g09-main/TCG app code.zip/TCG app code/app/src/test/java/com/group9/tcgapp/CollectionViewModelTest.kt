package com.group9.tcgapp.ui

import com.group9.tcgapp.viewmodel.CollectionGame
import com.group9.tcgapp.viewmodel.CollectionViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CollectionViewModelTest {

    private lateinit var viewModel: CollectionViewModel

    @Before
    fun setup() {
        // Repositories are null because we are testing UI state logic, not database logic
        viewModel = CollectionViewModel(null, null)
    }

    @Test
    fun `onCollectionSelected updates selected game`() {
        // When
        viewModel.onCollectionSelected(CollectionGame.MTG)

        // Then
        assertEquals(CollectionGame.MTG, viewModel.selectedCollection)
    }

    @Test
    fun `openCreateBinderDialog prepares UI state`() {
        // When
        viewModel.openCreateBinderDialog()

        // Then
        assertTrue(viewModel.showCreateBinderDialog)
        assertEquals("", viewModel.newBinderName)
    }

    @Test
    fun `dismissCreateBinderDialog clears UI state`() {
        viewModel.dismissCreateBinderDialog()

        // Then
        assertFalse(viewModel.showCreateBinderDialog)
    }

    @Test
    fun `onNewBinderNameChanged updates UI state`() {
        viewModel.onNewBinderNameChanged("New Binder")
        assertEquals("New Binder", viewModel.newBinderName)
    }

    @Test
    fun `toggleBinderSelection updates selected set`() {
        // When
        viewModel.toggleBinderSelection(1L)
        viewModel.toggleBinderSelection(2L)

        // Then
        assertTrue(viewModel.selectedBinderIds.contains(1L))
        assertTrue(viewModel.selectedBinderIds.contains(2L))

        // Toggle off
        viewModel.toggleBinderSelection(1L)
        assertFalse(viewModel.selectedBinderIds.contains(1L))
    }

    @Test
    fun `clearStatusMessage resets message to null`() {
        // This tests the explicit call to clear the message.
        viewModel.clearStatusMessage()
        assertEquals(null, viewModel.statusMessage)
    }

    @Test
    fun `dismissCardDialog resets selection state`() {
        viewModel.dismissCardDialog()
        assertEquals(null, viewModel.selectedCardForBinder)
        assertTrue(viewModel.selectedBinderIds.isEmpty())
    }
}