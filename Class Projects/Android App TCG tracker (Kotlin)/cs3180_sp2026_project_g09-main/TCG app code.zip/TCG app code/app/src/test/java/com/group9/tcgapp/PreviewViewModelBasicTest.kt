package com.group9.tcgapp

import com.group9.tcgapp.viewmodel.PreviewViewModel
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class PreviewViewModelBasicTest {
    private lateinit var viewModel: PreviewViewModel

    @Before
    fun setup() {
        viewModel = PreviewViewModel()
    }

    @Test
    fun `onSave sets statusMessage to Saved`() {
        viewModel.onSave()
        assertEquals("Saved", viewModel.statusMessage)
    }

    @Test
    fun `onCancel sets statusMessage to Canceled`() {
        viewModel.onCancel()
        assertEquals("Canceled", viewModel.statusMessage)
    }
}
