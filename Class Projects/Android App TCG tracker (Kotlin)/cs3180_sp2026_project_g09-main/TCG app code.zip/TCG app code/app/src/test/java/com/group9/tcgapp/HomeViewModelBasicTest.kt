package com.group9.tcgapp

import com.group9.tcgapp.viewmodel.HomeViewModel
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class HomeViewModelBasicTest {
    private lateinit var viewModel: HomeViewModel

    @Before
    fun setup() {
        viewModel = HomeViewModel()
    }

    @Test
    fun `searchText updates correctly`() {
        viewModel.searchText = "Pikachu"
        assertEquals("Pikachu", viewModel.searchText)
    }
}
