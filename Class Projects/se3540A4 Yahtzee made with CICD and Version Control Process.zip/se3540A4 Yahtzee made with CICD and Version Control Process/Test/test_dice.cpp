#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../src/yahtzee.cpp"

TEST_CASE("Dice class functionality") {
    Dice d;

    SECTION("Rolling a non-held die sets value between 1 and 6") {
        d.release(); // ensure not held
        d.roll();
        int val = d.getValue();
        REQUIRE(val >= 1);
        REQUIRE(val <= 6);
    }

    SECTION("Holding a die prevents value change on roll") {
        d.release();
        d.roll();
        int beforeHold = d.getValue();
        d.hold();
        d.roll();
        int afterHold = d.getValue();
        REQUIRE(beforeHold == afterHold);
    }

    SECTION("Releasing a die allows rolling again") {
        d.hold();
        d.roll(); // should not change
        int beforeRelease = d.getValue();
        d.release();
        d.roll();
        int afterRelease = d.getValue();
        REQUIRE(afterRelease >= 1);
        REQUIRE(afterRelease <= 6);
    }

    SECTION("held() returns correct state") {
        d.release();
        REQUIRE(d.getIsHeld() == false);
        d.hold();
        REQUIRE(d.getIsHeld() == true);
    }
}