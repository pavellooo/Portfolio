#define CATCH_CONFIG_MAIN
#define NO_MAIN
#include "catch.hpp"
#include "../src/yahtzee.cpp" 

TEST_CASE("Game End Conditions", "[GameState]") {
    ScoreCard sc;

    SECTION("New Scorecard is NOT full") {
        // Assuming you have a function like isFull() or you check availability
        // If you don't have isFull(), we check that categories are available
        REQUIRE(sc.checkIfCategoryIsAvailable(ONES) == true);
        REQUIRE(sc.checkIfCategoryIsAvailable(YAHTZEE) == true);
    }

    SECTION("Game ends when all categories are filled") {
        // Fill out the Upper Section
        sc.selectCategory(ONES, 3);
        sc.selectCategory(TWOS, 6);
        sc.selectCategory(THREES, 9);
        sc.selectCategory(FOURS, 12);
        sc.selectCategory(FIVES, 15);
        sc.selectCategory(SIXES, 18);

        // Fill out the Lower Section
        sc.selectCategory(THREE_OF_A_KIND, 20);
        sc.selectCategory(FOUR_OF_A_KIND, 25);
        sc.selectCategory(FULL_HOUSE, 25);
        sc.selectCategory(SMALL_STRAIGHT, 30);
        sc.selectCategory(LARGE_STRAIGHT, 40);
        sc.selectCategory(YAHTZEE, 50);
        sc.selectCategory(CHANCE, 15);
        // Don't forget the Bonus slot if your game tracks it as a category!
        // sc.selectCategory(YAHTZEE_BONUS, 0); 

        // NOW, verify the game knows it's done.
        // If your class has a isFull() method:
        // REQUIRE(sc.isFull() == true);

        // If not, verify you CANNOT select anything else
        REQUIRE(sc.checkIfCategoryIsAvailable(ONES) == false);
        REQUIRE(sc.checkIfCategoryIsAvailable(CHANCE) == false);
    }
}