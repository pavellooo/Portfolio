#define CATCH_CONFIG_MAIN // you are supposed to only have this in one test file but I found it was needed in every one to avoid linker errors
#include "catch.hpp" 
#include "../src/yahtzee.cpp"  // include your main game code

// Subclass ScoreCard to expose protected members for testing
class TestScoreCard : public ScoreCard {
public:
    using ScoreCard::savedScores;
    using ScoreCard::categoryUsed;
};

TEST_CASE("Upper section scoring (ONES, TWOS, etc.)", "[scorecard]") {
    TestScoreCard sc;
    int dice[5] = {1, 2, 1, 4, 1};

    int score = sc.calcUpperScore(ONES, dice);
    REQUIRE(score == 3);

    sc.selectCategory(ONES, score);
    REQUIRE(sc.checkIfCategoryIsAvailable(ONES) == false);
}

TEST_CASE("Full House scoring", "[scorecard]") {
    TestScoreCard sc;
    int dice[5] = {3, 3, 3, 2, 2};
    int score = sc.calcFullHouse(dice);
    REQUIRE(score == 25);
}

TEST_CASE("Yahtzee scoring", "[scorecard]") {
    TestScoreCard sc;
    int dice[5] = {6, 6, 6, 6, 6};
    int score = sc.calcYahtzee(dice);
    REQUIRE(score == 50);
}

TEST_CASE("Chance scoring", "[scorecard]") {
    TestScoreCard sc;
    int dice[5] = {2, 3, 4, 5, 6};
    int score = sc.sumDice(dice);
    REQUIRE(score == 20);
}

TEST_CASE("Upper section totals and bonus", "[scorecard]") {
    TestScoreCard sc;
    // Fill upper section to trigger bonus
    sc.selectCategory(ONES, 3);
    sc.selectCategory(TWOS, 10);
    sc.selectCategory(THREES, 18);
    sc.selectCategory(FOURS, 20);
    sc.selectCategory(FIVES, 20);
    sc.selectCategory(SIXES, 30);

    int total = sc.calcTotalScore();

    REQUIRE(sc.savedScores[UPPER_SCORE] >= 63);
    REQUIRE(total >= 101);
}

TEST_CASE("Complete 13-category scorecard total", "[scorecard]") {
    TestScoreCard sc;
    // Upper section
    sc.selectCategory(ONES, 3);
    sc.selectCategory(TWOS, 6);
    sc.selectCategory(THREES, 9);
    sc.selectCategory(FOURS, 12);
    sc.selectCategory(FIVES, 10);
    sc.selectCategory(SIXES, 18);
    // Lower section
    sc.selectCategory(THREE_OF_A_KIND, 18);
    sc.selectCategory(FOUR_OF_A_KIND, 24);
    sc.selectCategory(FULL_HOUSE, 25);
    sc.selectCategory(SMALL_STRAIGHT, 30);
    sc.selectCategory(LARGE_STRAIGHT, 40);
    sc.selectCategory(YAHTZEE, 50);
    sc.selectCategory(CHANCE, 22);
    sc.selectCategory(YAHTZEE_BONUS, 0);

    int expectedUpper = 3+6+9+12+10+18; // 58
    int expectedBonus = 0;
    int expectedLower = 18+24+25+30+40+50+22+0;
    int expectedGrand = expectedUpper + expectedBonus + expectedLower;

    REQUIRE(sc.calcTotalScore() == expectedGrand);
}
