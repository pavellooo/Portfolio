#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../src/yahtzee.cpp"

// Subclass for testing protected members
class TestScoreCard : public ScoreCard {
public:
    int* readSavedScores() {
        return this->savedScores;
    }
};

TEST_CASE("Lower ScoreCard Tests", "[lower_scorecard]") { 
    int passed = 0, failed = 0;
    ScoreCard sc;

    // Sample dice sets for testing
    int threeKind[5] = {3,3,3,1,5};
    int fourKind[5]  = {2,2,2,2,6};
    int fullHouse[5] = {4,4,4,2,2};
    int smallStraight[5] = {1,2,3,4,6};
    int largeStraight[5] = {2,3,4,5,6};
    int yahtzee[5] = {5,5,5,5,5};

    REQUIRE(sc.calcThreeOfKind(threeKind) == 15);
    REQUIRE(sc.calcFourOfKind(fourKind) == 14);
    REQUIRE(sc.calcFullHouse(fullHouse) == 25);
    REQUIRE(sc.calcSmallStraight(smallStraight) == 30);
    REQUIRE(sc.calcLargeStraight(largeStraight) == 40);
    REQUIRE(sc.calcYahtzee(yahtzee) == 50);
}

TEST_CASE("Bonus testing") {
    TestScoreCard sc;
    int yahtzeeRolls[5] = {6, 6, 6, 6, 6};

    // First Yahtzee: score normally
    sc.selectCategory(YAHTZEE, sc.calcYahtzee(yahtzeeRolls));
    REQUIRE(sc.readSavedScores()[YAHTZEE] == 50);

    // Second Yahtzee triggers bonus
    sc.checkForYahtzeeBonus(yahtzeeRolls);
    REQUIRE(sc.readSavedScores()[YAHTZEE_BONUS] == 100);

    // Third Yahtzee adds another bonus
    sc.checkForYahtzeeBonus(yahtzeeRolls);
    REQUIRE(sc.readSavedScores()[YAHTZEE_BONUS] == 200);
}

TEST_CASE("Three/Four of a Kind edge cases", "[lower_scorecard]") {
    ScoreCard sc;
    
    int fiveKind[5] = {5,5,5,5,5};
    REQUIRE(sc.calcThreeOfKind(fiveKind) == 25);
    REQUIRE(sc.calcFourOfKind(fiveKind) == 25);
    
    int twoKind[5] = {1,1,2,3,4};
    REQUIRE(sc.calcThreeOfKind(twoKind) == 0);
    REQUIRE(sc.calcFourOfKind(twoKind) == 0);
}

TEST_CASE("Full House edge cases", "[lower_scorecard]") {
    ScoreCard sc;
    
    int fiveOfKind[5] = {3,3,3,3,3};
    REQUIRE(sc.calcFullHouse(fiveOfKind) == 0);  // Not a full house!
    
    int fourAndOne[5] = {2,2,2,2,5};
    REQUIRE(sc.calcFullHouse(fourAndOne) == 0);
}

TEST_CASE("Small Straight patterns", "[lower_scorecard]") {
    ScoreCard sc;
    
    int pattern2[5] = {2,3,4,5,1};
    REQUIRE(sc.calcSmallStraight(pattern2) == 30);
    
    int pattern3[5] = {3,4,5,6,1};
    REQUIRE(sc.calcSmallStraight(pattern3) == 30);
    
    int notStraight[5] = {1,2,3,5,6};
    REQUIRE(sc.calcSmallStraight(notStraight) == 0);
}

TEST_CASE("Large Straight validation", "[lower_scorecard]") {
    ScoreCard sc;
    
    int valid[5] = {1,2,3,4,5};
    REQUIRE(sc.calcLargeStraight(valid) == 40);
    
    int notLarge[5] = {1,2,3,4,6};
    REQUIRE(sc.calcLargeStraight(notLarge) == 0);
}