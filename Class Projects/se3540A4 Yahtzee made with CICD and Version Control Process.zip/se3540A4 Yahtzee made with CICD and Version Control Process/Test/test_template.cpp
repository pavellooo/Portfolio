#define CATCH_CONFIG_MAIN // you are supposed to only have this in one test file but I found it was needed in every one to avoid linker errors
#include "catch.hpp" 
#include "../src/yahtzee.cpp"

/*
NOTE:
use this file as a template for writing additional tests
Copy and paste this file, rename it, and add your tests
Once all tests are written, add the new test files to CMakeLists.txt and the .gitlab-ci.yml file, both have instructions on how to do so.
*/

TEST_CASE("Sample Test Case", "[sample]") {
    REQUIRE(1 + 1 == 2);
    // may have multiple REQUIRE() statements in a test case, and may break up
    // into multiple block within as so:
    SECTION("Another section of the same test case, template") {
        REQUIRE(2 * 2 == 4);
    }
}


/* old version, replace with Catch2 tests as shown above
int main() {
    int passed = 0, failed = 0;

    //example test
    if (true) {
        std::cout << "test 1 passed \n";
        passed++;
    }
    else {
        std::cout << "test 2 passed \n";
        failed++;
    }

    std::cout << "\nTesting summary: " << passed << " tests passed and " << failed << " tests failed \n";

    //return nonzero if any test failed, for CI/CD to show some failure flag
    return failed > 0 ? 1 : 0;
}
*/