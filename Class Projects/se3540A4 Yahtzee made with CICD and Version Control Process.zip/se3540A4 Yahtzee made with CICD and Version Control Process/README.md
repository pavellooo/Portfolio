# Yahtzee Game

A command-line implementation of the classic Yahtzee dice game in C++.

## Requirements

- C++ compiler with C++11 support
- CMake 3.10 or higher
- macOS, Linux, or Windows

## Installation
```bash
# Clone the repository
git clone https://gitlab.com/se3540_g10/se3540_fall2025_a04_g10.git
cd se3540_fall2025_a04_g10

# Build the project
mkdir build
cd build
cmake ..
make

# Run the game
./yahtzee
```


## How to Play

### Game Overview
- **13 rounds** total
- **3 rolls** per turn
- Score in one category each turn
- Each category can only be used once

### Commands
- `R` - Roll/Re-roll unheld dice
- `H` - Hold/Release a die (enter 1 - 5)
- `S` - Score your current hand
- `Q` - Quit game

### Gameplay
1. Roll the dice (automatic first roll)
2. Choose dice to hold by pressing `H` and entering the die number
3. Re-roll up to 2 more times
4. Press `S` to score in an available category


## Scoring Categories

### Upper Section (sum of matching dice)
- **Ones** - Sum of all 1's
- **Twos** - Sum of all 2's
- **Threes** - Sum of all 3's
- **Fours** - Sum of all 4's
- **Fives** - Sum of all 5's
- **Sixes** - Sum of all 6's
- **Bonus** - 35 points if upper section totals 63+

### Lower Section
- **Three of a Kind** - At least 3 same dice, score = sum of all dice
- **Four of a Kind** - At least 4 same dice, score = sum of all dice
- **Full House** - 3 of one number + 2 of another = 25 points
- **Small Straight** - 4 consecutive numbers = 30 points
- **Large Straight** - 5 consecutive numbers = 40 points
- **Yahtzee** - All 5 dice the same = 50 points
- **Chance** - Any combination, score = sum of all dice


### Main Classes
- **Dice** - Individual die with hold/release functionality
- **ScoreCard** - Tracks scores and calculates category points
- **Game** - Main game loop and turn management

## Building

The project uses **CMake** as the build tool. To build the project, follow these steps:

1. Ensure you have CMake 3.10 or higher installed.
2. From the project root directory, create a `build` directory:
   ```bash
   mkdir build
   cd build
   ```
3. Run the CMake configuration:
   ```bash
   cmake ..
   ```
4. Build the project:
   ```bash
   cmake --build .
   ```

### Build Options
- **Default Build**: Generates the `yahtzee` executable.
- **Clean Build**: Remove the `build` directory and repeat the steps above.

---

## Testing

The project uses the **Catch2** testing framework for unit testing. Catch2 is a header-only library, making it easy to integrate into the project. Test files are located in the `Test` directory.

### How It Works
- The test files includes `#define CATCH_CONFIG_MAIN`, which provides the entry point for Catch2 tests.
- Test files also need to include `catch.hpp` and define test cases using the `TEST_CASE` macro.
- Tests are run by building the test executables and executing them.
- The "test_template.cpp" file was added for future unit tests and to ensure that Catch2 is fully functional in the case of test case issues.

### Integration Experience
Integrating Catch2 was straightforward due to its header-only nature. Headers including 'CATCH_CONFIG_MAIN' had to be added to all files and only needed some small changes to previous test case files and CMake.

To run the tests:
```bash
# From the build directory
./test_template
./test_dice
```

---

## Statement of Contributions

- **Dmitri Vigil**: added the "end of Assigement4, added catch.hpp,added test_game_state, 
- **Patrick Sheehan**: 
- **Jeongho Yang**: Implemented the feature which shows how many rolls a user has left, and the turn counter which display how many turn the user has left. Added some more test cases for test_lower_scorecard.
- **Logan Pavelschak**: Set up the repository and files, created CMake configurations, fully created and debugged the CI/CD pipeline, created code outline, implemented Dice class and miscellaneous classes/fixes for scoreboard calculations, wrote all original test cases, and wrote template/example unit tests for use by groupmates. Note that I set up CI/CD for the  Assignment04 and only needed some small modifications for using Catch2.

---

## Integration

The project integrates test cases with CI/CD using GitLab pipelines. The `.gitlab-ci.yml` file defines the pipeline stages:

1. **Build Stage**:
   - Compiles the project using CMake.
   - Ensures the code builds successfully on all supported platforms.

2. **Test Stage**:
   - Runs all test executables (e.g., `test_template`, `test_dice`).
   - Reports test results and fails the pipeline if any test fails.

This ensures that all changes are automatically tested before being merged.