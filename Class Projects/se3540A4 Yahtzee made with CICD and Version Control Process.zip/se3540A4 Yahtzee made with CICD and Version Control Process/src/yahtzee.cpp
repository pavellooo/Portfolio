#include <iostream>
#include <string>
#include <stdlib.h>
#include <random>
#include <ctime>
#include <iomanip>
#include <vector>
#include <numeric>
#include <set>

using namespace std;

// scorecard category names for display
static const std::string categoryNames[18] = {
    "",                   // index 0 unused
    "Ones",               // 1
    "Twos",               // 2
    "Threes",             // 3
    "Fours",              // 4
    "Fives",              // 5
    "Sixes",              // 6
    "Upper Section Total",// 7
    "Bonus (>=63 for 35)",// 8
    "Three of a Kind",    // 9
    "Four of a Kind",     // 10
    "Full House (25)",    // 11
    "Small Straight (30)",// 12
    "Large Straight (40)",// 13
    "Yahtzee (50)",       // 14
    "Chance",             // 15
    "Yahtzee Bonus",      // 16
    "FINAL SCORE"         // 17
};

class Dice {
private:
    int value = 1;
    bool isHeld = false;

public:
    void hold() {
        isHeld = true;
    }
    void release() { // mark dice not held, so it will reroll
        isHeld = false;
    }
    void roll() {
        // generate random number and assign to value. use if statement, do nothing if isHeld = true.
        if (!isHeld) {
            value = (rand() % 6) + 1;
        }
    }
    // getter functions
    int getValue() { return value; }
    bool getIsHeld() const { return isHeld; }
};

enum CategoryIndex {
    // upper sections
    ONES = 1, // SUM OF ALL DICE THAT ARE ONE (INDEX 1)
    TWOS,     // SUM OF ALL DICE THAT ARE TWO (INDEX 2)
    THREES,   // SUM OF ALL DICE THAT ARE THREE (INDEX 3)
    FOURS,    // SUM OF ALL DICE THAT ARE FOUR (INDEX 4)
    FIVES,    // SUM OF ALL DICE THAT ARE FIVE (INDEX 5)
    SIXES,    // SUM OF ALL DICE THAT ARE SIX (INDEX 6)
           // intermediate r
    UPPER_SCORE, // SUM OF ONES - SIXES (INDEX 7)
    UPPER_BONUS, //(35 POINTS) BONUS CALCULATION (IF SUM >= 63) (INDEX 8)
                 // lower section
    THREE_OF_A_KIND, // SUM OF THREE DICES THAT ARE THE SAME NUMBER (INDEX 9)
    FOUR_OF_A_KIND,  // SUM OF FOUR DICES THAT ARE THE SAME NUMBER (INDEX 10)
    FULL_HOUSE,      //(25 POINTS) 3 OF THE SAME DICE + 2 OF THE SAME DICE (INDEX 11)
    SMALL_STRAIGHT,  //(30 POINTS) 3 DICE IN ASSENDING ORDER (INDEX 12)
    LARGE_STRAIGHT,  // 40 POINTS) 4 DICE IN ASSENDING ORDER (INDEX 13)
    YAHTZEE,         //(50 POINTS) 5 DICE IN ASSENDING ORDER (INDEX 14)
    CHANCE,          // SUM OF ALL 5 DICE (INDEX 15)
    YAHTZEE_BONUS,   // ADDITIONAL YAHTZEE BONUSES (INDEX 16)
    GRAND_TOTAL      // FIANL SCORE (INDEX 17)

};

class ScoreCard {
protected: //protected so that test subclass can access these members
    // arrays for final score
    int savedScores[18] = {0};
    // array to track if a category has been used (1) or is available (0);
    int categoryUsed[18] = {0};

    // formats the output of the socre cell
    void printScoreLine(int index, const string &name) {
        cout << "| " << setw(2) << index << ". " << left << setw(20) << name << " | ";

        if (categoryUsed[index] == 1) {
            cout << right << setw(4) << savedScores[index] << " |" << endl;
        }
        else {
            cout << right << setw(4) << "-" << " |" << endl;
        }
    }

    // helper function to count occurrences of each dice value corresponding to the index, for 3 of a kind and 4 of a kind
    void countValues(const int diceValues[5], int counts[7]) {
        for (int i = 1; i <= 6; ++i)
            counts[i] = 0;
        for (int i = 0; i < 5; ++i)
            counts[diceValues[i]]++;
    }

public:
    // default constructor, saves all scores to 0 and marks all categories unused except intermediate rows
    ScoreCard() {
        for (int i = 1; i <= 17; ++i) {
            savedScores[i] = 0;
            categoryUsed[i] = 0;
        }
        categoryUsed[UPPER_SCORE] = 1;
        categoryUsed[UPPER_BONUS] = 1;
        categoryUsed[YAHTZEE_BONUS] = 1;
        categoryUsed[GRAND_TOTAL] = 1;
    }

    void displayScoreCard() {
        cout << "\n++++++++++++++++++++++++++++++++++" << endl;
        cout << "          YAHTZEE SCORECARD         " << endl;
        cout << "++++++++++++++++++++++++++++++++++" << endl;

        // upper section
        for (int i = 1; i <= 6; ++i) {
            printScoreLine(i, categoryNames[i]);
        }
        cout << "----------------------------------" << endl;

        // recaluate and display intermediate rows
        calcTotalScore();

        printScoreLine(UPPER_SCORE, "   Upper Section Total");
        printScoreLine(UPPER_BONUS, "   Bonus (>=63 for 35)");
        cout << "==================================" << endl;

        // lower selection
        printScoreLine(THREE_OF_A_KIND, "Three of a Kind");
        printScoreLine(FOUR_OF_A_KIND, "Four of a Kind");
        printScoreLine(FULL_HOUSE, "Full House (25))");
        printScoreLine(SMALL_STRAIGHT, "Small Straight (30)");
        printScoreLine(LARGE_STRAIGHT, "Large Straight (40)");
        printScoreLine(YAHTZEE, "Yahtzee (50)");
        printScoreLine(CHANCE, "Chance");
        cout << "----------------------------------" << endl;

        printScoreLine(YAHTZEE_BONUS, "   Yahtzee Bonus");
        cout << "==================================" << endl;

        // grand total
        printScoreLine(GRAND_TOTAL, "   FINAL SCORE");
        cout << "++++++++++++++++++++++++++++++++++\n"
             << endl;
    }

    // calulate the score for a specific Upper section category (1s -6s)
    int calcUpperScore(int targetValue, const int diceValues[5]) {
        int score = 0;
        for (int i = 0; i < 5; ++i) {
            if (diceValues[i] == targetValue) {
                score += targetValue;
            }
        }
        return score;
    }

    bool checkIfCategoryIsAvailable(int index) {
        // boundary checker
        if (index < 1 || index > 15) {
            return false;
        }
        // category is available if it has not been used
        return categoryUsed[index] == 0;
    }

    bool selectCategory(int index, int scoreToSave) {
        // use above function to error check. Then save the score for the corresponding index, and return true if it worked (use the bool for input validation)
        if (!checkIfCategoryIsAvailable(index)) {
            return false;
        }
        // mark the primary category as used
        categoryUsed[index] = 1;

        // save the score
        savedScores[index] = scoreToSave;

        // recalcuate total immediately
        calcTotalScore();

        return true;
    }

    void displayAllCategories(const int diceValues[5]) { // calculate and display potential scores for current dice hand for all available categories. Simple for loop and if stateemnts. output results to console with their corresponding index for selection
        cout << "\n -- POTENTIAL SCORES FOR CURRENT ROLL ---" << endl;

        //for calculating yahtzee bonus
        bool isYahtzee = (calcYahtzee(diceValues) == 50);

        for (int i = ONES; i <= CHANCE; ++i) {
            if (checkIfCategoryIsAvailable(i)) {
                int potentialScore = 0;
                switch (i) {
                case ONES: case TWOS: case THREES: case FOURS: case FIVES: case SIXES:
                    potentialScore = calcUpperScore(i, diceValues);
                    break;
                case THREE_OF_A_KIND:
                    potentialScore = calcThreeOfKind(diceValues);
                    break;
                case FOUR_OF_A_KIND:
                    potentialScore = calcFourOfKind(diceValues);
                    break;
                case FULL_HOUSE:
                    potentialScore = calcFullHouse(diceValues);
                    break;
                case SMALL_STRAIGHT:
                    potentialScore = calcSmallStraight(diceValues);
                    break;
                case LARGE_STRAIGHT:
                    potentialScore = calcLargeStraight(diceValues);
                    break;
                case YAHTZEE:
                    potentialScore = isYahtzee ? 50 : 0;
                    break;
                case CHANCE:
                    potentialScore = sumDice(diceValues);
                    break;
                }
                cout << setw(2) << i << ". " << left << setw(20) << categoryNames[i] << ": " << potentialScore << endl;
            }
        }
        
        //yahztee bonus info
        if (isYahtzee && !checkIfCategoryIsAvailable(YAHTZEE)) {
            cout << "\nYou rolled a Yahtzee! Since you've already scored Yahtzee, you will receive a Yahtzee bonus of 100 points!" << endl;
        }
        
        cout << "----------------------------------------" << endl;
    }

    int calcTotalScore() {
        int upperSum = 0;
        int lowerSum = 0;

        // calulate upper section sum (1-6)
        for (int i = ONES; i <= SIXES; ++i) {
            upperSum += savedScores[i];
        }
        savedScores[UPPER_SCORE] = upperSum;

        // caluate upper section bonus
        if (upperSum >= 63) {
            savedScores[UPPER_BONUS] = 35;
        }
        else {
            savedScores[UPPER_BONUS] = 0;
        }

        // calculate lower section sum
        for (int i = THREE_OF_A_KIND; i <= CHANCE; ++i)
            lowerSum += savedScores[i];

        // add yahtzee bonus
        lowerSum += savedScores[YAHTZEE_BONUS];

        // grand total
        int total = upperSum + savedScores[UPPER_BONUS] + lowerSum;
        savedScores[GRAND_TOTAL] = total;

        return total;
    }

    // helper function to sum all dice values, used for chance/3 of a kind/4 of a kind
    int sumDice(const int diceValues[5]) {
        int total = 0;
        for (int i = 0; i < 5; ++i)
            total += diceValues[i];
        return total;
    }

    int calcThreeOfKind(const int diceValues[5]) {
        int counts[7];
        countValues(diceValues, counts);
        // see if any value appears at least 3 times, if so return sum of all dice, else return 0
        for (int i = 1; i <= 6; ++i) {
            if (counts[i] >= 3) {
                return sumDice(diceValues);
            }
        }
        return 0;
    }

    int calcFourOfKind(const int diceValues[5]) {
        int counts[7];
        countValues(diceValues, counts);
        // see if any value appears at least 4 times, if so return sum of all dice, else return 0
        for (int i = 1; i <= 6; ++i) {
            if (counts[i] >= 4) {
                return sumDice(diceValues);
            }
        }
        return 0;
    }

    int calcSmallStraight(const int diceValues[5]) {
        // use set to find unique values
        set<int> uniqueValues;
        for (int i = 0; i < 5; ++i) {
            uniqueValues.insert(diceValues[i]);
        }
        // check for small straight sequences
        if ((uniqueValues.count(1) && uniqueValues.count(2) && uniqueValues.count(3) && uniqueValues.count(4)) ||
            (uniqueValues.count(2) && uniqueValues.count(3) && uniqueValues.count(4) && uniqueValues.count(5)) ||
            (uniqueValues.count(3) && uniqueValues.count(4) && uniqueValues.count(5) && uniqueValues.count(6))) {
            return 30; // small straight found
        }
        return 0; // no small straight
    }
    int calcLargeStraight(const int diceValues[5]) {
        // use set to find unique values
        set<int> uniqueValues;
        for (int i = 0; i < 5; ++i) {
            uniqueValues.insert(diceValues[i]);
        }
        // check for large straight sequences
        if ((uniqueValues.count(1) && uniqueValues.count(2) && uniqueValues.count(3) && uniqueValues.count(4) && uniqueValues.count(5)) ||
            (uniqueValues.count(2) && uniqueValues.count(3) && uniqueValues.count(4) && uniqueValues.count(5) && uniqueValues.count(6))) {
            return 40; // large straight found
        }
        return 0; // no large straight
    }

    int calcFullHouse(const int diceValues[5]) {
        int counts[7];
        countValues(diceValues, counts);
        bool hasThree = false;
        bool hasTwo = false;
        for (int i = 1; i <= 6; ++i) {
            if (counts[i] == 3) {
                hasThree = true;
            }
            else if (counts[i] == 2) {
                hasTwo = true;
            }
        }
        if (hasThree && hasTwo) {
            return 25; // full house found
        }
        return 0; // no full house
    }

    int calcYahtzee(const int diceValues[5]) {
        int firstValue = diceValues[0];
        for (int i = 1; i < 5; ++i) {
            if (diceValues[i] != firstValue) {
                return 0; // not all dice are the same
            }
        }
        
        return 50; // all dice are the same
    }

    // Call this at the START of the scoring phase
    void checkForYahtzeeBonus(const int diceValues[5]) {
        // check if the current roll is a Yahtzee
        bool isYahtzee = true;
        int firstValue = diceValues[0];
        for (int i = 1; i < 5; ++i) {
            if (diceValues[i] != firstValue) {
                isYahtzee = false;
                break;
            }
        }

        if (!isYahtzee) {
            return; // No Yahtzee rolled, exit early
        }

        // If it is, check if the Yahtzee category is already scored with 50 points
        if (categoryUsed[YAHTZEE] == 1 && savedScores[YAHTZEE] == 50) {
            cout << "\n**************************" << endl;
            cout << "YAHTZEE BONUS! +100 points" << endl;
            cout << "**************************" << endl;

            // Add 100 to the bonus score
            savedScores[YAHTZEE_BONUS] += 100;
            //recalculate total score
            calcTotalScore();
        }
    }

};

class Game {
private:
    static const int NUM_DICE = 5;
    static const int MAX_ROLLS = 3;
    int roundCounter = 0; // 0-12 for 13 rounds
    Dice DiceHand[NUM_DICE];
    ScoreCard sc;
    char input;
    int rollsThisTurn;
    int rollsRemaining;

    // placeholder for scoring action
    void getCurrentDiceValues(int values[5]) {
        for (int i = 0; i < NUM_DICE; ++i) {
            values[i] = DiceHand[i].getValue();
        }
    }

public:
    void performScoring() {
        cout << "\n--- SCORING PHASE ---" << endl;

        // show availabe scores
        int diceValues[NUM_DICE];
        getCurrentDiceValues(diceValues);
        //add yahtzee bonus
        sc.checkForYahtzeeBonus(diceValues);
        // show potential scores
        sc.displayAllCategories(diceValues);
        // show current scorecard
        sc.displayScoreCard();

        int chosenCategory;
        while (true) {
            cout << "Enter the category index to score (or enter '15' to leave **FIX COMING SOON): ";
            cin >> chosenCategory;

            if (cin.fail()) { // error checking for non-integer input
                cin.clear(); // clear error flag
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
                cout << "Invalid input. Please enter a number corresponding to an available category." << endl;
                continue;
            }
            else if (sc.checkIfCategoryIsAvailable(chosenCategory)) {
                break; // valid choice
            }
            else {
                cout << "Invalid category selection. Please choose an available category." << endl;
            }
        }

        int scoreToSave = 0;

        // Auto-select Chance category (Index 15)
        switch (chosenCategory) {
        case ONES: case TWOS: case THREES: case FOURS: case FIVES: case SIXES:
            scoreToSave = sc.calcUpperScore(chosenCategory, diceValues);
            break;
        case THREE_OF_A_KIND:
            scoreToSave = sc.calcThreeOfKind(diceValues);
            break;
        case FOUR_OF_A_KIND:
            scoreToSave = sc.calcFourOfKind(diceValues);
            break;
        case CHANCE:
            scoreToSave = sc.sumDice(diceValues);
            break;
        case FULL_HOUSE:
            scoreToSave = sc.calcFullHouse(diceValues);
            break;
        case SMALL_STRAIGHT:
            scoreToSave = sc.calcSmallStraight(diceValues);
            break;
        case LARGE_STRAIGHT:
            scoreToSave = sc.calcLargeStraight(diceValues);
            break;
        case YAHTZEE:
            scoreToSave = sc.calcYahtzee(diceValues);
            break;
        default:
            scoreToSave = 0; // placeholder for other categories
            break;
        }

        sc.selectCategory(chosenCategory, scoreToSave);
        sc.displayScoreCard();
    }

    void startTurn() {
        // reset turn counter each turn
        rollsThisTurn = 0;
        rollsRemaining = MAX_ROLLS;
        // release all dice by default
        for (int i = 0; i < NUM_DICE; i++) {
            DiceHand[i].release();
        }

        roundCounter++;
        cout << "\n--- START OF ROUND " << roundCounter << " ---" << endl;
    }

    void displayRollStatus() {
        cout << "\n=== Roll " << rollsThisTurn << " of 3 ===";
        if (rollsThisTurn < 3) {
            cout << " (" << (3 - rollsThisTurn) << " rolls remaining)";
        }
        else {
            cout << " (No rolls remaining)";
        }
        cout << "\n"
             << endl;
    }

    void rollDice() { // roll all dice, and output their values to console and related information
        if (rollsThisTurn >= 3) {
            cout << "No rolls left this turn!" << endl;
            return;
        }
        for (int i = 0; i < 5; i++) {
            DiceHand[i].roll();
        }
        rollsThisTurn++;

        // Display roll status
        displayRollStatus();

        cout << "Rolled roll number " << rollsThisTurn << endl;
        // output current dice values
        for (int i = 0; i < 5; i++) {
            cout << DiceHand[i].getValue() << " ";
        }
        cout << endl;
    }

    void displayDiceStatus() const {
        // show rolls left based on rolls USED
        int rollsLeft = MAX_ROLLS - rollsThisTurn;
        cout << "\n[Rolls #: " << rollsLeft << "] {Round: " << roundCounter << "]" << endl;
        cout << "---------------------------------" << endl;
        cout << "Dice: ";
        for (int i = 0; i < NUM_DICE; ++i) {
            cout << "| " << i + 1 << ":" << (DiceHand[i].getIsHeld() ? "H" : "R") << " ";
        }
        cout << "|" << endl;
        cout << "---------------------------------" << endl;
    }

    // toggling
    void toggleHold(int diceIndex) {
        if (diceIndex >= 1 && diceIndex <= NUM_DICE) {
            int index = diceIndex - 1;
            if (DiceHand[index].getIsHeld()) {
                DiceHand[index].release();
            }
            else {
                DiceHand[index].hold();
            }
            displayDiceStatus();
        }
        else {
            cout << "Invalid dice index. Please choose 1 to 5" << endl;
        }
    }

    void runTurn() {
        // first mandatory roll
        rollDice();

        // while(roll)
        while (rollsThisTurn < MAX_ROLLS) {
            cout << "\nEnter command ('R' to re-roll unheld dice, 'S' to score, 'H' to hold/release): ";
            char command;
            cin >> command;

            if (command == 'R' || command == 'r') {
                rollDice();
            }
            else if (command == 'S' || command == 's') {
                if (rollsThisTurn == 0) {
                    cout << "You must roll at least once before scoring." << endl;
                    continue;
                }
                performScoring();
                return; // End turn after scoring
            }
            else if (command == 'H' || command == 'h') {
                cout << "Enter dice index to toggle hold (1-5): ";
                int index;
                cin >> index;
                toggleHold(index);

                // --- THIS IS THE FIX ---
                if (cin.fail()) {
                    cin.clear(); // Clear the error flag
                    // Discard the bad input from the buffer
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Please select 'h' to try again (**FIX COMING SOON**" << endl;
                }
                else {
                    // Only call toggleHold if the input was a valid number
                    toggleHold(index);
                }
                // --- END FIX ---
            }
            else {
                cout << "Invalid command. Please try again." << endl;
            }
        }

        // if rolls are used up (rollsThisTurns == 3), force scoring
        if (rollsThisTurn == MAX_ROLLS) {
            cout << "\nMax rolls reached. Proceeding to score selection." << endl;
            performScoring();
        }
    }

    void runGameLoop(){
        while (roundCounter < 13) {
            startTurn();
            runTurn();
        }
        endGame();
    }

    void endGame() {
        cout << "\n-----GAME OVER-----" << endl;
        cout << "Your score:\n";
        sc.displayScoreCard();

        // Ask if player wants to play again
        char choice;
        while (true) {
            cout << "Would you like to play again? (Y/N): ";
            cin >> choice;
            if (choice == 'Y' || choice == 'y') {
                clearScreen();
                resetGame();
                runGameLoop();
                return;
            }
            else if (choice == 'N' || choice == 'n') {
                cout << "Thanks for playing Yahtzee!" << endl;
                exit(0);
            }
            else {
                cout << "Invalid input, please enter either Y or N." << endl;
            }
        }
    }

    void resetGame() {
        // reset variables
        roundCounter = 0;
        rollsThisTurn = 0;
        // make sure all die are released
        for (int i = 0; i < NUM_DICE; i++) {
            DiceHand[i].release();
        }
        // reset scorecard
        sc = ScoreCard();
    }
    void clearScreen() {
#ifdef _WIN32
        system("cls"); // clear command on windows
#else
        system("clear"); // clear command on linux/mac
#endif
    }
};

// define NO_MAIN to prevent duplicate main() definitions in test files.
#ifndef NO_MAIN
int main() {
    // initialize random seed
    srand(time(0));

    Game game;
    game.runGameLoop();

    return 0;
}
#endif
