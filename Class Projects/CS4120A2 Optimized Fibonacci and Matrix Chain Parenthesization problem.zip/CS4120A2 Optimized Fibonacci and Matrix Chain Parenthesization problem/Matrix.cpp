//Matrix.cpp
//implementation of the 3 matrix chain optimal parentheses functions in the header file

#include "Matrix.h"
#include <string>
#include <vector>
#include <climits>
#include <chrono>
#include <iostream>

using namespace std;

void Matrix::PrintOptimalParenthesis (int i, int j, vector<vector<int>>& s, char& matrixName) {
	if (i == j) {
		cout << matrixName++;
		return;
	}
	cout << "(";
	PrintOptimalParenthesis(i, s[i][j], s, matrixName);
	PrintOptimalParenthesis(s[i][j] + 1, j, s, matrixName);
	cout << ")";
}

long long Matrix::RecursiveMC (int i, int j, vector<int> dims, vector<vector<int>>& s) {
	//base case
	if (i == j)
		return 0;

	// minCost instead of m[i,j]
	long long minCost = LLONG_MAX;

	for (int k = i; k < j; k++) {
		long long cost = RecursiveMC(i, k, dims, s) + RecursiveMC(k + 1, j, dims, s) + ((long long)dims[i - 1] * dims[k] * dims[j]);
		//update memory if it is less
		if (cost < minCost) {
			minCost = cost;
			s[i][j] = k;
		}
	}

	return minCost;
}

//helper function for memoized approach
long long Matrix::LookupChain (vector<vector<long long>>& m, vector<vector<int>>& s, vector<int> dims, int i, int j) {
	if (m[i][j] < LLONG_MAX)
		return m[i][j];

	if (i == j) {
		m[i][j] = 0;
	} 
	else {
		m[i][j] = LLONG_MAX;
		for (int k = i; k < j; k++) {
			// cost instead of q
			long long q = LookupChain(m, s, dims, i, k) + LookupChain(m, s, dims, k+1, j) + (dims[i - 1] * dims[k] * dims[j]);
			//update minimum cost and split point
			if (q < m[i][j]) {
				m[i][j] = q;
				s[i][j] = k;
			}
		}
	}

	return m[i][j];
}

//public wrapper
long long Matrix::MemoizedMC (int n, vector<int> dims, vector<vector<int>>& s) {
	vector<vector<long long>> m(n + 1, vector<long long>(n + 1, LLONG_MAX));
	//call recursive function
	return LookupChain(m, s, dims, 1, n);
}

long long Matrix::BottomUpMC(int n, vector<int> dims, vector<vector<int>>& s) {
	//s holds splits, m holds subproblem solutions
	vector<vector<long long>> m(n + 1, vector<long long>(n + 1, 0));
	for (int i = 0; i <= n; i++)
		m[i][i] = 0;
	
	for (int l = 2; l <= n; l++) { // l is chain length
		for (int i = 1; i <= n - l + 1; i++) {
			int j = i + l - 1;
			m[i][j] = LLONG_MAX;

			for (int k = i; k < j; k++) {
				long long q = m[i][k] + m[k + 1][j] + (dims[i - 1] * dims[k] * dims[j]);
				if (q < m[i][j]) {
					m[i][j] = q;
					s[i][j] = k;
				}
			}
		}
	}

	return m[1][n];
}
