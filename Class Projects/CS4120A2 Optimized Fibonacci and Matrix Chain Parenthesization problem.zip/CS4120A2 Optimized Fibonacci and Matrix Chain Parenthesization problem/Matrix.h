#pragma once
// Matrix.h

#include <vector>

class Matrix {
public:
	void PrintOptimalParenthesis(int i, int j, std::vector<std::vector<int>>& s, char& matrixName);
	long long RecursiveMC(int i, int j, std::vector<int> dims, std::vector<std::vector<int>>& s);
	long long LookupChain(std::vector<std::vector<long long>>& m, std::vector<std::vector<int>>& s, std::vector<int> dims, int i, int j);
	long long MemoizedMC(int n, std::vector<int> dims, std::vector<std::vector<int>>& s);
	long long BottomUpMC(int n, std::vector<int> dims, std::vector<std::vector<int>>& s);
};