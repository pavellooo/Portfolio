//Fibonacci.cpp
//implementation file for the 3 fibonacci approaches
#include "Fibonacci.h"
#include <vector>

using namespace std;

long long Fibonacci::RecursiveFibonacci(int n) {
	if (n <= 0)
		return 0;
	if (n == 1)
		return 1;
	else
		return RecursiveFibonacci(n - 1) + RecursiveFibonacci(n - 2);
}

long long Fibonacci::MemoizedFibonacci(int n) {
	vector<long long> memo(n + 1, -1); //initialize all elements to -1
	return MemoizedFibonacciAux(memo, n);
}

long long Fibonacci::MemoizedFibonacciAux(vector<long long>& memo, int n) {
	if (memo[n] >= 0)
		return memo[n];
	if (n == 0)
		memo[n] = 0;
	else if (n == 1)
		memo[n] = 1;
	else
		memo[n] = MemoizedFibonacciAux(memo, n - 1) + MemoizedFibonacciAux(memo, n - 2);
	return memo[n];
}

long long Fibonacci::BottomUpFibonacci(int n) {
	if (n <= 1)
		return n;

	vector<long long> solutions(n + 1);
	
	solutions[0] = 0;
	solutions[1] = 1;

	for (int i = 2; i <= n; i++) {
		solutions[i] = solutions[i - 1] + solutions[i - 2];
	}

	return solutions[n];
}

