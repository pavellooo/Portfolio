/*
Name: Logan Pavelschak
Date: April 16, 2025
Purpose: To experiment with Dynammic programming
for the fibonacci and optimal matrix chain parenthesization problems
*/
#include <iostream>
#include "Fibonacci.h"
#include "Matrix.h"
#include <tuple>
#include <chrono>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;
using namespace std::chrono;

int main() {
	cout << "starting fibonacci computations: \n" << endl;

	Fibonacci F;

	ifstream fibInputFile("Fib_Inputs.txt");
	if (!fibInputFile.is_open()) {
		cerr << "error opening fibonacci input file" << endl;
		return 1;
	}

	int number;
	while (fibInputFile >> number) {
		cout << "Processing number: " << number << "\n" << endl;

		//run all 3 algorithms on the fibonacci input number
		for (int i = 0; i < 3; i++) {
			high_resolution_clock::time_point t1 = high_resolution_clock::now();
			long long x;

			switch (i) {
			case 0:
				x = F.RecursiveFibonacci(number);
				cout << "Recursive results: " << endl;
				break;
			case 1:
				x = F.MemoizedFibonacci(number);
				cout << "Memoized results: " << endl;
				break;
			case 2:
				x = F.BottomUpFibonacci(number);
				cout << "Bottom Up results: " << endl;
				break;
			default:
				break;
			}

			high_resolution_clock::time_point t2 = high_resolution_clock::now();
			duration<double> timeSpan = duration_cast<duration<double>>(t2 - t1);

			cout << "input number: " << number << "\ntime: " << timeSpan.count() << " seconds\n" << "result: " << x << "\n" << endl;

		}
		cout << "------------ \n" << endl;
	}

	fibInputFile.close();

	// Matrix chain multiplication functions:

	cout << "Starting Matrix computations: \n" << endl;

	Matrix m;

	ifstream matrixInputFile("Matrix_Inputs.txt");
	if (!matrixInputFile.is_open()) {
		cerr << "error opening matrix input file" << endl;
		return 1;
	}

	int n;
	while (matrixInputFile >> n) {
		vector<int> p(n + 1);
		cout << "Processing " << n << " matrices:\n" << endl;

		//read in the (n+1) dimensions
		for (int i = 0; i <= n; i++) {
			matrixInputFile >> p[i];
		}

		//run all 3 algorithms on the matrices
		for (int i = 0; i < 3; i++) {
			high_resolution_clock::time_point t1 = high_resolution_clock::now();
			vector<vector<int>> split(n + 1, vector<int>(n + 1, 0));
			long long minCost = 0;

			switch (i) {
			case 0:
				minCost = m.RecursiveMC(1, n, p, split);
				cout << "Recursive results: " << endl;
				break;
			case 1:
				minCost = m.MemoizedMC(n, p, split);
				cout << "\nMemoized results: " << endl;
				break;
			case 2:
				minCost = m.BottomUpMC(n, p, split);
				cout << "\nBottom Up results: " << endl;
				break;
			default:
				break;
			}

			high_resolution_clock::time_point t2 = high_resolution_clock::now();
			duration<double> timeSpan = duration_cast<duration<double>>(t2 - t1);

			cout << "cost: " << minCost << " scalar multiplications\ntime: " << timeSpan.count() << " seconds\nparenthesization : ";
			char name = 'A';
			m.PrintOptimalParenthesis(1, n, split, name);
			cout << endl;
		}

		cout << "\n -------------- \n" << endl;
	}

	matrixInputFile.close();

	//extra credit, the most feasible times for recursive. Just running it for a few hours and seeing how long they take
	cout << "running recursive fibonacci algorithm on integers 50-100, or stopping it when it takes too long: \n" << endl;
	long long result;
	for (int i = 50; i < 100; i +=2) {
		high_resolution_clock::time_point t1 = high_resolution_clock::now();
		result = F.RecursiveFibonacci(i);
		high_resolution_clock::time_point t2 = high_resolution_clock::now();
		duration<double> timeSpan = duration_cast<duration<double>>(t2 - t1);
		cout << "input number: " << i << "\ntime: " << timeSpan.count() << " seconds\n" << "result: " << result << "\n" << endl;
	}

	return 0;
}

