#pragma once
// Fibonacci.h
#include <vector>

class Fibonacci {
public:
	long long RecursiveFibonacci(int n);
	long long MemoizedFibonacci(int n);
	long long BottomUpFibonacci(int n);
	long long MemoizedFibonacciAux(std::vector<long long>& memo, int n);
};